package com.example.arcaptions

import com.google.mlkit.nl.translate.TranslateLanguage
import java.util.Locale

/** لغات الصوت المدعومة (نماذج Vosk الصغيرة) ولغات الترجمة (ML Kit). */
object Langs {
    private fun m(id: String, mb: Int, label: String? = null) = ModelManager.Info(id, mb, label)

    val SOURCES: Map<String, List<ModelManager.Info>> = linkedMapOf(
        "en" to listOf(m("vosk-model-small-en-us-0.15", 40), m("vosk-model-en-us-0.22-lgraph", 128)),
        "ar" to listOf(m("vosk-model-small-ar-tn-0.1-linto", 158, "تونسي"), m("vosk-model-ar-mgb2-0.4", 318, "فصحى")),
        "zh" to listOf(m("vosk-model-small-cn-0.22", 42)),
        "ru" to listOf(m("vosk-model-small-ru-0.22", 45)),
        "fr" to listOf(m("vosk-model-small-fr-0.22", 41)),
        "de" to listOf(m("vosk-model-small-de-0.15", 45)),
        "es" to listOf(m("vosk-model-small-es-0.42", 39)),
        "pt" to listOf(m("vosk-model-small-pt-0.3", 31)),
        "tr" to listOf(m("vosk-model-small-tr-0.3", 35)),
        "vi" to listOf(m("vosk-model-small-vn-0.4", 32), m("vosk-model-vn-0.4", 78)),
        "it" to listOf(m("vosk-model-small-it-0.22", 48)),
        "nl" to listOf(m("vosk-model-small-nl-0.22", 39)),
        "ca" to listOf(m("vosk-model-small-ca-0.4", 42)),
        "fa" to listOf(m("vosk-model-small-fa-0.42", 53)),
        "tl" to listOf(m("vosk-model-tl-ph-generic-0.6", 320)),
        "uk" to listOf(m("vosk-model-small-uk-v3-nano", 73), m("vosk-model-small-uk-v3-small", 133)),
        "sv" to listOf(m("vosk-model-small-sv-rhasspy-0.15", 289)),
        "ja" to listOf(m("vosk-model-small-ja-0.22", 48)),
        "eo" to listOf(m("vosk-model-small-eo-0.42", 42)),
        "hi" to listOf(m("vosk-model-small-hi-0.22", 42)),
        "cs" to listOf(m("vosk-model-small-cs-0.4-rhasspy", 44)),
        "pl" to listOf(m("vosk-model-small-pl-0.22", 50)),
        "ko" to listOf(m("vosk-model-small-ko-0.22", 82)),
        "gu" to listOf(m("vosk-model-small-gu-0.42", 100)),
        "te" to listOf(m("vosk-model-small-te-0.42", 58)),
        "ka" to listOf(m("vosk-model-small-ka-0.42", 45))
    )

    fun name(code: String): String = Locale(code).getDisplayName(Locale("ar"))
    fun sources(): List<String> = SOURCES.keys.filter { it in TranslateLanguage.getAllLanguages() }.sortedBy { name(it) }
    fun targets(): List<String> = TranslateLanguage.getAllLanguages().sortedBy { name(it) }
}
