package com.example.arcaptions

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.media.*
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.*
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import org.vosk.Model
import org.vosk.Recognizer
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.abs
import kotlin.math.ceil

class CaptionService : Service() {
    companion object { @Volatile var running = false }

    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var projection: MediaProjection? = null
    private lateinit var wm: WindowManager
    private var box: LinearLayout? = null
    private var arTv: TextView? = null
    private var enTv: TextView? = null
    private var lp: WindowManager.LayoutParams? = null
    private val h = Handler(Looper.getMainLooper())
    private val clearRun = Runnable { box?.visibility = View.INVISIBLE }
    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> h.post { restyle() } }
    private val seq = AtomicLong()
    private val queue = ArrayDeque<Pair<String, String>>()
    private var playing = false
    private val playRun = Runnable { playNext() }
    private val results = HashMap<Long, Pair<String, String>>()
    private var nextId = 1L
    private val history = ArrayList<String>()
    @Volatile private var keyBad = false
    private var translator: com.google.mlkit.nl.translate.Translator? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, f: Int, id: Int): Int {
        if (intent?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("cap", "الترجمة", NotificationManager.IMPORTANCE_LOW))
        val stopPi = PendingIntent.getService(this, 0, Intent(this, CaptionService::class.java).setAction("STOP"),
            PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "cap").setContentTitle("ترجمان يعمل")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_media_pause), "إيقاف", stopPi).build())
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

        @Suppress("DEPRECATION")
        val data = intent?.getParcelableExtra<Intent>("data")
        if (data == null || !Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(intent.getIntExtra("code", 0), data)
        projection?.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }, h)
        val src = prefs().getString("src", "en") ?: "en"; val tgt = prefs().getString("tgt", "ar") ?: "ar"
        // نفس اللغة = تفريغ نصي فقط بدون ترجمة
        if (src != tgt) translator = Translation.getClient(
            TranslatorOptions.Builder().setSourceLanguage(src).setTargetLanguage(tgt).build())
        running = true
        buildOverlay(); prefs().registerOnSharedPreferenceChangeListener(listener)
        show("جاري تجهيز الترجمة...")
        scope.launch { engine() }
        return START_NOT_STICKY
    }

    private fun buildOverlay() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        arTv = TextView(this).apply { gravity = Gravity.CENTER; textDirection = View.TEXT_DIRECTION_FIRST_STRONG }
        enTv = TextView(this).apply { gravity = Gravity.CENTER; textDirection = View.TEXT_DIRECTION_FIRST_STRONG }
        box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(28), dp(14), dp(28), dp(14)); visibility = View.INVISIBLE
            addView(enTv); addView(arTv)
        }
        lp = WindowManager.LayoutParams((resources.displayMetrics.widthPixels * 0.85f).toInt(),
            ViewGroup.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT)
        wm.addView(box, lp)
        restyle()
    }

    private fun restyle() {
        val b = box ?: return
        val s = loadStyle()
        applyStyle(s, b, arTv!!, enTv!!)
        lp!!.gravity = Gravity.CENTER_HORIZONTAL or when (s.pos) { 0 -> Gravity.BOTTOM; 1 -> Gravity.CENTER_VERTICAL; else -> Gravity.TOP }
        lp!!.y = dp(48)
        wm.updateViewLayout(b, lp)
    }

    /** رسائل النظام: تُعرض فوراً وتلغي الطابور. */
    private fun show(ar: String, en: String = "", ms: Long = 6000) {
        h.post { queue.clear(); h.removeCallbacks(playRun); playing = false; showNow(ar, en, ms) }
    }

    private fun showNow(ar: String, en: String, ms: Long) {
        if (ar.isBlank()) { box?.visibility = View.INVISIBLE; return }
        arTv?.text = ar; enTv?.text = en
        enTv?.visibility = if (en.isBlank() || !loadStyle().showEn) View.GONE else View.VISIBLE
        box?.visibility = View.VISIBLE
        h.removeCallbacks(clearRun); h.postDelayed(clearRun, ms)
    }

    /** يقسّم الترجمة لصفحات قصيرة (حد أقصى للكلمات) ويعرضها بالتتابع. */
    private fun enqueue(ar: String, en: String) {
        val maxW = prefs().getInt("maxWords", 10)
        val words = ar.split(" ").filter { it.isNotBlank() }
        if (words.size <= maxW) queue.addLast(ar to en)
        else {
            val pages = ceil(words.size / maxW.toDouble()).toInt()
            val per = ceil(words.size / pages.toDouble()).toInt()
            words.chunked(per).forEachIndexed { i, pg -> queue.addLast(pg.joinToString(" ") to (if (i == 0) en else "")) }
        }
        while (queue.size > 2) queue.removeFirst()   // نلحق البث المباشر
        if (!playing) playNext()
    }

    private fun playNext() {
        val n = queue.removeFirstOrNull()
        if (n == null) { playing = false; h.removeCallbacks(clearRun); h.postDelayed(clearRun, 2500); return }
        playing = true
        showNow(n.first, n.second, 60000)
        var ms = (n.first.split(" ").size * 330L + 500L).coerceAtLeast(1200L)
        if (queue.size >= 1) ms = (ms * 0.7).toLong().coerceAtLeast(900L)
        h.postDelayed(playRun, ms)
    }

    /** يحافظ على ترتيب الجمل حتى لو وصلت الترجمات متأخرة. */
    private fun deliver(id: Long, ar: String, en: String) {
        h.post {
            if (id < nextId) return@post   // نتيجة متأخرة تم تجاوزها
            results[id] = ar to en
            while (true) {
                val r = results.remove(nextId) ?: break
                if (r.first.isNotBlank()) enqueue(r.first, r.second)
                nextId++
            }
        }
    }

    private fun fail(msg: String) {
        show(msg, "", 8000)
        h.postDelayed({ stopSelf() }, 8000)
    }

    private suspend fun engine() {
        var model: Model? = null; var rec: Recognizer? = null; var ar: AudioRecord? = null
        try {
            val m = ModelManager.info(this)
            if (!ModelManager.ready(this, m)) { fail("نموذج الصوت غير محمّل، افتح التطبيق وشغّل من جديد"); return }

            val tr = translator
            if (tr != null) {
                val dl = CompletableDeferred<Boolean>()
                tr.downloadModelIfNeeded(DownloadConditions.Builder().build())
                    .addOnSuccessListener { dl.complete(true) }.addOnFailureListener { dl.complete(false) }
                if (!dl.await()) { fail("تعذر تحميل نموذج الترجمة، تأكد من الإنترنت"); return }
            }

            model = withContext(Dispatchers.IO) { Model(ModelManager.dir(this@CaptionService, m).absolutePath) }
            rec = Recognizer(model, 16000f)
            val cfg = AudioPlaybackCaptureConfiguration.Builder(projection!!)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA).addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN).build()
            val fmt = AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(16000).setChannelMask(AudioFormat.CHANNEL_IN_MONO).build()
            ar = AudioRecord.Builder().setAudioFormat(fmt).setAudioPlaybackCaptureConfig(cfg)
                .setBufferSizeInBytes(16000 * 2 * 2).build()
            if (ar.state != AudioRecord.STATE_INITIALIZED) { fail("تعذر بدء التقاط الصوت على هذا الجهاز"); return }
            ar.startRecording(); show("الترجمة جاهزة ✓")

            val buf = ShortArray(2048)
            var emitted = 0   // عدد كلمات الجملة الحالية اللي أُرسلت للترجمة
            var lastSound = System.currentTimeMillis(); var warned = false
            while (scope.isActive) {
                val n = ar.read(buf, 0, buf.size)
                if (n < 0) { fail("انقطع التقاط الصوت"); return }
                if (n == 0) continue

                var peak = 0
                for (i in 0 until n) { val a = abs(buf[i].toInt()); if (a > peak) peak = a }
                val now = System.currentTimeMillis()
                if (peak > 8) { lastSound = now; warned = false }
                else if (!warned && now - lastSound > 20000) {
                    warned = true
                    show("لا يصل صوت للتطبيق. قد يكون الفيديو متوقفاً أو أن التطبيق يمنع التقاط صوته")
                }

                val maxW = prefs().getInt("maxWords", 10)
                val prio = prefs().getInt("prio", 0)   // 0 سرعة، 1 متوازن، 2 دقة
                val chunk = when (prio) { 0 -> 5; 1 -> 7; else -> maxW - 1 }.coerceAtMost(maxW - 1).coerceAtLeast(4)
                val margin = when (prio) { 0 -> 0; 1 -> 1; else -> 2 }
                if (rec.acceptWaveForm(buf, n)) {
                    val t = JSONObject(rec.result).optString("text").trim()
                    if (t.isNotBlank()) {
                        val rest = t.split(" ").filter { it.isNotBlank() }.drop(emitted)
                        val parts = rest.chunked(chunk).toMutableList()
                        if (parts.size > 1 && parts.last().size < 3) {
                            val l = parts.removeAt(parts.lastIndex); parts[parts.lastIndex] = parts.last() + l
                        }
                        parts.forEach { emit(it.joinToString(" ")) }
                    }
                    emitted = 0
                } else {
                    val words = JSONObject(rec.partialResult).optString("partial").trim()
                        .split(" ").filter { it.isNotBlank() }
                    // ننتظر كلمتين زيادة عشان تثبت الكلمات قبل الترجمة
                    while (words.size - emitted >= chunk + margin) {
                        emit(words.subList(emitted, emitted + chunk).joinToString(" ")); emitted += chunk
                    }
                }
            }
        } catch (e: Exception) {
            fail("حدث خطأ: ${e.message ?: "غير معروف"}")
        } finally {
            try { ar?.stop() } catch (_: Exception) {}
            ar?.release(); rec?.close(); model?.close()
        }
    }

    private fun emit(src: String) {
        val id = seq.incrementAndGet()
        // أمان: لو تأخرت ترجمة أكثر من 6 ثواني لا توقف باقي الجمل
        h.postDelayed({ if (id >= nextId && !results.containsKey(id)) deliver(id, "", "") }, 6000)
        val ctx = synchronized(history) { val c = history.takeLast(3).joinToString(" | "); history.add(src); if (history.size > 6) history.removeAt(0); c }
        val tr = translator
        if (tr == null) { deliver(id, src, ""); return }   // نفس اللغة: تفريغ نصي
        val p = prefs()
        if (p.getBoolean("smart", false) && !keyBad && !p.getString("apikey", "").isNullOrBlank()) {
            scope.launch(Dispatchers.IO) {
                val r = smartTranslate(src, ctx)
                if (r != null) deliver(id, r, src) else mlkit(id, src, tr)
            }
        } else mlkit(id, src, tr)
    }

    private fun mlkit(id: Long, src: String, tr: com.google.mlkit.nl.translate.Translator) {
        tr.translate(src).addOnSuccessListener { deliver(id, it, src) }.addOnFailureListener { deliver(id, "", src) }
    }

    /** ترجمة ذكية عبر Claude: تصحح أخطاء التعرف وتكتب ترجمة طبيعية مختصرة. */
    private fun smartTranslate(src: String, ctx: String): String? {
        try {
            val p = prefs()
            val key = p.getString("apikey", "")?.trim().orEmpty()
            val tgt = p.getString("tgt", "ar") ?: "ar"
            val sl = Langs.name(p.getString("src", "en") ?: "en"); val tl = Langs.name(tgt)
            val maxW = p.getInt("maxWords", 10)
            val style = if (tgt != "ar") "" else if (p.getInt("style", 0) == 1)
                " اكتبها بلهجة خليجية بيضاء مفهومة للجميع." else " اكتبها بعربية فصحى مبسطة وسلسة."
            val sys = "أنت مترجم فوري محترف لسطور فيديو مباشر (غالباً تعليق رياضي أو حوار). " +
                "النص المدخل ناتج تعرف آلي على الكلام: بدون ترقيم وقد فيه كلمات خاطئة أو مقطوعة. " +
                "افهم المعنى المقصود من السياق، ثم اكتب ترجمة إلى $tl طبيعية وواضحة كأن المتحدث يتكلمها أصلاً، " +
                "وبحد أقصى $maxW كلمات، مع حذف الحشو والتكرار.$style " +
                "أرجع الترجمة فقط بدون شرح أو علامات اقتباس."
            val user = (if (ctx.isNotBlank()) "السياق السابق: $ctx\n" else "") + "النص الحالي ($sl): $src"
            val body = JSONObject().put("model", "claude-haiku-5-5").put("max_tokens", 120).put("system", sys)
                .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", user)))
            val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
            c.requestMethod = "POST"; c.connectTimeout = 6000; c.readTimeout = 8000; c.doOutput = true
            c.setRequestProperty("x-api-key", key)
            c.setRequestProperty("anthropic-version", "2023-06-01")
            c.setRequestProperty("content-type", "application/json")
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            if (code == 401 || code == 403) { keyBad = true; show("مفتاح API غير صحيح، سيتم استخدام الترجمة العادية", "", 5000); return null }
            if (code != 200) return null
            val txt = c.inputStream.bufferedReader().readText()
            val out = JSONObject(txt).getJSONArray("content").getJSONObject(0).getString("text")
                .trim().trim('"', '«', '»', ' ')
            return out.ifBlank { null }
        } catch (e: Exception) { return null }
    }

    override fun onDestroy() {
        running = false; scope.cancel(); projection?.stop()
        prefs().unregisterOnSharedPreferenceChangeListener(listener)
        h.removeCallbacksAndMessages(null)
        if (::wm.isInitialized) box?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        translator?.close()
        super.onDestroy()
    }
}
