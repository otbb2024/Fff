package com.example.arcaptions

import android.annotation.TargetApi
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.media.*
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import org.vosk.LibVosk
import org.vosk.LogLevel
import org.vosk.Model
import org.vosk.Recognizer
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.abs
import kotlin.math.ceil

/**
 * محرك الترجمة الفورية (الإصدار 2):
 *  - يعرض الترجمة أثناء الكلام (بث مباشر) مثل ترجمة المسلسلات، بدون انتظار نهاية الجملة.
 *  - كل عرض لا يزيد عن 3 ثوانٍ.
 *  - تعرف تلقائي على اللغة: يختار اللغة ثم "يقفل" عليها لسرعة أعلى ويعيد الفحص عند تغيّر اللغة.
 */
class CaptionService : Service() {
    companion object { @Volatile var running = false }

    private class Eng(val code: String, val model: Model, val rec: Recognizer)
    private class Out(val final: Boolean, val text: String, val conf: Double)

    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var projection: MediaProjection? = null
    private lateinit var wm: WindowManager
    private var box: LinearLayout? = null
    private var arTv: TextView? = null
    private var enTv: TextView? = null
    private var lp: WindowManager.LayoutParams? = null
    private val h = Handler(Looper.getMainLooper())
    private val clearRun = Runnable { box?.visibility = View.INVISIBLE }
    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> h.post { restyle() } }

    // ---- حالة العرض (الخيط الرئيسي فقط) ----
    private val queue = ArrayDeque<Pair<String, String>>()
    private var playing = false
    private val playRun = Runnable { playNext() }
    private var shownAt = 0L
    private var shownSrc = ""
    private var finalSeq = 0L
    private var nextFinal = 1L
    private val results = HashMap<Long, Pair<String, String>>()
    private var segId = 0L
    private var reqId = 0L
    private var lastShownReq = 0L
    private var liveBusy = false
    private var livePending: Pair<String, String>? = null
    private var lastLiveAt = 0L
    private val liveRun = Runnable { pumpLive() }
    private val history = ArrayList<String>()

    @Volatile private var keyBad = false
    private val translators = ConcurrentHashMap<String, Translator>()
    private var tgt = "ar"
    private var cands: List<String> = listOf("en")
    private var micMode = false

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, f: Int, id: Int): Int {
        if (intent?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        micMode = intent?.getBooleanExtra("mic", false) == true || Build.VERSION.SDK_INT < 29
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("cap", "الترجمة", NotificationManager.IMPORTANCE_LOW))
        val stopPi = PendingIntent.getService(this, 0, Intent(this, CaptionService::class.java).setAction("STOP"),
            PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "cap").setContentTitle("ترجمان يعمل")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_media_pause), "إيقاف", stopPi).build())
            .build()
        try {
            val type = if (micMode) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            if (Build.VERSION.SDK_INT >= 30 || (Build.VERSION.SDK_INT == 29 && !micMode)) startForeground(1, n, type)
            else startForeground(1, n)
        } catch (e: Exception) { stopSelf(); return START_NOT_STICKY }

        @Suppress("DEPRECATION")
        val data = intent?.getParcelableExtra<Intent>("data")
        if ((!micMode && data == null) || !Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        if (!micMode) {
            try {
                val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                projection = mpm.getMediaProjection(intent!!.getIntExtra("code", 0), data!!)
                projection?.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }, h)
            } catch (e: Exception) { stopSelf(); return START_NOT_STICKY }
        }
        try { LibVosk.setLogLevel(LogLevel.WARNINGS) } catch (_: Throwable) {}
        tgt = prefs().getString("tgt", "ar") ?: "ar"
        cands = Langs.candidates(this)
        for (code in cands) if (code != tgt) translators[code] = Translation.getClient(
            TranslatorOptions.Builder().setSourceLanguage(code).setTargetLanguage(tgt).build())
        running = true
        buildOverlay(); prefs().registerOnSharedPreferenceChangeListener(listener)
        show("جاري تجهيز الترجمة...")
        scope.launch { engine() }
        return START_NOT_STICKY
    }

    // ------------------------------------------------------------------ الواجهة العائمة

    private fun buildOverlay() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        arTv = TextView(this).apply { gravity = Gravity.CENTER; textDirection = View.TEXT_DIRECTION_FIRST_STRONG }
        enTv = TextView(this).apply { gravity = Gravity.CENTER; textDirection = View.TEXT_DIRECTION_FIRST_STRONG }
        box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(28), dp(14), dp(28), dp(14)); visibility = View.INVISIBLE
            addView(enTv); addView(arTv)
        }
        lp = WindowManager.LayoutParams((resources.displayMetrics.widthPixels * 0.85f).toInt(),
            ViewGroup.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT)
        wm.addView(box, lp)
        restyle()
    }

    private fun restyle() {
        val b = box ?: return
        val s = loadStyle()
        applyStyle(s, b, arTv!!, enTv!!)
        lp!!.gravity = Gravity.CENTER_HORIZONTAL or when (s.pos) { 0 -> Gravity.BOTTOM; 1 -> Gravity.CENTER_VERTICAL; else -> Gravity.TOP }
        lp!!.y = if (isTv()) dp(56) else dp(48)
        try { wm.updateViewLayout(b, lp) } catch (_: Exception) {}
    }

    /** رسائل النظام: تُعرض فوراً وتلغي الطابور. */
    private fun show(ar: String, en: String = "", ms: Long = 6000) {
        h.post { queue.clear(); h.removeCallbacks(playRun); playing = false; showNow(ar, en, ms) }
    }

    private fun showNow(ar: String, en: String, ms: Long) {
        if (ar.isBlank()) { box?.visibility = View.INVISIBLE; return }
        arTv?.text = ar; enTv?.text = en
        enTv?.visibility = if (en.isBlank() || !loadStyle().showEn) View.GONE else View.VISIBLE
        box?.visibility = View.VISIBLE
        shownAt = SystemClock.uptimeMillis(); shownSrc = en
        h.removeCallbacks(clearRun); h.postDelayed(clearRun, ms)
    }

    // ------------------------------------------------------------------ أدوات النص

    private fun maxW() = prefs().getInt("maxWords", 8)
    private fun prio() = prefs().getInt("prio", 0)   // 0 فوري، 1 متوازن، 2 دقة

    private fun units(s: String): Int =
        if (s.contains(' ')) s.split(' ').count { it.isNotBlank() } else maxOf(1, s.length / 3)

    /** آخر maxW كلمات (للعرض الحي أثناء الكلام). */
    private fun tail(s: String, mw: Int): String {
        val t = s.trim()
        if (!t.contains(' ')) return if (t.length <= mw * 3) t else t.takeLast(mw * 3)
        val w = t.split(' ').filter { it.isNotBlank() }
        return if (w.size <= mw) t else w.takeLast(mw).joinToString(" ")
    }

    /** يقسّم النص لصفحات متساوية، كل صفحة لا تزيد عن mw كلمات. */
    private fun pages(s: String, mw: Int): List<String> {
        val t = s.trim()
        if (t.isEmpty()) return emptyList()
        if (!t.contains(' ')) {
            val lim = mw * 3
            if (t.length <= lim) return listOf(t)
            val n = ceil(t.length / lim.toDouble()).toInt()
            return t.chunked(ceil(t.length / n.toDouble()).toInt())
        }
        val w = t.split(' ').filter { it.isNotBlank() }
        if (w.size <= mw) return listOf(w.joinToString(" "))
        val cnt = ceil(w.size / mw.toDouble()).toInt()
        val per = ceil(w.size / cnt.toDouble()).toInt()
        return w.chunked(per).map { it.joinToString(" ") }
    }

    // ------------------------------------------------------------------ الترجمة

    private fun smartAvailable(): Boolean {
        val p = prefs()
        return p.getBoolean("smart", false) && !keyBad && !p.getString("apikey", "").isNullOrBlank()
    }

    /** يترجم ويرجّع النتيجة على الخيط الرئيسي (null = فشل). */
    private fun translateNow(src: String, code: String, cb: (String?) -> Unit) {
        if (code == tgt) { cb(src); return }
        val tr = translators[code]
        if (tr == null) {
            if (smartAvailable()) {
                scope.launch(Dispatchers.IO) { val r = smartTranslate(src, "", code); h.post { cb(r) } }
            } else cb(null)
            return
        }
        tr.translate(src).addOnSuccessListener { cb(it) }.addOnFailureListener { cb(null) }
    }

    // ---- عرض حي أثناء الكلام ----
    private fun liveGap() = if (prio() == 0) 250L else 450L

    private fun onPartial(src: String, code: String) {
        if (prio() >= 2) return
        if (units(src) < (if (prio() == 0) 2 else 4)) return
        if (playing) {
            val canPreempt = queue.isEmpty() && SystemClock.uptimeMillis() - shownAt >= 1100
            if (!canPreempt) return
        }
        livePending = src to code
        pumpLive()
    }

    private fun pumpLive() {
        if (liveBusy) return
        val p = livePending ?: return
        val wait = lastLiveAt + liveGap() - SystemClock.uptimeMillis()
        if (wait > 0) { h.removeCallbacks(liveRun); h.postDelayed(liveRun, wait); return }
        livePending = null; liveBusy = true; lastLiveAt = SystemClock.uptimeMillis()
        val seg = segId; val id = ++reqId
        translateNow(p.first, p.second) { out ->
            liveBusy = false
            val canShow = seg == segId && id > lastShownReq && !out.isNullOrBlank() &&
                (!playing || (queue.isEmpty() && SystemClock.uptimeMillis() - shownAt >= 1100))
            if (canShow) {
                lastShownReq = id
                queue.clear(); h.removeCallbacks(playRun); playing = false
                showNow(tail(out!!, maxW()), tail(p.first, maxW()), 3000)
            }
            if (livePending != null) pumpLive()
        }
    }

    // ---- جملة مكتملة ----
    private fun onFinal(src: String, code: String) {
        segId++; livePending = null
        val ctx = history.takeLast(3).joinToString(" | ")
        history.add(src); if (history.size > 6) history.removeAt(0)
        val id = ++finalSeq
        h.postDelayed({ if (id >= nextFinal && !results.containsKey(id)) deliverFinal(id, null) }, 5000)
        translateNow(src, code) { out ->
            val text = out ?: src
            deliverFinal(id, text to src)
            if (!out.isNullOrBlank() && code != tgt && smartAvailable()) {
                val single = pages(text, maxW()).size == 1
                scope.launch(Dispatchers.IO) {
                    val r = smartTranslate(src, ctx, code)
                    if (r != null && single) h.post {
                        if (shownSrc == src && box?.visibility == View.VISIBLE) arTv?.text = tail(r, maxW())
                    }
                }
            }
        }
    }

    /** يحافظ على ترتيب الجمل حتى لو وصلت الترجمات متأخرة. */
    private fun deliverFinal(id: Long, v: Pair<String, String>?) {
        if (id < nextFinal) return
        results[id] = v ?: ("" to "")
        while (true) {
            val r = results.remove(nextFinal) ?: break
            if (r.first.isNotBlank()) showFinal(r.first, r.second)
            nextFinal++
        }
    }

    private fun showFinal(text: String, src: String) {
        val pgs = pages(text, maxW())
        pgs.forEachIndexed { i, p -> queue.addLast(p to (if (i == 0) src else "")) }
        while (queue.size > 3) queue.removeFirst()   // نلحق البث المباشر
        if (!playing) { h.removeCallbacks(playRun); playNext() }
    }

    private fun playNext() {
        val n = queue.removeFirstOrNull()
        if (n == null) { playing = false; h.removeCallbacks(clearRun); h.postDelayed(clearRun, 300); return }
        playing = true
        showNow(n.first, n.second, 60000)
        var ms = (units(n.first) * 300L + 700L).coerceIn(1200L, 3000L)   // كل عرض 3 ثواني كحد أقصى
        if (queue.isNotEmpty()) ms = (ms * 0.6).toLong().coerceAtLeast(900L)
        h.postDelayed(playRun, ms)
    }

    private fun fail(msg: String) {
        show(msg, "", 8000)
        h.postDelayed({ stopSelf() }, 8000)
    }

    // ------------------------------------------------------------------ التعرف على الصوت

    private fun score(j: JSONObject): Double {
        val a = j.optJSONArray("result") ?: return 0.0
        if (a.length() == 0) return 0.0
        var s = 0.0
        for (k in 0 until a.length()) s += a.getJSONObject(k).optDouble("conf", 0.0)
        return s / a.length() * minOf(1.0, a.length() / 3.0)
    }

    private fun feed(e: Eng, buf: ShortArray, n: Int): Out =
        if (e.rec.acceptWaveForm(buf, n)) {
            val j = JSONObject(e.rec.result)
            Out(true, j.optString("text").trim(), score(j))
        } else Out(false, JSONObject(e.rec.partialResult).optString("partial").trim(), 0.0)

    private suspend fun dlTranslator(tr: Translator): Boolean {
        val dl = CompletableDeferred<Boolean>()
        tr.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener { dl.complete(true) }.addOnFailureListener { dl.complete(false) }
        if (!dl.await()) return false
        // تسخين المترجم عشان أول جملة ما تتأخر
        val w = CompletableDeferred<Boolean>()
        tr.translate("hello").addOnCompleteListener { w.complete(true) }
        withTimeoutOrNull(4000) { w.await() }
        return true
    }

    private suspend fun loadModels(): List<Eng> = coroutineScope {
        cands.map { code ->
            async(Dispatchers.IO) {
                val info = ModelManager.infoFor(this@CaptionService, code)
                val m = Model(ModelManager.dir(this@CaptionService, info).absolutePath)
                val r = Recognizer(m, 16000f)
                if (cands.size > 1) r.setWords(true)
                // تسخين المحرك: أول معالجة تكون بطيئة، فنسوّيها قبل ما نقول "جاهزة"
                r.acceptWaveForm(ShortArray(4000), 4000); r.reset()
                Eng(code, m, r)
            }
        }.awaitAll()
    }

    private fun micRecord(): AudioRecord {
        val minBuf = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        return AudioRecord(MediaRecorder.AudioSource.MIC, 16000, AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, 16000 * 2))
    }

    @TargetApi(29)
    private fun playbackRecord(): AudioRecord {
        val cfg = AudioPlaybackCaptureConfiguration.Builder(projection!!)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA).addMatchingUsage(AudioAttributes.USAGE_GAME)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN).build()
        val fmt = AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(16000).setChannelMask(AudioFormat.CHANNEL_IN_MONO).build()
        return AudioRecord.Builder().setAudioFormat(fmt).setAudioPlaybackCaptureConfig(cfg)
            .setBufferSizeInBytes(16000 * 2).build()
    }

    private suspend fun engine() {
        val engs = ArrayList<Eng>(); var ar: AudioRecord? = null
        try {
            for (code in cands) {
                if (!ModelManager.ready(this, ModelManager.infoFor(this, code))) {
                    fail("نموذج الصوت (${Langs.name(code)}) غير محمّل، افتح التطبيق وشغّل من جديد"); return
                }
            }
            val smartOn = smartAvailable()

            // تحميل نماذج الترجمة وتحميل نماذج الصوت بالتوازي (أسرع بكثير)
            val (trRes, loaded) = coroutineScope {
                val t = async { translators.entries.toList().map { (c, tr) -> c to async { dlTranslator(tr) } }.map { it.first to it.second.await() } }
                val m = async { loadModels() }
                t.await() to m.await()
            }
            engs.addAll(loaded)
            for ((code, ok) in trRes) if (!ok) {
                if (smartOn) translators.remove(code)?.close()
                else { fail("تعذر تحميل نموذج الترجمة، تأكد من الإنترنت"); return }
            }

            val audio: AudioRecord = if (micMode || projection == null) micRecord() else playbackRecord()
            ar = audio
            if (audio.state != AudioRecord.STATE_INITIALIZED) { fail("تعذر بدء التقاط الصوت على هذا الجهاز"); return }
            audio.startRecording()
            show("الترجمة جاهزة ✓", "", 1500)

            val buf = ShortArray(1600)   // 100 ملّي ثانية
            var locked: Eng? = if (engs.size == 1) engs[0] else null
            var lockedAt = 0L; var lowCount = 0
            val pend = HashMap<Int, Out>(); var decideAt = 0L
            var lastPartial = ""
            var lastSound = System.currentTimeMillis(); var warned = false

            while (scope.isActive) {
                val n = audio.read(buf, 0, buf.size)
                if (n < 0) { fail("انقطع التقاط الصوت"); return }
                if (n == 0) continue

                var peak = 0
                for (i in 0 until n) { val a = abs(buf[i].toInt()); if (a > peak) peak = a }
                val now = System.currentTimeMillis()
                if (peak > 8) { lastSound = now; warned = false }
                else if (!warned && now - lastSound > 20000) {
                    warned = true
                    show("لا يصل صوت للتطبيق. تأكد أن الفيديو شغّال، أو جرّب خيار الميكروفون من إعدادات التطبيق")
                }

                val lk = locked
                if (lk != null) {
                    // ---- المسار السريع: محرك واحد ----
                    val o = feed(lk, buf, n)
                    if (o.final) {
                        lastPartial = ""
                        if (o.text.isNotBlank()) {
                            val t = o.text; val c = lk.code
                            h.post { onFinal(t, c) }
                            if (engs.size > 1) {
                                if (o.conf < 0.55 && units(t) >= 2) lowCount++ else lowCount = 0
                                if (lowCount >= 2 || now - lockedAt > 60000) {
                                    locked = null; lowCount = 0   // إعادة فحص اللغة
                                    for (e in engs) e.rec.reset()
                                }
                            }
                        }
                    } else if (o.text.isNotEmpty() && o.text != lastPartial) {
                        lastPartial = o.text
                        val t = o.text; val c = lk.code
                        h.post { onPartial(t, c) }
                    }
                } else {
                    // ---- تعرف تلقائي: كل المحركات تسمع بالتوازي، ونختار الأعلى ثقة ----
                    val outs = coroutineScope { engs.map { e -> async { feed(e, buf, n) } }.awaitAll() }
                    for ((i, o) in outs.withIndex()) if (o.final && o.text.isNotBlank()) pend[i] = o
                    if (pend.isNotEmpty()) {
                        if (decideAt == 0L) decideAt = now + 350
                        if (now >= decideAt) {
                            val best = pend.maxByOrNull { it.value.conf }
                            if (best != null) {
                                locked = engs[best.key]; lockedAt = now; lowCount = 0; lastPartial = ""
                                val t = best.value.text; val c = engs[best.key].code
                                h.post { onFinal(t, c) }
                            }
                            pend.clear(); decideAt = 0L
                        }
                    }
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            fail("حدث خطأ: ${e.message ?: "غير معروف"}")
        } finally {
            try { ar?.stop() } catch (_: Exception) {}
            ar?.release()
            for (e in engs) { try { e.rec.close() } catch (_: Throwable) {}; try { e.model.close() } catch (_: Throwable) {} }
        }
    }

    // ------------------------------------------------------------------ ترجمة ذكية (اختياري)

    /** ترجمة ذكية عبر Claude: تصحح أخطاء التعرف وتكتب ترجمة طبيعية مختصرة. */
    private fun smartTranslate(src: String, ctx: String, code: String): String? {
        try {
            val p = prefs()
            val key = p.getString("apikey", "")?.trim().orEmpty()
            val sl = Langs.name(code); val tl = Langs.name(tgt)
            val mw = maxW()
            val style = if (tgt != "ar") "" else if (p.getInt("style", 0) == 1)
                " اكتبها بلهجة خليجية بيضاء مفهومة للجميع." else " اكتبها بعربية فصحى مبسطة وسلسة."
            val sys = "أنت مترجم فوري محترف لسطور مسلسل أو فيديو مباشر. " +
                "النص المدخل ناتج تعرف آلي على الكلام: بدون ترقيم وقد فيه كلمات خاطئة أو مقطوعة. " +
                "افهم المعنى المقصود من السياق، ثم اكتب ترجمة إلى $tl طبيعية وواضحة كأن المتحدث يتكلمها أصلاً " +
                "مثل ترجمة المسلسلات، وبحد أقصى $mw كلمات، مع حذف الحشو والتكرار.$style " +
                "أرجع الترجمة فقط بدون شرح أو علامات اقتباس."
            val user = (if (ctx.isNotBlank()) "السياق السابق: $ctx\n" else "") + "النص الحالي ($sl): $src"
            val body = JSONObject().put("model", "claude-haiku-5-5").put("max_tokens", 120).put("system", sys)
                .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", user)))
            val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
            c.requestMethod = "POST"; c.connectTimeout = 4000; c.readTimeout = 5000; c.doOutput = true
            c.setRequestProperty("x-api-key", key)
            c.setRequestProperty("anthropic-version", "2023-06-01")
            c.setRequestProperty("content-type", "application/json")
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val rc = c.responseCode
            if (rc == 401 || rc == 403) { keyBad = true; show("مفتاح API غير صحيح، سيتم استخدام الترجمة العادية", "", 5000); return null }
            if (rc != 200) return null
            val txt = c.inputStream.bufferedReader().readText()
            val out = JSONObject(txt).getJSONArray("content").getJSONObject(0).getString("text")
                .trim().trim('"', '«', '»', ' ')
            return out.ifBlank { null }
        } catch (e: Exception) { return null }
    }

    override fun onDestroy() {
        running = false; scope.cancel(); projection?.stop()
        prefs().unregisterOnSharedPreferenceChangeListener(listener)
        h.removeCallbacksAndMessages(null)
        if (::wm.isInitialized) box?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        for (t in translators.values) { try { t.close() } catch (_: Exception) {} }
        super.onDestroy()
    }
}
