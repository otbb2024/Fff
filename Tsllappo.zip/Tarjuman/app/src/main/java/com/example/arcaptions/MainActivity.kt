package com.example.arcaptions

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions

class MainActivity : Activity() {
    private val BG = 0xFF0B0F24.toInt(); private val CARD = 0xFF161B3A.toInt()
    private val ACC = 0xFF14B8A6.toInt(); private val GOLD = 0xFFFFC857.toInt()
    private val MUTED = 0xFF9AA3C7.toInt(); private val CHIP = 0xFF232A55.toInt()
    private lateinit var root: LinearLayout
    private lateinit var pFrame: FrameLayout
    private lateinit var pBox: LinearLayout
    private lateinit var pAr: TextView
    private lateinit var pEn: TextView
    private lateinit var startBtn: TextView
    private lateinit var statusTv: TextView
    private lateinit var progress: ProgressBar
    private var busy = false

    private fun rr(c: Int, r: Int = 14, st: Int = 0, sc: Int = 0) = GradientDrawable().apply {
        setColor(c); cornerRadius = dp(r).toFloat(); if (st > 0) setStroke(dp(st), sc)
    }
    private fun oval(c: Int, st: Int, sc: Int) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL; setColor(c); setStroke(dp(st), sc)
    }
    private fun focusable(n: Drawable, f: Drawable) = StateListDrawable().apply {
        addState(intArrayOf(android.R.attr.state_focused), f); addState(intArrayOf(), n)
    }
    private fun put(k: String, v: Any) {
        val e = prefs().edit()
        when (v) { is Int -> e.putInt(k, v); is Boolean -> e.putBoolean(k, v) }
        e.apply(); refresh()
    }
    private fun txt(t: String, sp: Float, c: Int, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = sp; setTextColor(c); if (bold) typeface = android.graphics.Typeface.DEFAULT_BOLD
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = BG; window.navigationBarColor = BG
        val scroll = ScrollView(this).apply { setBackgroundColor(BG); isFillViewport = true }
        val side = (resources.displayMetrics.widthPixels * 0.12f).toInt().coerceAtLeast(dp(20))
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(side, dp(32), side, dp(48))
        }
        scroll.addView(root); setContentView(scroll)

        // الهيدر: الشعار + الاسم
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(ImageView(this).apply { setImageResource(R.drawable.ic_logo) }, LinearLayout.LayoutParams(dp(84), dp(84)))
        val names = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), 0, dp(18), 0) }
        names.addView(txt("ترجمان", 40f, Color.WHITE, true))
        names.addView(txt("ترجمة فورية لكل ما تشاهده", 16f, MUTED))
        head.addView(names); root.addView(head)

        // زر التشغيل
        startBtn = TextView(this).apply {
            textSize = 22f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            typeface = android.graphics.Typeface.DEFAULT_BOLD; isFocusable = true; isClickable = true
            setOnClickListener { if (busy) return@setOnClickListener; if (CaptionService.running) { stopService(Intent(this@MainActivity, CaptionService::class.java)); CaptionService.running = false; refreshBtn(); setStatus("") } else begin() }
        }
        root.addView(startBtn, lp(dp(64), dp(24)))
        startBtn.requestFocus()
        statusTv = txt("", 15f, MUTED).apply { gravity = Gravity.CENTER; visibility = View.GONE }
        root.addView(statusTv, lp(ViewGroup.LayoutParams.WRAP_CONTENT, dp(12)))
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; visibility = View.GONE; progressTintList = ColorStateList.valueOf(ACC)
        }
        root.addView(progress, lp(dp(8), dp(8)))

        // المعاينة
        root.addView(txt("معاينة مباشرة", 15f, GOLD, true), lp(ViewGroup.LayoutParams.WRAP_CONTENT, dp(24)))
        pFrame = FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF27306B.toInt(), 0xFF0B0F24.toInt())).apply { cornerRadius = dp(20).toFloat() }
        }
        pAr = TextView(this).apply { text = "أهلاً بعودتك، من الجيد رؤيتك مجدداً."; gravity = Gravity.CENTER }
        pEn = TextView(this).apply { text = "Welcome back, it's good to see you again."; gravity = Gravity.CENTER }
        pBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(12), dp(20), dp(12))
            layoutDirection = View.LAYOUT_DIRECTION_RTL; addView(pEn); addView(pAr)
        }
        pFrame.addView(pBox)
        root.addView(pFrame, lp(dp(220), dp(8)))

        // الإعدادات
        val s = loadStyle()
        var c = card("اللغات")
        val src = prefs().getString("src", "en") ?: "en"; val tgt = prefs().getString("tgt", "ar") ?: "ar"
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
        sub(c, "لغة الصوت (المنطوقة في الفيديو)")
        c.addView(btn("${Langs.name(src)}  ▾") { pick("src", Langs.sources(), src) }, lp(wrap, dp(4)))
        sub(c, "لغة الترجمة (المعروضة)")
        c.addView(btn("${Langs.name(tgt)}  ▾") { pick("tgt", Langs.targets(), tgt) }, lp(wrap, dp(4)))
        if (Langs.SOURCES.containsKey(tgt) && Langs.SOURCES.containsKey(src) && src != tgt)
            c.addView(btn("⇄  تبديل اللغتين") { swapLangs(src, tgt) }, lp(wrap, dp(10)))
        if (src == tgt) c.addView(txt("نفس اللغة: يظهر تفريغ نصي للكلام بدون ترجمة", 14f, GOLD).apply { setPadding(0, dp(10), 0, 0) })

        c = card("طول الترجمة")
        seek(c, "أقصى عدد كلمات في العرض الواحد", 5, 14, "maxWords", 10, 1, "")
        c.addView(txt("كل ما قلّ الرقم صارت الترجمة أقصر وأسرع.", 13f, MUTED).apply { setPadding(0, dp(6), 0, 0) })

        c = card("الترجمة الذكية (اختياري)")
        c.addView(txt("تعطي ترجمة طبيعية وواضحة وتصحح أخطاء الصوت. تحتاج إنترنت ومفتاح API من console.anthropic.com، ويُرسل النص المنطوق فقط لخوادم Anthropic، والاستخدام يُحاسب على حسابك.", 13f, MUTED).apply { setPadding(0, dp(6), 0, 0) })
        chips(c, listOf("مفعّلة", "متوقفة"), if (prefs().getBoolean("smart", false)) 0 else 1) { put("smart", it == 0) }
        val keyBox = EditText(this).apply {
            hint = "الصق مفتاح API هنا"; setHintTextColor(MUTED); setTextColor(Color.WHITE)
            setText(prefs().getString("apikey", "")); isSingleLine = true
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            background = focusable(rr(CHIP, 12), rr(CHIP, 12, 3, GOLD)); setPadding(dp(14), dp(12), dp(14), dp(12))
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(e: Editable?) { prefs().edit().putString("apikey", e.toString().trim()).apply() }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        }
        c.addView(keyBox, lp(ViewGroup.LayoutParams.WRAP_CONTENT, dp(12)))
        if (tgt == "ar") { sub(c, "أسلوب العربية"); chips(c, listOf("فصحى مبسطة", "لهجة خليجية"), prefs().getInt("style", 0)) { put("style", it) } }

        c = card("الخط")
        chips(c, fontNames(), s.font) { put("font", it) }
        chips(c, listOf("عريض", "عادي"), if (s.bold) 0 else 1) { put("bold", it == 0) }
        seek(c, "حجم الخط", 18, 64, "size", 32, 2, "")

        c = card("لون النص")
        colorRow(c, TEXT_COLORS, TEXT_COLORS.indexOf(s.color)) { put("color", TEXT_COLORS[it]) }

        c = card("الخلفية")
        colorRow(c, BG_COLORS, BG_COLORS.indexOf(s.bg)) { put("bg", BG_COLORS[it]) }
        seek(c, "الشفافية", 0, 100, "opacity", 70, 5, "%")

        c = card("المظهر والموضع")
        sub(c, "موضع الترجمة"); chips(c, POS_NAMES, s.pos) { put("pos", it) }
        sub(c, "ظل النص"); chips(c, listOf("مفعّل", "معطّل"), if (s.shadow) 0 else 1) { put("shadow", it == 0) }
        sub(c, "عرض النص الإنجليزي الأصلي"); chips(c, listOf("نعم", "لا"), if (s.showEn) 0 else 1) { put("showEn", it == 0) }

        c = card("التعرف على الكلام")
        sub(c, "نموذج الصوت للغة ${Langs.name(src)} (يُحمَّل مرة واحدة ثم يعمل بدون إنترنت)")
        val opts = ModelManager.options(this)
        chips(c, opts.map { it.label() }, prefs().getInt("acc", 0).coerceIn(0, opts.size - 1)) { put("acc", it) }
        c.addView(btn("حذف النماذج المحمّلة لتوفير المساحة") {
            if (CaptionService.running) Toast.makeText(this, "أوقف الترجمة أولاً", Toast.LENGTH_SHORT).show()
            else { ModelManager.deleteAll(this); setStatus("تم حذف النماذج، ستُحمَّل مجدداً عند التشغيل") }
        }, lp(ViewGroup.LayoutParams.WRAP_CONTENT, dp(14)))

        c = card("ملاحظات")
        c.addView(txt("• أول تشغيل لكل لغة يحتاج إنترنت لتحميل النماذج، وبعدها تعمل بدون إنترنت.\n" +
            "• الصوت يدعم ${Langs.sources().size} لغة، والترجمة تدعم ${Langs.targets().size} لغة.\n" +
            "• بعض التطبيقات المحمية تمنع التقاط صوتها، وقد لا تظهر الترجمة معها.\n" +
            "• الترجمة تقريبية وتتأخر ثوانٍ قليلة.", 14f, MUTED).apply { setPadding(0, dp(8), 0, 0) })

        root.addView(btn("استعادة الإعدادات الافتراضية") { prefs().edit().clear().apply(); recreate() },
            lp(ViewGroup.LayoutParams.WRAP_CONTENT, dp(24)))
        refresh()
    }

    private fun lp(h: Int, top: Int) = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h).apply { topMargin = top }

    private fun card(title: String): LinearLayout {
        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = rr(CARD, 20); setPadding(dp(20), dp(16), dp(20), dp(20)) }
        c.addView(txt(title, 17f, GOLD, true))
        root.addView(c, lp(ViewGroup.LayoutParams.WRAP_CONTENT, dp(16))); return c
    }
    private fun sub(c: LinearLayout, t: String) = c.addView(txt(t, 14f, MUTED).apply { setPadding(0, dp(12), 0, dp(4)) })

    private fun chips(card: LinearLayout, labels: List<String>, sel: Int, onSel: (Int) -> Unit) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(10), 0, 0) }
        val views = ArrayList<TextView>()
        fun paint(s: Int) = views.forEachIndexed { i, v ->
            val col = if (i == s) ACC else CHIP
            v.background = focusable(rr(col, 12), rr(col, 12, 3, GOLD))
            v.setTextColor(if (i == s) Color.WHITE else MUTED)
        }
        labels.forEachIndexed { i, l ->
            val v = txt(l, 17f, MUTED).apply {
                gravity = Gravity.CENTER; isFocusable = true; isClickable = true
                setPadding(dp(6), dp(12), dp(6), dp(12)); setOnClickListener { paint(i); onSel(i) }
            }
            row.addView(v, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(4), 0, dp(4), 0) })
            views.add(v)
        }
        paint(sel); card.addView(row)
    }

    private fun colorRow(card: LinearLayout, colors: IntArray, sel: Int, onSel: (Int) -> Unit) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(12), 0, dp(4)) }
        val views = ArrayList<View>()
        fun paint(s: Int) = views.forEachIndexed { i, v ->
            v.background = focusable(oval(colors[i], if (i == s) 4 else 1, if (i == s) Color.WHITE else 0x66FFFFFF), oval(colors[i], 4, GOLD))
        }
        colors.forEachIndexed { i, _ ->
            val v = View(this).apply { isFocusable = true; isClickable = true; setOnClickListener { paint(i); onSel(i) } }
            row.addView(v, LinearLayout.LayoutParams(dp(44), dp(44)).apply { setMargins(dp(6), 0, dp(6), 0) }); views.add(v)
        }
        paint(sel); card.addView(row)
    }

    private fun seek(card: LinearLayout, title: String, min: Int, max: Int, key: String, def: Int, step: Int, unit: String) {
        val cur = prefs().getInt(key, def)
        val label = txt("$title: $cur$unit", 15f, MUTED).apply { setPadding(0, dp(14), 0, 0) }
        val sb = SeekBar(this).apply {
            this.max = max - min; progress = cur - min; keyProgressIncrement = step
            progressTintList = ColorStateList.valueOf(ACC); thumbTintList = ColorStateList.valueOf(GOLD)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { label.text = "$title: ${p + min}$unit"; put(key, p + min) }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        card.addView(label); card.addView(sb)
    }

    private fun refresh() {
        if (!::pBox.isInitialized) return
        val s = loadStyle(); applyStyle(s, pBox, pAr, pEn)
        pEn.visibility = if (s.showEn) View.VISIBLE else View.GONE
        pBox.layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            when (s.pos) { 0 -> Gravity.BOTTOM; 1 -> Gravity.CENTER_VERTICAL; else -> Gravity.TOP }).apply { setMargins(dp(24), dp(20), dp(24), dp(20)) }
    }

    private fun refreshBtn() {
        val on = CaptionService.running
        startBtn.text = if (on) "■  إيقاف الترجمة" else "▶  تشغيل الترجمة"
        val col = if (on) 0xFFE5484D.toInt() else ACC
        startBtn.background = focusable(rr(col, 18), rr(col, 18, 3, GOLD))
    }

    private fun btn(t: String, onClick: () -> Unit) = txt(t, 17f, MUTED).apply {
        gravity = Gravity.CENTER; isFocusable = true; isClickable = true
        background = focusable(rr(CHIP, 14), rr(CHIP, 14, 3, GOLD)); setPadding(0, dp(14), 0, dp(14))
        setOnClickListener { onClick() }
    }

    private fun applyLangChange() {
        if (CaptionService.running) {
            stopService(Intent(this, CaptionService::class.java)); CaptionService.running = false
            Toast.makeText(this, "تم إيقاف الترجمة، شغّلها من جديد لتطبيق اللغة", Toast.LENGTH_LONG).show()
        }
        recreate()
    }

    private fun pick(key: String, codes: List<String>, cur: String) {
        val names = codes.map { Langs.name(it) }.toTypedArray<CharSequence>()
        android.app.AlertDialog.Builder(this)
            .setTitle(if (key == "src") "لغة الصوت" else "لغة الترجمة")
            .setSingleChoiceItems(names, codes.indexOf(cur)) { d, w ->
                d.dismiss()
                if (codes[w] != cur) {
                    val e = prefs().edit().putString(key, codes[w])
                    if (key == "src") e.putInt("acc", 0)
                    e.apply(); applyLangChange()
                }
            }.show()
    }

    private fun swapLangs(src: String, tgt: String) {
        prefs().edit().putString("src", tgt).putString("tgt", src).putInt("acc", 0).apply(); applyLangChange()
    }

    private fun setStatus(t: String, pct: Int = -1, err: Boolean = false) {
        if (isDestroyed) return
        statusTv.text = t; statusTv.setTextColor(if (err) 0xFFFF8A80.toInt() else MUTED)
        statusTv.visibility = if (t.isEmpty()) View.GONE else View.VISIBLE
        progress.visibility = if (pct >= 0) View.VISIBLE else View.GONE
        if (pct >= 0) progress.progress = pct
    }

    private fun begin() {
        if (!Settings.canDrawOverlays(this)) {
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                setStatus("فعّل صلاحية العرض فوق التطبيقات ثم ارجع واضغط تشغيل")
            } catch (e: ActivityNotFoundException) {
                setStatus("جهازك لا يعرض شاشة الصلاحية. وصّله بالكمبيوتر ونفّذ:\nadb shell appops set $packageName SYSTEM_ALERT_WINDOW allow", err = true)
            }
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            val perms = if (android.os.Build.VERSION.SDK_INT >= 33)
                arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
            else arrayOf(Manifest.permission.RECORD_AUDIO)
            requestPermissions(perms, 1); return
        }
        prepare {
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            try { startActivityForResult(mpm.createScreenCaptureIntent(), 2) }
            catch (e: Exception) { setStatus("جهازك لا يدعم التقاط صوت التطبيقات", err = true) }
        }
    }

    /** تحميل نموذج الصوت (إن لم يوجد) ونموذج الترجمة، ثم تنفيذ onDone. */
    private fun prepare(onDone: () -> Unit) {
        busy = true
        val m = ModelManager.info(this)
        val src = prefs().getString("src", "en") ?: "en"; val tgt = prefs().getString("tgt", "ar") ?: "ar"
        fun fail(msg: String) { busy = false; setStatus(msg, err = true) }
        Thread {
            try {
                if (!ModelManager.ready(this, m)) {
                    ModelManager.download(this, m) { stage, pct ->
                        runOnUiThread {
                            setStatus(if (stage == 0) "جاري تحميل نموذج الصوت (${Langs.name(src)}) $pct%" else "جاري تجهيز النموذج $pct%", pct)
                        }
                    }
                }
                runOnUiThread {
                    if (src == tgt) { busy = false; setStatus(""); onDone(); return@runOnUiThread }
                    setStatus("جاري تجهيز نموذج الترجمة...")
                    val tr = Translation.getClient(TranslatorOptions.Builder()
                        .setSourceLanguage(src).setTargetLanguage(tgt).build())
                    tr.downloadModelIfNeeded(DownloadConditions.Builder().build())
                        .addOnSuccessListener { tr.close(); busy = false; setStatus(""); onDone() }
                        .addOnFailureListener { tr.close(); fail("تعذر تحميل نموذج الترجمة، تأكد من الإنترنت وأعد المحاولة") }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    if (e.message == "space") fail("المساحة غير كافية، اختر دقة خفيفة أو احذف تطبيقات")
                    else fail("تعذر تحميل نموذج الصوت، تأكد من الإنترنت وأعد المحاولة")
                }
            }
        }.start()
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(rc, p, r)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) begin()
        else setStatus("صلاحية الصوت مطلوبة لالتقاط صوت التلفزيون", err = true)
    }
    override fun onResume() { super.onResume(); refreshBtn() }

    override fun onActivityResult(rc: Int, res: Int, data: Intent?) {
        super.onActivityResult(rc, res, data)
        if (rc != 2) return
        if (res == RESULT_OK && data != null) {
            startForegroundService(Intent(this, CaptionService::class.java).putExtra("code", res).putExtra("data", data))
            CaptionService.running = true; refreshBtn()
            setStatus("اضغط زر الرجوع وافتح ما تريد مشاهدته")
        } else setStatus("لم يتم منح إذن التقاط الصوت", err = true)
    }
}
