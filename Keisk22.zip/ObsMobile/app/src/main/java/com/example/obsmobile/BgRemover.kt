package com.example.obsmobile

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Handler
import android.os.Looper
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.subject.SubjectSegmentation
import com.google.mlkit.vision.segmentation.subject.SubjectSegmenterOptions
import java.io.File
import kotlin.math.abs

/**
 * إزالة خلفية الصورة وحفظها PNG شفاف.
 * أولًا ML Kit (يعرف الشخص/الشيء الرئيسي)، ولو فشل (ما فيه خدمات جوجل أو نت لتنزيل
 * النموذج أول مرة) نستخدم طريقة احتياطية تشيل لون الخلفية المتصل بحواف الصورة.
 * النتيجة (مسار الملف) تُرجع على الخيط الرئيسي، أو null لو فشل كل شيء.
 */
object BgRemover {
    private val ui = Handler(Looper.getMainLooper())

    fun cutout(ctx: Context, srcUri: String, onDone: (String?) -> Unit) {
        val app = ctx.applicationContext
        Thread {
            val bmp = decode(app, srcUri)
            if (bmp == null) { ui.post { onDone(null) }; return@Thread }
            fun finish(result: Bitmap?) {
                val path = result?.let { save(app, it) }
                ui.post { onDone(path) }
            }
            try {
                val seg = SubjectSegmentation.getClient(
                    SubjectSegmenterOptions.Builder().enableForegroundBitmap().build()
                )
                seg.process(InputImage.fromBitmap(bmp, 0))
                    .addOnSuccessListener { r ->
                        val fg = r.foregroundBitmap
                        if (fg != null) Thread { finish(fg) }.start()
                        else Thread { finish(fallback(bmp)) }.start()
                    }
                    .addOnFailureListener { Thread { finish(fallback(bmp)) }.start() }
            } catch (e: Throwable) {
                finish(fallback(bmp))
            }
        }.start()
    }

    private fun decode(ctx: Context, uri: String): Bitmap? = try {
        ctx.contentResolver.openInputStream(Uri.parse(uri))?.use { BitmapFactory.decodeStream(it) }?.let {
            val max = 1280
            val big = maxOf(it.width, it.height)
            if (big > max) Bitmap.createScaledBitmap(it, it.width * max / big, it.height * max / big, true) else it
        }
    } catch (e: Throwable) { null }

    private fun save(ctx: Context, bmp: Bitmap): String? = try {
        val dir = File(ctx.filesDir, "cutouts").apply { mkdirs() }
        val f = File(dir, "cut_${System.currentTimeMillis()}.png")
        f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        Uri.fromFile(f).toString()
    } catch (e: Throwable) { null }

    /** احتياطي: نمسح البكسلات المشابهة للون الحواف والمتصلة بها (تنفع مع الخلفيات الصافية) */
    private fun fallback(src: Bitmap): Bitmap? = try {
        val w = src.width; val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        val corners = intArrayOf(px[0], px[w - 1], px[(h - 1) * w], px[h * w - 1])
        val bg = Color.rgb(
            corners.sumOf { Color.red(it) } / 4,
            corners.sumOf { Color.green(it) } / 4,
            corners.sumOf { Color.blue(it) } / 4
        )
        val tol = 48
        fun close(c: Int) = abs(Color.red(c) - Color.red(bg)) + abs(Color.green(c) - Color.green(bg)) +
            abs(Color.blue(c) - Color.blue(bg)) < tol * 3 / 2 + tol
        val seen = BooleanArray(w * h)
        val stack = IntArray(w * h)
        var sp = 0
        fun push(i: Int) { if (!seen[i] && close(px[i])) { seen[i] = true; stack[sp++] = i } }
        for (x in 0 until w) { push(x); push((h - 1) * w + x) }
        for (y in 0 until h) { push(y * w); push(y * w + w - 1) }
        while (sp > 0) {
            val i = stack[--sp]
            val x = i % w; val y = i / w
            if (x > 0) push(i - 1)
            if (x < w - 1) push(i + 1)
            if (y > 0) push(i - w)
            if (y < h - 1) push(i + w)
        }
        for (i in px.indices) if (seen[i]) px[i] = 0
        Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    } catch (e: Throwable) { null }
}
