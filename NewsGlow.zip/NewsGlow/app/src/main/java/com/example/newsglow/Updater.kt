package com.example.newsglow

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.Uri

object Updater {

    private const val GLOW_MS = 10 * 60 * 1000L
    private const val CHANNEL = "breaking"

    fun runAsync(r: BroadcastReceiver, ctx: Context) {
        val pending = r.goAsync()
        val app = ctx.applicationContext
        Thread {
            try {
                run(app)
            } catch (_: Exception) {
            } finally {
                Scheduler.scheduleIfNeeded(app)
                pending.finish()
            }
        }.start()
    }

    fun run(ctx: Context) {
        val items = NewsRepo.fetchAll()
        if (items.isNotEmpty()) {
            Store.save(ctx, items)
            checkBreaking(ctx, items)
        }
        NewsWidget.renderAll(ctx)
    }

    private fun checkBreaking(ctx: Context, items: List<NewsItem>) {
        val p = Store.prefs(ctx)
        val notified = p.getStringSet("notified", emptySet())!!.toMutableSet()
        val now = System.currentTimeMillis()
        val fresh = items.filter {
            NewsRepo.isBreaking(it.title) && now - it.time < 60 * 60 * 1000L && it.link !in notified
        }
        if (fresh.isEmpty()) return
        val top = fresh.maxByOrNull { it.time }!!
        if (notified.size > 100) notified.clear()
        fresh.forEach { notified.add(it.link) }
        p.edit()
            .putStringSet("notified", notified)
            .putLong("glow_until", now + GLOW_MS)
            .putString("b_title", top.title)
            .putString("b_link", top.link)
            .apply()
        notifyBreaking(ctx, top.title, top.link)
    }

    private fun notifyBreaking(ctx: Context, title: String, link: String) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "أخبار عاجلة", NotificationManager.IMPORTANCE_HIGH)
                .apply { enableVibration(true) }
        )
        val pi = PendingIntent.getActivity(
            ctx, 1, Intent(Intent.ACTION_VIEW, Uri.parse(link)),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("🔴 عاجل")
            .setContentText(title)
            .setStyle(Notification.BigTextStyle().bigText(title))
            .setColor(0xFFFF1744.toInt())
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        nm.notify(title.hashCode(), n)
    }

    /** للتجربة: يشغّل التوهج الأحمر دقيقة ونصف */
    fun testBreaking(ctx: Context) {
        Store.prefs(ctx).edit()
            .putLong("glow_until", System.currentTimeMillis() + 90_000L)
            .putString("b_title", "هذا خبر عاجل تجريبي لاختبار التوهج الأحمر")
            .putString("b_link", "https://www.bbc.com/arabic")
            .apply()
        NewsWidget.renderAll(ctx)
    }
}
