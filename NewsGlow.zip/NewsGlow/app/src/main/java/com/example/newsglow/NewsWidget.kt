package com.example.newsglow

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import android.view.View
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class NewsWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, mgr: AppWidgetManager, ids: IntArray) {
        renderAll(context)
        Updater.runAsync(this, context)
    }

    override fun onAppWidgetOptionsChanged(
        context: Context, mgr: AppWidgetManager, id: Int, newOptions: android.os.Bundle?
    ) {
        renderAll(context)
    }

    override fun onEnabled(context: Context) {
        Scheduler.schedule(context)
    }

    override fun onDisabled(context: Context) {
        Scheduler.cancel(context)
    }

    companion object {
        private val ROWS = intArrayOf(R.id.row0, R.id.row1, R.id.row2, R.id.row3, R.id.row4)

        fun renderAll(ctx: Context) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, NewsWidget::class.java))
            if (ids.isEmpty()) return
            val rv = build(ctx)
            ids.forEach { mgr.updateAppWidget(it, rv) }
        }

        private fun pick(items: List<NewsItem>, n: Int): MutableList<NewsItem> {
            val groups = listOf(CAT_WAR, CAT_FOOTBALL, CAT_GENERAL)
                .map { c -> items.filter { it.cat == c }.toMutableList() }
            val out = mutableListOf<NewsItem>()
            while (out.size < n && groups.any { it.isNotEmpty() }) {
                for (g in groups) {
                    if (g.isNotEmpty() && out.size < n) out.add(g.removeAt(0))
                }
            }
            return out
        }

        private fun build(ctx: Context): RemoteViews {
            val rv = RemoteViews(ctx.packageName, R.layout.widget_news)
            val p = Store.prefs(ctx)
            val now = System.currentTimeMillis()
            val glowing = now < p.getLong("glow_until", 0)

            val vis = if (glowing) View.VISIBLE else View.GONE
            rv.setViewVisibility(R.id.glow, vis)
            rv.setViewVisibility(R.id.badge, vis)

            val list = pick(Store.load(ctx), 5)
            if (glowing) {
                val bt = p.getString("b_title", null)
                val bl = p.getString("b_link", null)
                if (bt != null && bl != null) {
                    list.removeAll { it.title == bt }
                    list.add(0, NewsItem(bt, bl, now, "", -1))
                }
            }

            val updated = p.getLong("updated", 0)
            rv.setTextViewText(
                R.id.updated,
                if (updated == 0L) "جاري التحميل…"
                else "آخر تحديث " + SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(updated))
            )

            for (i in ROWS.indices) {
                if (i < list.size) {
                    val it = list[i]
                    val (tag, color) = when (it.cat) {
                        -1 -> "🔴 عاجل" to 0xFFFF1744.toInt()
                        CAT_WAR -> "⚔ حروب" to 0xFFFF8A80.toInt()
                        CAT_FOOTBALL -> "⚽ كرة" to 0xFF69F0AE.toInt()
                        else -> "🌍 عام" to 0xFF82B1FF.toInt()
                    }
                    val s = SpannableString("$tag  ${it.title}")
                    s.setSpan(ForegroundColorSpan(color), 0, tag.length, 0)
                    rv.setTextViewText(ROWS[i], s)
                    rv.setViewVisibility(ROWS[i], View.VISIBLE)
                    val open = PendingIntent.getActivity(
                        ctx, 100 + i, Intent(Intent.ACTION_VIEW, Uri.parse(it.link)),
                        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                    )
                    rv.setOnClickPendingIntent(ROWS[i], open)
                } else if (i == 0) {
                    rv.setTextViewText(ROWS[0], "جاري تحميل الأخبار…")
                    rv.setViewVisibility(ROWS[0], View.VISIBLE)
                } else {
                    rv.setViewVisibility(ROWS[i], View.GONE)
                }
            }

            val app = PendingIntent.getActivity(
                ctx, 99, Intent(ctx, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            rv.setOnClickPendingIntent(R.id.title, app)
            return rv
        }
    }
}
