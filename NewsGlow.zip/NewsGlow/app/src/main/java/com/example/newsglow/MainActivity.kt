package com.example.newsglow

import android.Manifest
import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        root.addView(TextView(this).apply {
            textSize = 20f
            text = "NewsGlow — أخبار اليوم"
        })
        root.addView(TextView(this).apply {
            textSize = 15f
            setPadding(0, pad, 0, pad)
            text = "لإضافة الويدجت: اضغط مطولاً على الشاشة الرئيسية ← الويدجت ← NewsGlow.\n" +
                "الأخبار تتحدث كل دقيقتين تقريباً، والخبر العاجل يظهر بتوهج أحمر وإشعار."
        })
        root.addView(Button(this).apply {
            text = "تحديث الأخبار الآن"
            setOnClickListener {
                val app = applicationContext
                Thread {
                    Updater.run(app)
                    Scheduler.scheduleIfNeeded(app)
                }.start()
                Toast.makeText(this@MainActivity, "جاري التحديث…", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(Button(this).apply {
            text = "تجربة التوهج الأحمر (عاجل)"
            setOnClickListener {
                Updater.testBreaking(applicationContext)
                Toast.makeText(this@MainActivity, "شوف الويدجت", Toast.LENGTH_SHORT).show()
            }
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }
}
