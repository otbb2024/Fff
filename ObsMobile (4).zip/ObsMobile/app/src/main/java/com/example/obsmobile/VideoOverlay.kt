package com.example.obsmobile

import android.content.Context
import android.graphics.PixelFormat
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.SurfaceView
import android.view.WindowManager
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer

/**
 * مشغّل فيديو (libVLC) داخل نافذة عائمة فوق الشاشة.
 * لأن التقاط الشاشة يلتقط كل شي ظاهر، الفيديو يطلع في البث تلقائيًا (مثل كاميرا CameraOverlay).
 * وبما إن الفيديو يتحرك باستمرار، الشاشة "تتغير" دائمًا فما يصير 0 فريم.
 * يدعم تقريبًا كل الصيغ والبروتوكولات (HLS, DASH, TS, MKV, FLV, MP4, RTMP, RTSP, UDP...).
 * لو انقطع الرابط يعيد التشغيل تلقائيًا.
 */
class VideoOverlay(private val ctx: Context) {

    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val ui = Handler(Looper.getMainLooper())
    private var vlc: LibVLC? = null
    private var player: MediaPlayer? = null
    private var surface: SurfaceView? = null
    private var url = ""
    private var referer = ""
    private var retries = 0
    private var released = false

    val isShowing get() = surface != null

    private val restart = Runnable { if (!released) play() }

    fun show(url: String, referer: String, x: Int, y: Int, w: Int, h: Int) {
        hide()
        released = false
        this.url = url; this.referer = referer; retries = 0
        try {
            val sv = SurfaceView(ctx)
            val lp = WindowManager.LayoutParams(
                w, h,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.START; this.x = x; this.y = y }
            wm.addView(sv, lp)
            surface = sv

            val v = LibVLC(ctx, arrayListOf("--network-caching=1500", "--no-drop-late-frames", "--no-skip-frames"))
            vlc = v
            val p = MediaPlayer(v)
            player = p
            p.vlcVout.setVideoView(sv)
            p.vlcVout.setWindowSize(w, h)
            p.vlcVout.attachViews()
            p.videoScale = MediaPlayer.ScaleType.SURFACE_BEST_FIT
            p.setEventListener { e ->
                when (e.type) {
                    MediaPlayer.Event.Playing -> { retries = 0; AppLog.i("Video", "يشتغل") }
                    MediaPlayer.Event.EncounteredError -> retry("خطأ في الرابط")
                    MediaPlayer.Event.EndReached -> retry("انتهى الفيديو")
                }
            }
            play()
        } catch (e: Throwable) {
            AppLog.e("Video", e, "تعذر تشغيل الفيديو")
            hide()
        }
    }

    private fun play() {
        val v = vlc ?: return
        val p = player ?: return
        try {
            val m = Media(v, Uri.parse(url))
            m.addOption(":network-caching=1500")
            m.addOption(":http-user-agent=Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
            if (referer.isNotBlank()) m.addOption(":http-referrer=$referer")
            p.media = m
            m.release()
            p.play()
            AppLog.i("Video", "تشغيل: ${url.take(80)}")
        } catch (e: Throwable) { AppLog.e("Video", e, "فشل التشغيل") }
    }

    /** إعادة تشغيل بمهلة متزايدة (2، 4، 8، 15 ثانية) لو انقطع الرابط */
    private fun retry(why: String) {
        if (released) return
        retries++
        val delay = (2000L shl (retries - 1).coerceAtMost(3)).coerceAtMost(15_000L)
        AppLog.w("Video", "$why، إعادة المحاولة $retries بعد ${delay / 1000} ثواني")
        ui.removeCallbacks(restart)
        ui.postDelayed(restart, delay)
    }

    fun hide() {
        released = true
        ui.removeCallbacks(restart)
        try { player?.stop() } catch (_: Throwable) {}
        try { player?.vlcVout?.detachViews() } catch (_: Throwable) {}
        try { player?.release() } catch (_: Throwable) {}
        try { vlc?.release() } catch (_: Throwable) {}
        player = null; vlc = null
        surface?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        surface = null
    }
}
