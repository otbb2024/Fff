package com.example.arcaptions

import android.annotation.TargetApi
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.media.*
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import java.io.OutputStream
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import org.vosk.LibVosk
import org.vosk.LogLevel
import org.vosk.Model
import org.vosk.Recognizer
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import java.nio.ByteBuffer
import java.nio.ByteOrder
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.RequestBody.Companion.toRequestBody
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.channels.Channel
import java.util.Locale
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString.Companion.toByteString
import kotlin.math.abs
import kotlin.math.ceil

/**
 * محرك الترجمة الفورية (الإصدار 2):
 *  - يعرض الترجمة أثناء الكلام (بث مباشر) مثل ترجمة المسلسلات، بدون انتظار نهاية الجملة.
 *  - كل عرض لا يزيد عن 3 ثوانٍ.
 *  - تعرف تلقائي على اللغة: يختار اللغة ثم "يقفل" عليها لسرعة أعلى ويعيد الفحص عند تغيّر اللغة.
 */
class CaptionService : Service() {
    companion object { @Volatile var running = false }

    private class Eng(val code: String, val model: Model, val rec: Recognizer)
    private class Out(val final: Boolean, val text: String, val conf: Double)

    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var projection: MediaProjection? = null
    private lateinit var wm: WindowManager
    private var box: LinearLayout? = null
    private var arTv: TextView? = null
    private var enTv: TextView? = null
    private var lp: WindowManager.LayoutParams? = null
    private val h = Handler(Looper.getMainLooper())
    private val clearRun = Runnable { box?.visibility = View.INVISIBLE }
    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> h.post { restyle() } }

    // ---- حالة العرض (الخيط الرئيسي فقط) ----
    private val queue = ArrayDeque<Pair<String, String>>()
    private var playing = false
    private val playRun = Runnable { playNext() }
    private var shownAt = 0L
    private var shownSrc = ""
    private var finalSeq = 0L
    private var nextFinal = 1L
    private val results = HashMap<Long, Pair<String, String>>()
    private var segId = 0L
    private var reqId = 0L
    private var lastShownReq = 0L
    private var liveBusy = false
    private var livePending: Pair<String, String>? = null
    private var lastLiveAt = 0L
    private val liveRun = Runnable { pumpLive() }
    private val history = ArrayList<String>()

    @Volatile private var keyBad = false
    private val translators = ConcurrentHashMap<String, Translator>()
    private var tgt = "ar"
    private var cands: List<String> = listOf("en")
    private var micMode = false

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, f: Int, id: Int): Int {
        if (intent?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        micMode = intent?.getBooleanExtra("mic", false) == true || Build.VERSION.SDK_INT < 29
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("cap", "الترجمة", NotificationManager.IMPORTANCE_LOW))
        val stopPi = PendingIntent.getService(this, 0, Intent(this, CaptionService::class.java).setAction("STOP"),
            PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "cap").setContentTitle("ترجمان يعمل")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_media_pause), "إيقاف", stopPi).build())
            .build()
        try {
            val type = if (micMode) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            if (Build.VERSION.SDK_INT >= 30 || (Build.VERSION.SDK_INT == 29 && !micMode)) startForeground(1, n, type)
            else startForeground(1, n)
        } catch (e: Exception) { stopSelf(); return START_NOT_STICKY }

        @Suppress("DEPRECATION")
        val data = intent?.getParcelableExtra<Intent>("data")
        if ((!micMode && data == null) || !Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        if (!micMode) {
            try {
                val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                projection = mpm.getMediaProjection(intent!!.getIntExtra("code", 0), data!!)
                projection?.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }, h)
            } catch (e: Exception) { stopSelf(); return START_NOT_STICKY }
        }
        try { LibVosk.setLogLevel(LogLevel.WARNINGS) } catch (_: Throwable) {}
        tgt = prefs().getString("tgt", "ar") ?: "ar"
        cands = Langs.candidates(this)
        for (code in cands) if (code != tgt) translators[code] = Translation.getClient(
            TranslatorOptions.Builder().setSourceLanguage(code).setTargetLanguage(tgt).build())
        running = true
        buildOverlay(); prefs().registerOnSharedPreferenceChangeListener(listener)
        show("جاري تجهيز الترجمة...")
        scope.launch { engine() }
        return START_NOT_STICKY
    }

    // ------------------------------------------------------------------ الواجهة العائمة

    private fun buildOverlay() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        arTv = TextView(this).apply { gravity = Gravity.CENTER; textDirection = View.TEXT_DIRECTION_FIRST_STRONG }
        enTv = TextView(this).apply { gravity = Gravity.CENTER; textDirection = View.TEXT_DIRECTION_FIRST_STRONG }
        box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(28), dp(14), dp(28), dp(14)); visibility = View.INVISIBLE
            addView(enTv); addView(arTv)
        }
        lp = WindowManager.LayoutParams((resources.displayMetrics.widthPixels * 0.85f).toInt(),
            ViewGroup.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT)
        wm.addView(box, lp)
        restyle()
    }

    private fun restyle() {
        val b = box ?: return
        val s = loadStyle()
        applyStyle(s, b, arTv!!, enTv!!)
        lp!!.gravity = Gravity.CENTER_HORIZONTAL or when (s.pos) { 0 -> Gravity.BOTTOM; 1 -> Gravity.CENTER_VERTICAL; else -> Gravity.TOP }
        lp!!.y = if (isTv()) dp(56) else dp(48)
        try { wm.updateViewLayout(b, lp) } catch (_: Exception) {}
    }

    /** رسائل النظام: تُعرض فوراً وتلغي الطابور. */
    private fun show(ar: String, en: String = "", ms: Long = 6000) {
        h.post { queue.clear(); h.removeCallbacks(playRun); playing = false; showNow(ar, en, ms) }
    }

    private fun showNow(ar: String, en: String, ms: Long) {
        if (ar.isBlank()) { box?.visibility = View.INVISIBLE; return }
        arTv?.text = ar; enTv?.text = en
        enTv?.visibility = if (en.isBlank() || !loadStyle().showEn) View.GONE else View.VISIBLE
        box?.visibility = View.VISIBLE
        shownAt = SystemClock.uptimeMillis(); shownSrc = en
        h.removeCallbacks(clearRun); h.postDelayed(clearRun, ms)
    }

    // ------------------------------------------------------------------ أدوات النص

    private fun maxW() = prefs().getInt("maxWords", 8)
    private fun prio() = prefs().getInt("prio", 0)   // 0 فوري، 1 متوازن، 2 دقة

    private fun units(s: String): Int =
        if (s.contains(' ')) s.split(' ').count { it.isNotBlank() } else maxOf(1, s.length / 3)

    /** آخر maxW كلمات (للعرض الحي أثناء الكلام). */
    private fun tail(s: String, mw: Int): String {
        val t = s.trim()
        if (!t.contains(' ')) return if (t.length <= mw * 3) t else t.takeLast(mw * 3)
        val w = t.split(' ').filter { it.isNotBlank() }
        return if (w.size <= mw) t else w.takeLast(mw).joinToString(" ")
    }

    /** يقسّم النص لصفحات متساوية، كل صفحة لا تزيد عن mw كلمات. */
    private fun pages(s: String, mw: Int): List<String> {
        val t = s.trim()
        if (t.isEmpty()) return emptyList()
        if (!t.contains(' ')) {
            val lim = mw * 3
            if (t.length <= lim) return listOf(t)
            val n = ceil(t.length / lim.toDouble()).toInt()
            return t.chunked(ceil(t.length / n.toDouble()).toInt())
        }
        val w = t.split(' ').filter { it.isNotBlank() }
        if (w.size <= mw) return listOf(w.joinToString(" "))
        val cnt = ceil(w.size / mw.toDouble()).toInt()
        val per = ceil(w.size / cnt.toDouble()).toInt()
        return w.chunked(per).map { it.joinToString(" ") }
    }

    // ------------------------------------------------------------------ الترجمة

    private fun smartAvailable(): Boolean {
        val p = prefs()
        return p.getBoolean("smart", false) && !keyBad && !p.getString("apikey", "").isNullOrBlank()
    }

    // ---- ترجمة قوقل (أونلاين) ----
    @Volatile private var gFails = 0
    @Volatile private var gPauseUntil = 0L

    private fun gCode(c: String) = when (c) { "zh" -> "zh-CN"; "he" -> "iw"; else -> c }

    /** نفس محرك Google Translate. يرجع null لو فشل أو ما فيه إنترنت (فيشتغل ML Kit بدله). */
    private fun googleTranslate(src: String, code: String): String? {
        if (SystemClock.uptimeMillis() < gPauseUntil) return null
        try {
            val u = "https://translate.googleapis.com/translate_a/single?client=gtx&dt=t&dj=0" +
                "&sl=${gCode(code)}&tl=${gCode(tgt)}&q=" + URLEncoder.encode(src, "UTF-8")
            val c = URL(u).openConnection() as HttpURLConnection
            c.connectTimeout = 2500; c.readTimeout = 3000
            c.setRequestProperty("User-Agent", "Mozilla/5.0")
            if (c.responseCode != 200) throw RuntimeException("http ${c.responseCode}")
            val arr = JSONArray(c.inputStream.bufferedReader().readText()).getJSONArray(0)
            val sb = StringBuilder()
            for (i in 0 until arr.length()) sb.append(arr.getJSONArray(i).optString(0, ""))
            gFails = 0
            return sb.toString().trim().ifBlank { null }
        } catch (e: Exception) {
            if (++gFails >= 3) { gPauseUntil = SystemClock.uptimeMillis() + 30000; gFails = 0 }
            return null
        }
    }

    /** يترجم ويرجّع النتيجة على الخيط الرئيسي (null = فشل). قوقل أولاً، ثم ML Kit/الذكية كاحتياط. */
    private fun translateNow(src: String, code: String, cb: (String?) -> Unit) {
        if (code == tgt) { cb(src); return }
        scope.launch(Dispatchers.IO) {
            val g = googleTranslate(src, code)
            h.post {
                if (g != null) { cb(g); return@post }
                val tr = translators[code]
                if (tr == null) {
                    if (smartAvailable()) scope.launch(Dispatchers.IO) { val r = smartTranslate(src, "", code); h.post { cb(r) } }
                    else cb(null)
                } else tr.translate(src).addOnSuccessListener { cb(it) }.addOnFailureListener { cb(null) }
            }
        }
    }

    // ---- عرض حي أثناء الكلام ----
    private fun liveGap() = if (prio() == 0) 250L else 450L

    private fun onPartial(src: String, code: String) {
        if (prio() >= 2) return
        if (units(src) < (if (prio() == 0) 2 else 4)) return
        if (playing) {
            val canPreempt = queue.isEmpty() && SystemClock.uptimeMillis() - shownAt >= 1100
            if (!canPreempt) return
        }
        livePending = src to code
        pumpLive()
    }

    private fun pumpLive() {
        if (liveBusy) return
        val p = livePending ?: return
        val wait = lastLiveAt + liveGap() - SystemClock.uptimeMillis()
        if (wait > 0) { h.removeCallbacks(liveRun); h.postDelayed(liveRun, wait); return }
        livePending = null; liveBusy = true; lastLiveAt = SystemClock.uptimeMillis()
        val seg = segId; val id = ++reqId
        translateNow(p.first, p.second) { out ->
            liveBusy = false
            val canShow = seg == segId && id > lastShownReq && !out.isNullOrBlank() &&
                (!playing || (queue.isEmpty() && SystemClock.uptimeMillis() - shownAt >= 1100))
            if (canShow) {
                lastShownReq = id
                queue.clear(); h.removeCallbacks(playRun); playing = false
                showNow(tail(out!!, maxW()), tail(p.first, maxW()), 3000)
            }
            if (livePending != null) pumpLive()
        }
    }

    // ---- جملة مكتملة ----
    private fun onFinal(src: String, code: String) {
        segId++; livePending = null
        val ctx = history.takeLast(3).joinToString(" | ")
        history.add(src); if (history.size > 6) history.removeAt(0)
        val id = ++finalSeq
        h.postDelayed({ if (id >= nextFinal && !results.containsKey(id)) deliverFinal(id, null) }, 5000)
        translateNow(src, code) { out ->
            val text = out ?: src
            deliverFinal(id, text to src)
            if (!out.isNullOrBlank() && code != tgt && smartAvailable()) {
                val single = pages(text, maxW()).size == 1
                scope.launch(Dispatchers.IO) {
                    val r = smartTranslate(src, ctx, code)
                    if (r != null && single) h.post {
                        if (shownSrc == src && box?.visibility == View.VISIBLE) arTv?.text = tail(r, maxW())
                    }
                }
            }
        }
    }

    /** يحافظ على ترتيب الجمل حتى لو وصلت الترجمات متأخرة. */
    private fun deliverFinal(id: Long, v: Pair<String, String>?) {
        if (id < nextFinal) return
        results[id] = v ?: ("" to "")
        while (true) {
            val r = results.remove(nextFinal) ?: break
            if (r.first.isNotBlank()) showFinal(r.first, r.second)
            nextFinal++
        }
    }

    private fun showFinal(text: String, src: String) {
        val pgs = pages(text, maxW())
        pgs.forEachIndexed { i, p -> queue.addLast(p to (if (i == 0) src else "")) }
        while (queue.size > 3) queue.removeFirst()   // نلحق البث المباشر
        if (!playing) { h.removeCallbacks(playRun); playNext() }
    }

    private fun playNext() {
        val n = queue.removeFirstOrNull()
        if (n == null) { playing = false; h.removeCallbacks(clearRun); h.postDelayed(clearRun, 300); return }
        playing = true
        showNow(n.first, n.second, 60000)
        var ms = (units(n.first) * 300L + 700L).coerceIn(1200L, 3000L)   // كل عرض 3 ثواني كحد أقصى
        if (queue.isNotEmpty()) ms = (ms * 0.6).toLong().coerceAtLeast(900L)
        h.postDelayed(playRun, ms)
    }

    private fun fail(msg: String) {
        show(msg, "", 8000)
        h.postDelayed({ stopSelf() }, 8000)
    }

    // ------------------------------------------------------------------ التعرف على الصوت

    private fun score(j: JSONObject): Double {
        val a = j.optJSONArray("result") ?: return 0.0
        if (a.length() == 0) return 0.0
        var s = 0.0
        for (k in 0 until a.length()) s += a.getJSONObject(k).optDouble("conf", 0.0)
        return s / a.length() * minOf(1.0, a.length() / 3.0)
    }

    private fun feed(e: Eng, buf: ShortArray, n: Int): Out =
        if (e.rec.acceptWaveForm(buf, n)) {
            val j = JSONObject(e.rec.result)
            Out(true, j.optString("text").trim(), score(j))
        } else Out(false, JSONObject(e.rec.partialResult).optString("partial").trim(), 0.0)

    private suspend fun dlTranslator(tr: Translator): Boolean {
        val dl = CompletableDeferred<Boolean>()
        tr.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener { dl.complete(true) }.addOnFailureListener { dl.complete(false) }
        if (!dl.await()) return false
        // تسخين المترجم عشان أول جملة ما تتأخر
        val w = CompletableDeferred<Boolean>()
        tr.translate("hello").addOnCompleteListener { w.complete(true) }
        withTimeoutOrNull(4000) { w.await() }
        return true
    }

    private suspend fun loadModels(): List<Eng> = coroutineScope {
        cands.map { code ->
            async(Dispatchers.IO) {
                val info = ModelManager.infoFor(this@CaptionService, code)
                val m = Model(ModelManager.dir(this@CaptionService, info).absolutePath)
                val r = Recognizer(m, 16000f)
                if (cands.size > 1) r.setWords(true)
                // تسخين المحرك: أول معالجة تكون بطيئة، فنسوّيها قبل ما نقول "جاهزة"
                r.acceptWaveForm(ShortArray(4000), 4000); r.reset()
                Eng(code, m, r)
            }
        }.awaitAll()
    }

    private fun micRecord(): AudioRecord {
        val minBuf = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        return AudioRecord(MediaRecorder.AudioSource.MIC, 16000, AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, 16000 * 2))
    }

    @TargetApi(29)
    private fun playbackRecord(): AudioRecord {
        val cfg = AudioPlaybackCaptureConfiguration.Builder(projection!!)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA).addMatchingUsage(AudioAttributes.USAGE_GAME)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN).build()
        val fmt = AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(16000).setChannelMask(AudioFormat.CHANNEL_IN_MONO).build()
        return AudioRecord.Builder().setAudioFormat(fmt).setAudioPlaybackCaptureConfig(cfg)
            .setBufferSizeInBytes(16000 * 2).build()
    }

    // ------------------------------------------------------------------ التعرف من قوقل (مجاني، مدمج في أندرويد)

    @Volatile private var gStop = false
    @Volatile private var gOut: OutputStream? = null
    private var gSr: SpeechRecognizer? = null
    private var gDone: CompletableDeferred<Boolean>? = null
    private var gErrs = 0
    private var gReady = false
    private var gDevice = false

    private fun gTag(c: String) = when (c) {
        "en" -> "en-US"; "ar" -> "ar-SA"; "zh" -> "zh-CN"; "pt" -> "pt-BR"; "fr" -> "fr-FR"; "de" -> "de-DE"
        "es" -> "es-ES"; "it" -> "it-IT"; "ru" -> "ru-RU"; "tr" -> "tr-TR"; "ja" -> "ja-JP"; "ko" -> "ko-KR"; "hi" -> "hi-IN"
        else -> c
    }

    private fun gFatal() { gDone?.complete(false) }

    private fun gNext(ms: Long) { h.postDelayed({ if (running && !gStop) gStart() }, ms) }

    /** جلسة تعرف جديدة (تُستدعى على الخيط الرئيسي). */
    private fun gStart() {
        try {
            try { gOut?.close() } catch (_: Exception) {}
            gOut = null
            gSr?.destroy()
            val sr = SpeechRecognizer.createSpeechRecognizer(this)
            gSr = sr
            val code = cands[0]
            sr.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) { if (!gReady) { gReady = true; show("الترجمة جاهزة ✓", "", 1500) } }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onEvent(t: Int, p: Bundle?) {}
                override fun onPartialResults(b: Bundle?) {
                    val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim().orEmpty()
                    if (t.isNotEmpty()) onPartial(t, code)
                }
                override fun onResults(b: Bundle?) {
                    gErrs = 0
                    val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim().orEmpty()
                    if (t.isNotEmpty()) onFinal(t, code)
                    gNext(50)
                }
                override fun onError(e: Int) {
                    when (e) {
                        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> { gNext(50) }
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> gFatal()
                        12, 13 -> gFatal()   // اللغة غير مدعومة / غير متوفرة
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> gNext(600)
                        else -> { if (++gErrs >= (if (gReady) 8 else 3)) gFatal() else gNext(500) }
                    }
                }
            })
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, gTag(code))
                .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
                .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1000L)
            if (gDevice && Build.VERSION.SDK_INT >= 33) {
                val pipe = ParcelFileDescriptor.createPipe()
                i.putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE, pipe[0])
                i.putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_SAMPLING_RATE, 16000)
                i.putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_CHANNEL_COUNT, 1)
                i.putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_ENCODING, AudioFormat.ENCODING_PCM_16BIT)
                gOut = ParcelFileDescriptor.AutoCloseOutputStream(pipe[1])
            }
            sr.startListening(i)
        } catch (e: Throwable) {
            if (++gErrs >= 3) gFatal() else gNext(500)
        }
    }

    /** true = تولّى التشغيل حتى الإيقاف، false = غير متاح (نرجع لخيار آخر). */
    private suspend fun googleEngine(): Boolean {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            show("خدمة قوقل للتعرف على الصوت غير موجودة على هذا الجهاز، تم التحويل لخيار آخر", "", 5000); return false
        }
        gDevice = !micMode && projection != null
        if (gDevice && Build.VERSION.SDK_INT < 33) {
            show("قوقل مع صوت الجهاز يحتاج أندرويد 13 أو أحدث (أو اختر الميكروفون)، تم التحويل لخيار آخر", "", 6000); return false
        }
        var ar: AudioRecord? = null
        val done = CompletableDeferred<Boolean>()
        gDone = done; gStop = false; gErrs = 0; gReady = false
        try {
            for (tr in translators.values) scope.launch(Dispatchers.IO) { try { dlTranslator(tr) } catch (_: Throwable) {} }
            if (gDevice) {
                val audio = playbackRecord(); ar = audio
                if (audio.state != AudioRecord.STATE_INITIALIZED) { fail("تعذر بدء التقاط الصوت على هذا الجهاز"); return true }
                audio.startRecording()
                // ننقل صوت الجهاز لقوقل عبر أنبوب (pipe)
                scope.launch(Dispatchers.IO) {
                    val b = ShortArray(1600); val bytes = ByteArray(3200)
                    while (isActive && !gStop) {
                        val n = audio.read(b, 0, b.size)
                        if (n <= 0) continue
                        val os = gOut ?: continue
                        val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
                        for (k in 0 until n) bb.putShort(b[k])
                        try { os.write(bytes, 0, n * 2); os.flush() } catch (_: Exception) { gOut = null }
                    }
                }
            }
            h.post { gStart() }
            return done.await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            fail("حدث خطأ: ${e.message ?: "غير معروف"}"); return true
        } finally {
            gStop = true
            try { gOut?.close() } catch (_: Exception) {}
            h.post { try { gSr?.destroy() } catch (_: Exception) {}; gSr = null }
            try { ar?.stop() } catch (_: Exception) {}
            ar?.release()
        }
    }

    // ------------------------------------------------------------------ التعرف المجاني القوي (Groq Whisper large-v3)

    @Volatile private var gqBad = false
    @Volatile private var gqLimitUntil = 0L
    @Volatile private var gqFails = 0
    @Volatile private var gqOk = 0
    private val httpq by lazy { http.newBuilder().pingInterval(0, TimeUnit.SECONDS).readTimeout(12, TimeUnit.SECONDS).callTimeout(15, TimeUnit.SECONDS).build() }

    private fun groqWanted(): Boolean {
        val p = prefs()
        return p.getInt("asr", 0) == 2 && !gqBad && !p.getString("gqkey", "").isNullOrBlank()
    }

    private fun wav(pcm: ShortArray): ByteArray {
        val len = pcm.size * 2
        val bb = ByteBuffer.allocate(44 + len).order(ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray()); bb.putInt(36 + len); bb.put("WAVE".toByteArray()); bb.put("fmt ".toByteArray())
        bb.putInt(16); bb.putShort(1); bb.putShort(1); bb.putInt(16000); bb.putInt(32000); bb.putShort(2); bb.putShort(16)
        bb.put("data".toByteArray()); bb.putInt(len)
        for (v in pcm) bb.putShort(v)
        return bb.array()
    }

    private val junk = listOf("thanks for watching", "thank you for watching", "subscribe", "subtitles by", "اشتركوا", "ترجمة نانسي", "ترجمة")

    /** يرجع (النص، رمز اللغة) أو null عند الفشل. */
    private fun groqTranscribe(w: ByteArray): Pair<String, String>? {
        val key = prefs().getString("gqkey", "")!!.trim()
        val mb = MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("file", "a.wav", w.toRequestBody("audio/wav".toMediaType()))
            .addFormDataPart("model", "whisper-large-v3")
            .addFormDataPart("temperature", "0")
        if (cands.size == 1) {
            if (cands[0] != "eo") mb.addFormDataPart("language", cands[0])
            mb.addFormDataPart("response_format", "json")
        } else mb.addFormDataPart("response_format", "verbose_json")
        val req = Request.Builder().url("https://api.groq.com/openai/v1/audio/transcriptions")
            .addHeader("Authorization", "Bearer $key").post(mb.build()).build()
        httpq.newCall(req).execute().use { r ->
            if (r.code == 401 || r.code == 403) { gqBad = true; return null }
            if (r.code == 429) {
                val ra = r.header("retry-after")?.toDoubleOrNull() ?: 5.0
                gqLimitUntil = SystemClock.uptimeMillis() + (ra * 1000).toLong(); return null
            }
            if (!r.isSuccessful) { gqFails++; return null }
            val j = JSONObject(r.body!!.string())
            val text = j.optString("text", "").trim()
            val code = if (cands.size == 1) cands[0] else {
                val l = j.optString("language", "").lowercase()
                cands.firstOrNull { Locale(it).getDisplayLanguage(Locale.ENGLISH).lowercase() == l } ?: cands[0]
            }
            gqFails = 0; gqOk++
            return text to code
        }
    }

    /** true = تولّى التشغيل حتى الإيقاف، false = فشل (نرجع لخيار آخر). */
    private suspend fun groqEngine(): Boolean {
        var ar: AudioRecord? = null
        val q = Channel<ShortArray>(3, BufferOverflow.DROP_OLDEST)
        try {
            for (tr in translators.values) scope.launch(Dispatchers.IO) { try { dlTranslator(tr) } catch (_: Throwable) {} }
            val audio: AudioRecord = if (micMode || projection == null) micRecord() else playbackRecord()
            ar = audio
            if (audio.state != AudioRecord.STATE_INITIALIZED) { fail("تعذر بدء التقاط الصوت على هذا الجهاز"); return true }

            // عامل واحد يرسل المقاطع بالترتيب وبمسافة 3.1 ثانية (حد Groq المجاني 20 طلب بالدقيقة)
            scope.launch(Dispatchers.IO) {
                var last = 0L
                for (seg in q) {
                    val now = SystemClock.uptimeMillis()
                    val wait = maxOf(last + 3100 - now, gqLimitUntil - now)
                    if (wait > 0) delay(wait)
                    last = SystemClock.uptimeMillis()
                    val r = try { groqTranscribe(wav(seg)) } catch (_: Exception) { gqFails++; null }
                    if (r != null && r.first.isNotBlank() && junk.none { r.first.lowercase().contains(it) }) h.post { onFinal(r.first, r.second) }
                }
            }

            audio.startRecording()
            show("الترجمة جاهزة ✓", "", 1500)
            val thr = if (micMode || projection == null) 900 else 500
            val buf = ShortArray(1600)   // 100 ملّي ثانية
            val pre = ArrayDeque<ShortArray>()
            var seg = ArrayList<ShortArray>(); var inSpeech = false; var quiet = 0; var peakSeg = 0
            var lastSound = System.currentTimeMillis(); var warned = false

            fun flush() {
                val frames = if (quiet > 2) seg.subList(0, seg.size - (quiet - 2)) else seg
                if (peakSeg >= thr * 2 && frames.size >= 5) {
                    val out = ShortArray(frames.size * 1600); var o = 0
                    for (f in frames) { System.arraycopy(f, 0, out, o, 1600); o += 1600 }
                    q.trySend(out)
                }
                seg = ArrayList(); inSpeech = false; quiet = 0; peakSeg = 0
            }

            while (scope.isActive) {
                if (gqBad || (gqOk == 0 && gqFails >= 3)) {
                    show(if (gqBad) "مفتاح Groq غير صحيح، تم التحويل لخيار آخر" else "تعذر الاتصال بـ Groq، تم التحويل لخيار آخر", "", 5000)
                    return false
                }
                val n = audio.read(buf, 0, buf.size)
                if (n < 0) { fail("انقطع التقاط الصوت"); return true }
                if (n < buf.size) { if (n > 0) java.util.Arrays.fill(buf, n, buf.size, 0.toShort()) else continue }
                var peak = 0
                for (i in 0 until buf.size) { val a = abs(buf[i].toInt()); if (a > peak) peak = a }
                val now = System.currentTimeMillis()
                if (peak > 8) { lastSound = now; warned = false }
                else if (!warned && now - lastSound > 20000) {
                    warned = true
                    show("لا يصل صوت للتطبيق. تأكد أن الفيديو شغّال، أو جرّب خيار الميكروفون من إعدادات التطبيق")
                }
                val frame = buf.copyOf()
                if (!inSpeech) {
                    pre.addLast(frame); if (pre.size > 3) pre.removeFirst()
                    if (peak > thr) { inSpeech = true; seg.addAll(pre); pre.clear(); peakSeg = peak; quiet = 0 }
                } else {
                    seg.add(frame)
                    if (peak > thr) { quiet = 0; if (peak > peakSeg) peakSeg = peak } else quiet++
                    val len = seg.size
                    if ((quiet >= 4 && len >= 32) || quiet >= 12 || len >= 80) flush()
                }
            }
            return true
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            fail("حدث خطأ: ${e.message ?: "غير معروف"}"); return true
        } finally {
            q.close()
            try { ar?.stop() } catch (_: Exception) {}
            ar?.release()
        }
    }

    // ------------------------------------------------------------------ التعرف السحابي (Deepgram Nova-3)

    @Volatile private var dgBad = false
    @Volatile private var dgDead = false
    private val http = OkHttpClient.Builder().pingInterval(10, TimeUnit.SECONDS).readTimeout(0, TimeUnit.MILLISECONDS).build()

    private fun cloudWanted(): Boolean {
        val p = prefs()
        return p.getInt("asr", 0) == 3 && !dgBad && !p.getString("dgkey", "").isNullOrBlank()
    }

    private fun dgUrl(): String {
        val sb = StringBuilder("wss://api.deepgram.com/v1/listen?model=nova-3&encoding=linear16&sample_rate=16000&channels=1" +
            "&interim_results=true&endpointing=300&smart_format=true")
        if (cands.size == 1) sb.append("&language=").append(cands[0])
        else { sb.append("&language=multi"); for (c in cands) sb.append("&language_hint=").append(c) }
        return sb.toString()
    }

    /** يرجع true إذا تولّى التشغيل حتى الإيقاف، و false إذا تعذر الاتصال (فنرجع لـ Vosk). */
    private suspend fun cloudEngine(): Boolean {
        var ar: AudioRecord? = null
        var ws: WebSocket? = null
        try {
            // نماذج ML Kit تنزل بالخلفية كاحتياط فقط (ما نوقف التشغيل لو فشلت)
            for (tr in translators.values) scope.launch(Dispatchers.IO) { try { dlTranslator(tr) } catch (_: Throwable) {} }
            val audio: AudioRecord = if (micMode || projection == null) micRecord() else playbackRecord()
            ar = audio
            if (audio.state != AudioRecord.STATE_INITIALIZED) { fail("تعذر بدء التقاط الصوت على هذا الجهاز"); return true }
            var started = false; var everOpened = false; var fails = 0
            val buf = ShortArray(1600)   // 100 ملّي ثانية
            var lastSound = System.currentTimeMillis(); var warned = false

            while (scope.isActive) {
                val opened = CompletableDeferred<Boolean>()
                dgDead = false
                val req = Request.Builder().url(dgUrl()).addHeader("Authorization", "Token " + prefs().getString("dgkey", "")!!.trim()).build()
                ws = http.newWebSocket(req, object : WebSocketListener() {
                    var acc = ""; var lastLive = ""; var lastCode = cands[0]
                    override fun onOpen(webSocket: WebSocket, response: Response) { opened.complete(true) }
                    override fun onMessage(webSocket: WebSocket, text: String) {
                        try {
                            val j = JSONObject(text)
                            if (j.optString("type") != "Results") return
                            val alt = j.getJSONObject("channel").getJSONArray("alternatives").getJSONObject(0)
                            val t = alt.optString("transcript", "").trim()
                            val isFinal = j.optBoolean("is_final"); val sf = j.optBoolean("speech_final")
                            val langs = alt.optJSONArray("languages")
                            if (langs != null && langs.length() > 0) {
                                val l = langs.optString(0, "")
                                lastCode = cands.firstOrNull { it == l || l.startsWith(it + "-") } ?: lastCode
                            }
                            if (t.isNotEmpty()) {
                                if (isFinal) acc = "$acc $t".trim()
                                val live = if (isFinal) acc else "$acc $t".trim()
                                val flush = isFinal && (sf || units(acc) >= 30)
                                if (!flush && live != lastLive) { lastLive = live; val c = lastCode; h.post { onPartial(live, c) } }
                            }
                            if (isFinal && acc.isNotBlank() && (sf || units(acc) >= 30)) {
                                val f = acc; val c = lastCode; acc = ""; lastLive = ""
                                h.post { onFinal(f, c) }
                            }
                        } catch (_: Exception) {}
                    }
                    override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                        if (response?.code == 401 || response?.code == 403) dgBad = true
                        if (!opened.isCompleted) opened.complete(false)
                        dgDead = true
                    }
                    override fun onClosed(webSocket: WebSocket, code: Int, reason: String) { dgDead = true }
                })
                val ok = withTimeoutOrNull(7000) { opened.await() } ?: false
                if (!ok) {
                    ws?.cancel()
                    if (!everOpened || dgBad) {
                        show(if (dgBad) "مفتاح Deepgram غير صحيح، تم التحويل للتعرف على الجهاز" else "تعذر الاتصال بالتعرف السحابي، تم التحويل للتعرف على الجهاز", "", 5000)
                        return false
                    }
                    if (++fails >= 5) { fail("انقطع الاتصال بخدمة التعرف على الصوت"); return true }
                    delay(1000); continue
                }
                everOpened = true; fails = 0
                if (!started) { audio.startRecording(); started = true; show("الترجمة جاهزة ✓", "", 1500) }

                while (scope.isActive && !dgDead) {
                    val n = audio.read(buf, 0, buf.size)
                    if (n < 0) { fail("انقطع التقاط الصوت"); return true }
                    if (n == 0) continue
                    var peak = 0
                    for (i in 0 until n) { val a = abs(buf[i].toInt()); if (a > peak) peak = a }
                    val now = System.currentTimeMillis()
                    if (peak > 8) { lastSound = now; warned = false }
                    else if (!warned && now - lastSound > 20000) {
                        warned = true
                        show("لا يصل صوت للتطبيق. تأكد أن الفيديو شغّال، أو جرّب خيار الميكروفون من إعدادات التطبيق")
                    }
                    val bb = ByteBuffer.allocate(n * 2).order(ByteOrder.LITTLE_ENDIAN)
                    for (i in 0 until n) bb.putShort(buf[i])
                    ws?.send(bb.array().toByteString(0, n * 2))
                }
                try { ws?.close(1000, null) } catch (_: Exception) {}
                if (dgBad) { show("مفتاح Deepgram غير صحيح، تم التحويل للتعرف على الجهاز", "", 5000); return false }
            }
            return true
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            fail("حدث خطأ: ${e.message ?: "غير معروف"}"); return true
        } finally {
            try { ws?.cancel() } catch (_: Exception) {}
            try { ar?.stop() } catch (_: Exception) {}
            ar?.release()
        }
    }

    private suspend fun engine() {
        if (prefs().getInt("asr", 0) == 1 && googleEngine()) return
        if (groqWanted() && groqEngine()) return
        if (cloudWanted() && cloudEngine()) return
        val engs = ArrayList<Eng>(); var ar: AudioRecord? = null
        try {
            for (code in cands) {
                if (!ModelManager.ready(this, ModelManager.infoFor(this, code))) {
                    fail("نموذج الصوت (${Langs.name(code)}) غير محمّل، افتح التطبيق وشغّل من جديد"); return
                }
            }
            val smartOn = smartAvailable()

            // تحميل نماذج الترجمة وتحميل نماذج الصوت بالتوازي (أسرع بكثير)
            val (trRes, loaded) = coroutineScope {
                val t = async { translators.entries.toList().map { (c, tr) -> c to async { dlTranslator(tr) } }.map { it.first to it.second.await() } }
                val m = async { loadModels() }
                t.await() to m.await()
            }
            engs.addAll(loaded)
            for ((code, ok) in trRes) if (!ok) {
                if (smartOn) translators.remove(code)?.close()
                else { fail("تعذر تحميل نموذج الترجمة، تأكد من الإنترنت"); return }
            }

            val audio: AudioRecord = if (micMode || projection == null) micRecord() else playbackRecord()
            ar = audio
            if (audio.state != AudioRecord.STATE_INITIALIZED) { fail("تعذر بدء التقاط الصوت على هذا الجهاز"); return }
            audio.startRecording()
            show("الترجمة جاهزة ✓", "", 1500)

            val buf = ShortArray(1600)   // 100 ملّي ثانية
            var locked: Eng? = if (engs.size == 1) engs[0] else null
            var lockedAt = 0L; var lowCount = 0
            val pend = HashMap<Int, Out>(); var decideAt = 0L
            var lastPartial = ""
            var lastSound = System.currentTimeMillis(); var warned = false

            while (scope.isActive) {
                val n = audio.read(buf, 0, buf.size)
                if (n < 0) { fail("انقطع التقاط الصوت"); return }
                if (n == 0) continue

                var peak = 0
                for (i in 0 until n) { val a = abs(buf[i].toInt()); if (a > peak) peak = a }
                val now = System.currentTimeMillis()
                if (peak > 8) { lastSound = now; warned = false }
                else if (!warned && now - lastSound > 20000) {
                    warned = true
                    show("لا يصل صوت للتطبيق. تأكد أن الفيديو شغّال، أو جرّب خيار الميكروفون من إعدادات التطبيق")
                }

                val lk = locked
                if (lk != null) {
                    // ---- المسار السريع: محرك واحد ----
                    val o = feed(lk, buf, n)
                    if (o.final) {
                        lastPartial = ""
                        if (o.text.isNotBlank()) {
                            val t = o.text; val c = lk.code
                            h.post { onFinal(t, c) }
                            if (engs.size > 1) {
                                if (o.conf < 0.55 && units(t) >= 2) lowCount++ else lowCount = 0
                                if (lowCount >= 2 || now - lockedAt > 60000) {
                                    locked = null; lowCount = 0   // إعادة فحص اللغة
                                    for (e in engs) e.rec.reset()
                                }
                            }
                        }
                    } else if (o.text.isNotEmpty() && o.text != lastPartial) {
                        lastPartial = o.text
                        val t = o.text; val c = lk.code
                        h.post { onPartial(t, c) }
                    }
                } else {
                    // ---- تعرف تلقائي: كل المحركات تسمع بالتوازي، ونختار الأعلى ثقة ----
                    val outs = coroutineScope { engs.map { e -> async { feed(e, buf, n) } }.awaitAll() }
                    for ((i, o) in outs.withIndex()) if (o.final && o.text.isNotBlank()) pend[i] = o
                    if (pend.isNotEmpty()) {
                        if (decideAt == 0L) decideAt = now + 350
                        if (now >= decideAt) {
                            val best = pend.maxByOrNull { it.value.conf }
                            if (best != null) {
                                locked = engs[best.key]; lockedAt = now; lowCount = 0; lastPartial = ""
                                val t = best.value.text; val c = engs[best.key].code
                                h.post { onFinal(t, c) }
                            }
                            pend.clear(); decideAt = 0L
                        }
                    }
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            fail("حدث خطأ: ${e.message ?: "غير معروف"}")
        } finally {
            try { ar?.stop() } catch (_: Exception) {}
            ar?.release()
            for (e in engs) { try { e.rec.close() } catch (_: Throwable) {}; try { e.model.close() } catch (_: Throwable) {} }
        }
    }

    // ------------------------------------------------------------------ ترجمة ذكية (اختياري)

    /** ترجمة ذكية عبر Claude: تصحح أخطاء التعرف وتكتب ترجمة طبيعية مختصرة. */
    private fun smartTranslate(src: String, ctx: String, code: String): String? {
        try {
            val p = prefs()
            val key = p.getString("apikey", "")?.trim().orEmpty()
            val sl = Langs.name(code); val tl = Langs.name(tgt)
            val mw = maxW()
            val style = if (tgt != "ar") "" else if (p.getInt("style", 0) == 1)
                " اكتبها بلهجة خليجية بيضاء مفهومة للجميع." else " اكتبها بعربية فصحى مبسطة وسلسة."
            val sys = "أنت مترجم فوري محترف لسطور مسلسل أو فيديو مباشر. " +
                "النص المدخل ناتج تعرف آلي على الكلام: بدون ترقيم وقد فيه كلمات خاطئة أو مقطوعة. " +
                "افهم المعنى المقصود من السياق، ثم اكتب ترجمة إلى $tl طبيعية وواضحة كأن المتحدث يتكلمها أصلاً " +
                "مثل ترجمة المسلسلات، وبحد أقصى $mw كلمات، مع حذف الحشو والتكرار.$style " +
                "أرجع الترجمة فقط بدون شرح أو علامات اقتباس."
            val user = (if (ctx.isNotBlank()) "السياق السابق: $ctx\n" else "") + "النص الحالي ($sl): $src"
            val body = JSONObject().put("model", "claude-haiku-5-5").put("max_tokens", 120).put("system", sys)
                .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", user)))
            val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
            c.requestMethod = "POST"; c.connectTimeout = 4000; c.readTimeout = 5000; c.doOutput = true
            c.setRequestProperty("x-api-key", key)
            c.setRequestProperty("anthropic-version", "2023-06-01")
            c.setRequestProperty("content-type", "application/json")
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val rc = c.responseCode
            if (rc == 401 || rc == 403) { keyBad = true; show("مفتاح API غير صحيح، سيتم استخدام الترجمة العادية", "", 5000); return null }
            if (rc != 200) return null
            val txt = c.inputStream.bufferedReader().readText()
            val out = JSONObject(txt).getJSONArray("content").getJSONObject(0).getString("text")
                .trim().trim('"', '«', '»', ' ')
            return out.ifBlank { null }
        } catch (e: Exception) { return null }
    }

    override fun onDestroy() {
        running = false; scope.cancel(); projection?.stop()
        prefs().unregisterOnSharedPreferenceChangeListener(listener)
        h.removeCallbacksAndMessages(null)
        if (::wm.isInitialized) box?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        for (t in translators.values) { try { t.close() } catch (_: Exception) {} }
        super.onDestroy()
    }
}
