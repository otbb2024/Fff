package com.example.arcaptions

import android.app.UiModeManager
import android.content.Context
import android.content.res.Configuration
import android.os.Build
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.View
import android.widget.TextView

val TEXT_COLORS = intArrayOf(0xFFFFFFFF.toInt(), 0xFFFFD54F.toInt(), 0xFF4DD0E1.toInt(), 0xFF81C784.toInt(),
    0xFFF48FB1.toInt(), 0xFFFFB74D.toInt(), 0xFFB39DDB.toInt(), 0xFF111111.toInt())
val BG_COLORS = intArrayOf(0xFF000000.toInt(), 0xFF0D1B3D.toInt(), 0xFF2A0F3D.toInt(),
    0xFF0B3D2E.toInt(), 0xFF3D0B0B.toInt(), 0xFFFFFFFF.toInt())
val FONT_NAMES = listOf("حديث", "نسخ", "مضغوط", "خفيف", "وسط")
val FONT_FAMILIES = listOf("sans-serif", "serif", "sans-serif-condensed", "sans-serif-light", "sans-serif-medium")
val POS_NAMES = listOf("أسفل", "وسط", "أعلى")

data class Style(val size: Int, val color: Int, val bg: Int, val opacity: Int, val font: Int,
                 val bold: Boolean, val shadow: Boolean, val pos: Int, val showEn: Boolean)

fun Context.prefs() = getSharedPreferences("tarjuman", Context.MODE_PRIVATE)
fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()
// لإضافة خط عربي خاص: ضع ملف الخط في res/font/custom_font.ttf وسيظهر خيار "مخصص" تلقائياً
fun Context.customFontId() = resources.getIdentifier("custom_font", "font", packageName)
fun Context.fontNames(): List<String> = if (customFontId() != 0) FONT_NAMES + "مخصص" else FONT_NAMES

fun Context.isTv(): Boolean = try {
    (getSystemService(Context.UI_MODE_SERVICE) as UiModeManager).currentModeType == Configuration.UI_MODE_TYPE_TELEVISION
} catch (_: Exception) { false }
fun Context.defaultSize() = if (isTv()) 40 else 32

fun Context.loadStyle(): Style {
    val p = prefs()
    return Style(p.getInt("size", defaultSize()), p.getInt("color", TEXT_COLORS[0]), p.getInt("bg", BG_COLORS[0]),
        p.getInt("opacity", 0), p.getInt("font", 0), p.getBoolean("bold", true),
        p.getBoolean("shadow", false), p.getInt("pos", 0), p.getBoolean("showEn", true))
}

fun Context.typefaceFor(s: Style): Typeface {
    val base = if (s.font == FONT_FAMILIES.size && customFontId() != 0) resources.getFont(customFontId())
    else Typeface.create(FONT_FAMILIES.getOrElse(s.font) { "sans-serif" }, Typeface.NORMAL)
    return if (Build.VERSION.SDK_INT >= 28) Typeface.create(base, if (s.bold) 700 else 400, false)
    else Typeface.create(base, if (s.bold) Typeface.BOLD else Typeface.NORMAL)
}

fun Context.applyStyle(s: Style, box: View, ar: TextView, en: TextView) {
    val a = s.opacity * 255 / 100
    box.background = GradientDrawable().apply {
        cornerRadius = dp(18).toFloat(); setColor((s.bg and 0x00FFFFFF) or (a shl 24))
    }
    val tf = typefaceFor(s)
    ar.apply {
        setTextSize(TypedValue.COMPLEX_UNIT_SP, s.size.toFloat()); setTextColor(s.color); typeface = tf
        if (s.shadow) setShadowLayer(8f, 0f, 2f, Color.BLACK) else setShadowLayer(0f, 0f, 0f, 0)
    }
    en.apply {
        setTextSize(TypedValue.COMPLEX_UNIT_SP, (s.size * 0.55f).coerceAtLeast(12f)); typeface = tf
        setTextColor((s.color and 0x00FFFFFF) or 0xB0000000.toInt())
        if (s.shadow) setShadowLayer(6f, 0f, 2f, Color.BLACK) else setShadowLayer(0f, 0f, 0f, 0)
    }
}
