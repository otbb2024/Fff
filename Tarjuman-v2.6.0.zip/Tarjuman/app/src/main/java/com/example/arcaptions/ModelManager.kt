package com.example.arcaptions

import android.content.Context
import java.io.File
import java.io.FileOutputStream
import java.io.FilterInputStream
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/** تحميل نموذج التعرف على الكلام (Vosk) داخل التطبيق عند أول تشغيل. */
object ModelManager {
    class Info(val id: String, val sizeMb: Int, private val tag: String? = null) {
        val url get() = "https://alphacephei.com/vosk/models/$id.zip"
        fun label() = (tag ?: if (sizeMb < 100) "خفيف" else "دقيق") + " ($sizeMb ميغا)"
    }

    fun options(ctx: Context): List<Info> =
        Langs.SOURCES[ctx.prefs().getString("src", "en")] ?: Langs.SOURCES.getValue("en")

    fun info(ctx: Context): Info {
        val o = options(ctx); return o[ctx.prefs().getInt("acc", 0).coerceIn(0, o.size - 1)]
    }

    /** نموذج لغة معينة: الجودة المختارة تنطبق على اللغة المحددة فقط، وغيرها الخفيف. */
    fun infoFor(ctx: Context, code: String): Info {
        val o = Langs.SOURCES[code] ?: Langs.SOURCES.getValue("en")
        val idx = if (code == ctx.prefs().getString("src", "en")) ctx.prefs().getInt("acc", 0) else 0
        return o[idx.coerceIn(0, o.size - 1)]
    }
    fun dir(ctx: Context, m: Info) = File(ctx.filesDir, "models/${m.id}")
    fun ready(ctx: Context, m: Info) = File(dir(ctx, m), ".ready").exists()
    fun deleteAll(ctx: Context) { File(ctx.filesDir, "models").deleteRecursively() }

    private class Counting(i: InputStream, val onBytes: (Long) -> Unit) : FilterInputStream(i) {
        var count = 0L
        override fun read(b: ByteArray, off: Int, len: Int): Int {
            val n = super.read(b, off, len)
            if (n > 0) { count += n; onBytes(count) }
            return n
        }
    }

    /** عملية حاجبة: شغّلها في خيط خلفي. stage: 0 تحميل، 1 فك ضغط. */
    fun download(ctx: Context, m: Info, onProgress: (stage: Int, pct: Int) -> Unit) {
        var attempt = 0
        while (true) {
            try { downloadOnce(ctx, m, onProgress); return }
            catch (e: IOException) {
                if (e.message == "space" || e.message == "bad zip" || ++attempt >= 3) throw e
                Thread.sleep(1500)
            }
        }
    }

    private fun downloadOnce(ctx: Context, m: Info, onProgress: (stage: Int, pct: Int) -> Unit) {
        val root = File(ctx.filesDir, "models").apply { mkdirs() }
        if (root.usableSpace < m.sizeMb * 1024L * 1024L * 3) throw IOException("space")
        val zip = File(ctx.cacheDir, "${m.id}.zip")
        val tmp = File(root, "${m.id}.tmp")
        try {
            val conn = URL(m.url).openConnection() as HttpURLConnection
            conn.connectTimeout = 20000; conn.readTimeout = 30000; conn.instanceFollowRedirects = true
            if (conn.responseCode != 200) throw IOException("HTTP ${conn.responseCode}")
            val total = conn.contentLengthLong
            conn.inputStream.use { i ->
                zip.outputStream().use { o ->
                    val b = ByteArray(65536); var done = 0L; var last = -1; var n: Int
                    while (i.read(b).also { n = it } > 0) {
                        o.write(b, 0, n); done += n
                        if (total > 0) { val p = (done * 100 / total).toInt(); if (p != last) { last = p; onProgress(0, p) } }
                    }
                }
            }
            tmp.deleteRecursively(); tmp.mkdirs()
            val zl = zip.length().coerceAtLeast(1); var lastP = -1
            val counting = Counting(zip.inputStream()) { c ->
                val p = (c * 100 / zl).toInt().coerceAtMost(100)
                if (p != lastP) { lastP = p; onProgress(1, p) }
            }
            ZipInputStream(counting.buffered()).use { z ->
                var e = z.nextEntry
                while (e != null) {
                    val name = e.name.substringAfter('/', "")  // حذف المجلد الأعلى
                    if (name.isNotEmpty()) {
                        val out = File(tmp, name)
                        if (!out.canonicalPath.startsWith(tmp.canonicalPath + File.separator)) throw IOException("bad zip")
                        if (e.isDirectory) out.mkdirs()
                        else { out.parentFile?.mkdirs(); FileOutputStream(out).use { z.copyTo(it) } }
                    }
                    e = z.nextEntry
                }
            }
            if (!File(tmp, "am").exists()) throw IOException("bad model")
            File(tmp, ".ready").writeText("ok")
            val target = dir(ctx, m); target.deleteRecursively()
            if (!tmp.renameTo(target)) throw IOException("rename")
        } finally {
            zip.delete(); if (!ready(ctx, m)) tmp.deleteRecursively()
        }
    }
}
