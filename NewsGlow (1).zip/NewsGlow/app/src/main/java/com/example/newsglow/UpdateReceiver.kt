package com.example.newsglow

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings

class UpdateReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Updater.runAsync(this, context)
    }
}

/** بعد إعادة تشغيل الجهاز أو تحديث التطبيق: يرجّع الزر العائم والتحديثات */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (Store.prefs(context).getBoolean("overlay_on", false) && Settings.canDrawOverlays(context)) {
            try {
                context.startForegroundService(Intent(context, OverlayService::class.java))
            } catch (_: Exception) {
            }
        }
        Updater.runAsync(this, context)
    }
}
