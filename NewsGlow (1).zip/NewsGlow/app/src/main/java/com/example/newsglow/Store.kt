package com.example.newsglow

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object Store {
    fun prefs(c: Context) = c.getSharedPreferences("news", Context.MODE_PRIVATE)

    fun save(c: Context, items: List<NewsItem>) {
        val keep = items.groupBy { it.cat }.values.flatMap { it.take(15) }
        val arr = JSONArray()
        keep.forEach {
            arr.put(
                JSONObject().put("t", it.title).put("l", it.link)
                    .put("d", it.time).put("s", it.source).put("c", it.cat)
            )
        }
        prefs(c).edit()
            .putString("items", arr.toString())
            .putLong("updated", System.currentTimeMillis())
            .apply()
    }

    fun load(c: Context): List<NewsItem> {
        val s = prefs(c).getString("items", null) ?: return emptyList()
        return try {
            val arr = JSONArray(s)
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                NewsItem(o.getString("t"), o.getString("l"), o.getLong("d"), o.getString("s"), o.getInt("c"))
            }.sortedByDescending { it.time }
        } catch (_: Exception) {
            emptyList()
        }
    }
}
