package com.example.newsglow

import android.content.Context
import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

const val CAT_AUTO = -1
const val CAT_WAR = 0
const val CAT_FOOTBALL = 1
const val CAT_GENERAL = 2

/** ترتيب الأسماء = (cat + 1) */
val CAT_NAMES = listOf("تلقائي", "حروب وسياسة", "كرة قدم", "عام")

data class NewsItem(
    val title: String,
    val link: String,
    val time: Long,
    val source: String,
    val cat: Int
)

object NewsRepo {

    private val BREAKING = listOf("عاجل", "breaking", "urgent", "flash")
    private val WAR = listOf(
        "حرب", "غارة", "غارات", "قصف", "هجوم", "صاروخ", "جيش", "عسكري", "غزة", "أوكرانيا", "هدنة",
        "war", "strike", "missile", "attack", "military", "gaza", "ukraine", "troops", "ceasefire", "israel", "iran"
    )
    private val FOOT = listOf(
        "كرة", "الدوري", "مباراة", "هدف", "كأس", "المنتخب", "football", "soccer", "premier league",
        "champions league", "goal", "fifa", "match", "la liga", "world cup"
    )

    fun isBreaking(title: String): Boolean {
        val t = title.lowercase()
        return BREAKING.any { t.contains(it) }
    }

    private fun classify(title: String, def: Int): Int {
        if (def != CAT_AUTO) return def
        val t = title.lowercase()
        if (WAR.any { t.contains(it) }) return CAT_WAR
        if (FOOT.any { t.contains(it) }) return CAT_FOOTBALL
        return CAT_GENERAL
    }

    private val DATE_FORMATS = listOf(
        "EEE, dd MMM yyyy HH:mm:ss Z",
        "EEE, dd MMM yyyy HH:mm:ss zzz",
        "dd MMM yyyy HH:mm:ss Z"
    )

    private fun parseDate(s: String): Long {
        for (f in DATE_FORMATS) {
            try {
                return SimpleDateFormat(f, Locale.ENGLISH).parse(s)!!.time
            } catch (_: Exception) {
            }
        }
        return System.currentTimeMillis()
    }

    private fun parse(feed: Feed): List<NewsItem> {
        val out = mutableListOf<NewsItem>()
        var conn: HttpURLConnection? = null
        try {
            conn = URL(feed.url).openConnection() as HttpURLConnection
            conn.connectTimeout = 6000
            conn.readTimeout = 6000
            conn.instanceFollowRedirects = true
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) NewsGlow/2.0")
            if (conn.responseCode != 200) return out
            val p = Xml.newPullParser()
            p.setInput(conn.inputStream, null)
            var inItem = false
            var title = ""
            var link = ""
            var date = ""
            var ev = p.eventType
            while (ev != XmlPullParser.END_DOCUMENT && out.size < 15) {
                if (ev == XmlPullParser.START_TAG) {
                    when (p.name) {
                        "item" -> { inItem = true; title = ""; link = ""; date = "" }
                        "title" -> if (inItem) title = p.nextText().trim()
                        "link" -> if (inItem) link = p.nextText().trim()
                        "pubDate" -> if (inItem) date = p.nextText().trim()
                    }
                } else if (ev == XmlPullParser.END_TAG && p.name == "item" && inItem) {
                    inItem = false
                    if (title.isNotEmpty() && link.startsWith("http")) {
                        out.add(NewsItem(title, link, parseDate(date), feed.name, classify(title, feed.cat)))
                    }
                }
                ev = p.next()
            }
        } catch (_: Exception) {
        } finally {
            conn?.disconnect()
        }
        return out
    }

    fun fetchAll(ctx: Context): List<NewsItem> {
        val feeds = FeedStore.enabled(ctx)
        if (feeds.isEmpty()) return emptyList()
        val pool = Executors.newFixedThreadPool(feeds.size)
        try {
            val tasks = feeds.map { f -> Callable<List<NewsItem>> { parse(f) } }
            val futures = pool.invokeAll(tasks, 9, TimeUnit.SECONDS)
            val all = futures.flatMap { f ->
                try { f.get() } catch (_: Exception) { emptyList<NewsItem>() }
            }
            return all.distinctBy { it.title }.sortedByDescending { it.time }
        } finally {
            pool.shutdownNow()
        }
    }
}
