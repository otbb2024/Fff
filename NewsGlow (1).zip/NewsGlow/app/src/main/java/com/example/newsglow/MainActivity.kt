package com.example.newsglow

import android.Manifest
import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var overlayBtn: Button
    private lateinit var status: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        root.addView(TextView(this).apply {
            textSize = 22f
            text = "NewsGlow — أخبار اليوم"
        })
        status = TextView(this).apply {
            textSize = 13f
            alpha = 0.75f
            setPadding(0, dp(6), 0, dp(10))
        }
        root.addView(status)

        fun btn(label: String, action: () -> Unit): Button = Button(this).apply {
            text = label
            setOnClickListener { action() }
        }.also {
            root.addView(it, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(8) })
        }

        btn("➕ ويدجت — إضافة للشاشة الرئيسية") { addWidget() }
        overlayBtn = btn("") { toggleOverlay() }
        btn("⚙ إدارة المصادر") { startActivity(Intent(this, SourcesActivity::class.java)) }
        btn("🔄 تحديث الأخبار الآن") {
            val app = applicationContext
            Thread {
                try { Updater.run(app) } catch (_: Exception) {}
                Scheduler.scheduleIfNeeded(app)
            }.start()
            toast("جاري التحديث…")
        }
        btn("🔴 تجربة التوهج الأحمر (عاجل)") {
            Updater.testBreaking(applicationContext)
            toast("شوف الويدجت أو الزر العائم")
        }

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        refreshUi()
    }

    private fun refreshUi() {
        val on = Store.prefs(this).getBoolean("overlay_on", false)
        overlayBtn.text = if (on) "⏹ إيقاف الزر العائم" else "🔘 تشغيل الزر العائم"
        val n = FeedStore.enabled(this).size
        status.text = "المصادر المفعّلة: $n • التحديث كل دقيقتين تقريباً\n" +
            "الزر العائم: " + (if (on) "يعمل" else "متوقف")
    }

    private fun addWidget() {
        val m = AppWidgetManager.getInstance(this)
        if (Build.VERSION.SDK_INT >= 26 && m.isRequestPinAppWidgetSupported) {
            m.requestPinAppWidget(ComponentName(this, NewsWidget::class.java), null, null)
        } else {
            toast("اضغط مطولاً على الشاشة الرئيسية ← الويدجت ← NewsGlow")
        }
    }

    private fun toggleOverlay() {
        val p = Store.prefs(this)
        if (p.getBoolean("overlay_on", false)) {
            p.edit().putBoolean("overlay_on", false).apply()
            stopService(Intent(this, OverlayService::class.java))
        } else {
            if (!Settings.canDrawOverlays(this)) {
                toast("فعّل «العرض فوق التطبيقات» لـ NewsGlow ثم ارجع واضغط الزر مرة ثانية")
                try {
                    startActivity(
                        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                    )
                } catch (_: Exception) {
                    toast("على التلفزيون: adb shell appops set $packageName SYSTEM_ALERT_WINDOW allow")
                }
                return
            }
            p.edit().putBoolean("overlay_on", true).apply()
            startForegroundService(Intent(this, OverlayService::class.java))
        }
        refreshUi()
    }
}
