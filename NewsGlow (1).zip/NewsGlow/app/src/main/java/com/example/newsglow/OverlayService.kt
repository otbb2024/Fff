package com.example.newsglow

import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

/** الزر العائم: دائرة قابلة للسحب، تضغط عليها تفتح بطاقة الأخبار، والعاجل ينبض بالأحمر */
class OverlayService : Service() {

    companion object {
        @Volatile
        private var inst: OverlayService? = null

        fun requestRefresh() {
            val s = inst ?: return
            s.handler.post { s.refreshUi() }
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var params: WindowManager.LayoutParams
    private var root: LinearLayout? = null
    private lateinit var panel: LinearLayout
    private lateinit var rows: LinearLayout
    private lateinit var panelBg: GradientDrawable
    private lateinit var ringBg: GradientDrawable

    private var expanded = false
    private var wasGlowing = false
    private var pulse: ValueAnimator? = null
    private var lastFetch = 0L

    private val tick = object : Runnable {
        override fun run() {
            refreshUi()
            val now = System.currentTimeMillis()
            if (now - lastFetch >= Scheduler.INTERVAL_MS) {
                lastFetch = now
                val app = applicationContext
                Thread {
                    try { Updater.run(app) } catch (_: Exception) {}
                }.start()
            }
            handler.postDelayed(this, 15_000)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onCreate() {
        super.onCreate()
        inst = this
        startAsForeground()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        try {
            buildUi()
        } catch (_: Exception) {
            // لا توجد صلاحية العرض فوق التطبيقات
            Store.prefs(this).edit().putBoolean("overlay_on", false).apply()
            stopSelf()
            return
        }
        handler.post(tick)
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("overlay", "الزر العائم", NotificationManager.IMPORTANCE_LOW)
        )
        val pi = PendingIntent.getActivity(
            this, 2, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, "overlay")
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("NewsGlow")
            .setContentText("الزر العائم يعمل — اضغط لفتح الإعدادات")
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun buildUi() {
        val prefs = Store.prefs(this)
        val r = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        // ----- الزر الدائري -----
        ringBg = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.TRANSPARENT)
            setStroke(dp(4), Color.TRANSPARENT)
        }
        val ring = View(this).apply { background = ringBg }
        val face = TextView(this).apply {
            text = "📰"
            textSize = 24f
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xEE212121.toInt())
            }
        }
        val bubble = FrameLayout(this).apply {
            addView(ring, FrameLayout.LayoutParams(dp(60), dp(60)))
            addView(face, FrameLayout.LayoutParams(dp(52), dp(52)).apply { gravity = Gravity.CENTER })
        }

        // ----- بطاقة الأخبار -----
        panelBg = GradientDrawable().apply {
            setColor(0xF2121212.toInt())
            cornerRadius = dp(16).toFloat()
            setStroke(dp(2), 0xFF424242.toInt())
        }
        val title = TextView(this).apply {
            text = "أخبار اليوم"
            setTextColor(Color.WHITE)
            textSize = 15f
            setOnClickListener {
                startActivity(Intent(this@OverlayService, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
        val refresh = TextView(this).apply {
            text = "🔄"
            textSize = 18f
            setPadding(dp(10), 0, dp(10), 0)
            setOnClickListener {
                lastFetch = System.currentTimeMillis()
                val app = applicationContext
                Thread { try { Updater.run(app) } catch (_: Exception) {} }.start()
            }
        }
        val close = TextView(this).apply {
            text = "✕"
            setTextColor(Color.WHITE)
            textSize = 18f
            setPadding(dp(10), 0, dp(4), 0)
            setOnClickListener { expanded = false; refreshUi() }
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(refresh)
            addView(close)
        }
        rows = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = panelBg
            setPadding(dp(12), dp(10), dp(12), dp(10))
            visibility = View.GONE
            addView(header)
            addView(rows)
        }

        r.addView(bubble, LinearLayout.LayoutParams(dp(60), dp(60)))
        r.addView(panel, LinearLayout.LayoutParams(dp(300), ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(6)
        })

        params = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.getInt("ov_x", dp(8))
            y = prefs.getInt("ov_y", dp(160))
        }

        // سحب + ضغط
        var sx = 0
        var sy = 0
        var tx = 0f
        var ty = 0f
        var moved = false
        bubble.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = params.x; sy = params.y; tx = e.rawX; ty = e.rawY; moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt()
                    val dy = (e.rawY - ty).toInt()
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                    if (moved) {
                        params.x = sx + dx
                        params.y = sy + dy
                        wm.updateViewLayout(r, params)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        prefs.edit().putInt("ov_x", params.x).putInt("ov_y", params.y).apply()
                    } else {
                        expanded = !expanded
                        refreshUi()
                    }
                    true
                }
                else -> false
            }
        }

        wm.addView(r, params)
        root = r
        refreshUi()
    }

    fun refreshUi() {
        if (root == null) return
        val (list, glowing) = NewsWidget.currentList(this)
        rows.removeAllViews()
        if (list.isEmpty()) {
            rows.addView(TextView(this).apply {
                text = if (FeedStore.enabled(this@OverlayService).isEmpty()) "لا توجد مصادر مفعّلة" else "جاري تحميل الأخبار…"
                setTextColor(Color.WHITE)
                textSize = 13f
            })
        }
        for (n in list) {
            rows.addView(TextView(this).apply {
                text = NewsWidget.styled(n)
                setTextColor(Color.WHITE)
                textSize = 13f
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
                setPadding(0, dp(6), 0, dp(6))
                setOnClickListener {
                    try {
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(n.link)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } catch (_: Exception) {
                    }
                }
            })
        }
        if (glowing && !wasGlowing) expanded = true // يفتح البطاقة تلقائياً عند العاجل
        wasGlowing = glowing
        panel.visibility = if (expanded) View.VISIBLE else View.GONE
        setPulse(glowing)
    }

    private fun setPulse(on: Boolean) {
        if (on && pulse == null) {
            pulse = ValueAnimator.ofInt(60, 255).apply {
                duration = 700
                repeatMode = ValueAnimator.REVERSE
                repeatCount = ValueAnimator.INFINITE
                addUpdateListener { a ->
                    val c = Color.argb(a.animatedValue as Int, 255, 23, 68)
                    ringBg.setStroke(dp(4), c)
                    panelBg.setStroke(dp(3), c)
                }
                start()
            }
        } else if (!on && pulse != null) {
            pulse?.cancel()
            pulse = null
            ringBg.setStroke(dp(4), Color.TRANSPARENT)
            panelBg.setStroke(dp(2), 0xFF424242.toInt())
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        pulse?.cancel()
        root?.let {
            try { wm.removeView(it) } catch (_: Exception) {}
        }
        root = null
        inst = null
        super.onDestroy()
    }
}
