package com.example.newsglow

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Feed(
    val name: String,
    val url: String,
    val cat: Int = CAT_AUTO,
    val enabled: Boolean = true
)

object FeedStore {
    private const val KEY = "feeds"

    val DEFAULTS = listOf(
        Feed("BBC عربي", "https://feeds.bbci.co.uk/arabic/rss.xml"),
        Feed("سكاي نيوز عربية", "https://www.skynewsarabia.com/web/rss"),
        Feed("Al Jazeera", "https://www.aljazeera.com/xml/rss/all.xml"),
        Feed("BBC World", "https://feeds.bbci.co.uk/news/world/rss.xml"),
        Feed("BBC Football", "https://feeds.bbci.co.uk/sport/football/rss.xml", CAT_FOOTBALL),
        Feed("ESPN FC", "https://www.espn.com/espn/rss/soccer/news", CAT_FOOTBALL)
    )

    fun all(ctx: Context): List<Feed> {
        val s = Store.prefs(ctx).getString(KEY, null) ?: return DEFAULTS
        return try {
            val arr = JSONArray(s)
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                Feed(o.getString("n"), o.getString("u"), o.getInt("c"), o.getBoolean("e"))
            }
        } catch (_: Exception) {
            DEFAULTS
        }
    }

    fun save(ctx: Context, list: List<Feed>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("n", it.name).put("u", it.url).put("c", it.cat).put("e", it.enabled))
        }
        Store.prefs(ctx).edit().putString(KEY, arr.toString()).apply()
    }

    fun resetDefaults(ctx: Context) {
        Store.prefs(ctx).edit().remove(KEY).apply()
    }

    fun enabled(ctx: Context): List<Feed> = all(ctx).filter { it.enabled }
}
