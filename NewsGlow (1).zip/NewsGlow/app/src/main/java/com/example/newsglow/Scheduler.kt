package com.example.newsglow

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.SystemClock

object Scheduler {
    // كل دقيقتين (تقريباً؛ أندرويد قد يؤخرها قليلاً في وضع توفير الطاقة)
    const val INTERVAL_MS = 2 * 60 * 1000L

    private fun pi(ctx: Context) = PendingIntent.getBroadcast(
        ctx, 0, Intent(ctx, UpdateReceiver::class.java),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    fun schedule(ctx: Context) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.setAndAllowWhileIdle(
            AlarmManager.ELAPSED_REALTIME_WAKEUP,
            SystemClock.elapsedRealtime() + INTERVAL_MS,
            pi(ctx)
        )
    }

    fun cancel(ctx: Context) {
        (ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pi(ctx))
    }

    fun hasWidgets(ctx: Context): Boolean {
        val m = AppWidgetManager.getInstance(ctx)
        return m.getAppWidgetIds(ComponentName(ctx, NewsWidget::class.java)).isNotEmpty()
    }

    fun scheduleIfNeeded(ctx: Context) {
        if (hasWidgets(ctx)) schedule(ctx) else cancel(ctx)
    }
}
