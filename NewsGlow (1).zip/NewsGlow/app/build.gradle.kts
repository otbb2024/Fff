plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.newsglow"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.newsglow"
        minSdk = 26
        targetSdk = 34
        // يزيد تلقائياً مع كل بناء على GitHub عشان التحديث فوق النسخة القديمة يشتغل
        versionCode = (System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 1) + 10
        versionName = "2.0"
    }

    // مفتاح توقيع ثابت: نفس التوقيع في كل نسخة = تحديث بدون "حزمة غير صالحة"
    signingConfigs {
        create("app") {
            storeFile = rootProject.file("keystore/newsglow.jks")
            storePassword = "newsglow123"
            keyAlias = "newsglow"
            keyPassword = "newsglow123"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("app")
        }
        debug {
            signingConfig = signingConfigs.getByName("app")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}
