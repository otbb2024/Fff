package com.example.obsmobile

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.media.MediaCodecInfo
import android.graphics.Color
import android.graphics.Paint
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.core.content.ContextCompat
import androidx.core.content.IntentCompat
import com.pedro.common.ConnectChecker
import com.pedro.encoder.input.gl.render.filters.GreyScaleFilterRender
import com.pedro.encoder.input.gl.render.filters.NegativeFilterRender
import com.pedro.encoder.input.gl.render.filters.SepiaFilterRender
import com.pedro.encoder.input.gl.render.filters.`object`.ImageObjectFilterRender
import com.pedro.encoder.input.gl.render.filters.`object`.TextObjectFilterRender
import com.pedro.library.rtmp.RtmpDisplay
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.min

class StreamService : Service() {

    companion object {
        const val ACTION_START = "start"
        const val ACTION_STOP = "stop"
        const val ACTION_APPLY = "apply"   // تبديل المشهد / تحديث المصادر والفلتر
        const val ACTION_MUTE = "mute"     // كتم / تشغيل الصوت
        const val ACTION_SWITCH = "switch" // تبديل المشهد مع انتقال
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val EXTRA_URL = "url"
        const val EXTRA_RECORD = "record"
        @Volatile var running = false
        @Volatile var muted = false
        @Volatile var liveBitrateK = 0          // البت ريت الفعلي المرسل (kbps)
        @Volatile var targetK = 0               // الهدف الحالي بعد التكيّف (kbps)
        @Volatile var thermalThrottled = false  // هل خفّضنا الإطارات بسبب السخونة
        @Volatile var health = 0                // صحة البث: 0 لا بث، 1 ممتاز، 2 ضعيف، 3 سيّئ
        @Volatile var reconnecting = false      // جاري إعادة الاتصال
        const val MAX_RETRIES = 10
        const val RETRY_DELAY_MS = 3000L
    }

    private var display: RtmpDisplay? = null
    private var camera: CameraOverlay? = null
    private var heartbeat: Heartbeat? = null
    private var camSig: String? = null
    private var streamW = 1280
    private var streamH = 720
    private val ui = Handler(Looper.getMainLooper())
    private var targetBitrate = 0
    private var currentBitrate = 0
    private var calmTicks = 0
    private var adapting = false
    private var renderFps = 30
    private var thermalListener: Any? = null
    private var wakeLock: android.os.PowerManager.WakeLock? = null
    private var retryCount = 0
    private var currentUrl = ""
    private var countdown: Countdown? = null

    private val checker = object : ConnectChecker {
        override fun onConnectionStarted(url: String) {}
        override fun onConnectionSuccess() {
            if (reconnecting) toast("رجع الاتصال، البث شغال")
            else toast("تم الاتصال، البث شغال")
            reconnecting = false
            retryCount = 0
            if (health == 3) health = 1
            display?.let { setRetries(it, MAX_RETRIES) } // نرجّع عدّاد المحاولات
        }
        override fun onConnectionFailed(reason: String) {
            if (display == null) return
            if (currentUrl.isNotEmpty() && tryReconnect(reason)) {
                retryCount++
                reconnecting = true
                health = 3
                toast("انقطع الاتصال، أعيد المحاولة ($retryCount/$MAX_RETRIES)")
            } else {
                toast("فشل الاتصال: $reason")
                stopAll()
            }
        }
        override fun onNewBitrate(bitrate: Long) { liveBitrateK = (bitrate / 1000).toInt() }
        override fun onDisconnect() { toast("انقطع البث") }
        override fun onAuthError() { toast("خطأ مصادقة") }
        override fun onAuthSuccess() {}
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> start(intent)
            ACTION_APPLY -> if (transitioning) ui.postDelayed({ applyScene() }, 800) else applyScene()
            ACTION_SWITCH -> switchScene()
            ACTION_MUTE -> toggleMute()
            ACTION_STOP -> stopAll()
        }
        return START_NOT_STICKY
    }

    private fun start(intent: Intent) {
        goForeground()
        running = true
        val n = SettingsStore.load(this).countdown
        if (n > 0 && Settings.canDrawOverlays(this)) {
            countdown?.cancel()
            countdown = Countdown(this).also { it.start(n) { countdown = null; startNow(intent) } }
        } else startNow(intent)
    }

    private fun startNow(intent: Intent) {

        val code = intent.getIntExtra(EXTRA_CODE, 0)
        val data = IntentCompat.getParcelableExtra(intent, EXTRA_DATA, Intent::class.java)
        val url = intent.getStringExtra(EXTRA_URL).orEmpty().trim()
        val record = intent.getBooleanExtra(EXTRA_RECORD, false)
        if (data == null) { stopAll(); return }

        val st = SettingsStore.load(this)
        renderFps = st.fps
        thermalThrottled = false
        val d = display ?: RtmpDisplay(applicationContext, true, checker).also { display = it }
        d.setIntentResult(code, data)

        val m = resources.displayMetrics
        if (st.ratio == "169") {
            // أفقي 16:9 يملأ شاشة تلقرام / يوتيوب
            streamH = st.shortSide / 2 * 2
            streamW = (st.shortSide * 16 / 9) / 2 * 2
        } else {
            val scale = st.shortSide.toFloat() / min(m.widthPixels, m.heightPixels)
            streamW = (m.widthPixels * scale).toInt() / 2 * 2
            streamH = (m.heightPixels * scale).toInt() / 2 * 2
        }

        val videoOk = prepareVideoSmart(d, st.fps, st.bitrateK * 1000, m.densityDpi, st.codec == "high")
        val audioOk = if (st.audio == "internal" && Build.VERSION.SDK_INT >= 29)
            d.prepareInternalAudio(128 * 1000, 48000, true, false, false)
        else d.prepareAudio(128 * 1000, 48000, true, false, false)

        if (!videoOk || !audioOk) { toast("الجهاز ما يدعم هذي الإعدادات"); stopAll(); return }

        if (record) {
            val dir = getExternalFilesDir(android.os.Environment.DIRECTORY_MOVIES)!!
            val name = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val file = File(dir, "rec_$name.mp4")
            d.startRecord(file.absolutePath)
            toast("التسجيل في: ${file.absolutePath}")
        }
        currentUrl = url
        retryCount = 0
        reconnecting = false
        if (url.isNotEmpty()) {
            setRetries(d, MAX_RETRIES)
            d.startStream(url)
            health = 1
            startAdaptive(st.bitrateK * 1000)
        }
        acquireWake()
        running = true

        // نبضة تخلي الشاشة "تتغير" عشان يطلع الفيديو حتى لو الشاشة ثابتة
        if (Settings.canDrawOverlays(this)) {
            heartbeat = Heartbeat(this).also { it.start() }
        } else {
            toast("فعّل (الظهور فوق التطبيقات) عشان يشتغل البث والشاشة ثابتة")
        }

        muted = st.audio == "none"
        if (muted) d.disableAudio()

        unwatchThermal()
        if (Build.VERSION.SDK_INT >= 29) watchThermal(st.fps)

        // نطبق المشهد بعد ما يشتغل الـ OpenGL
        ui.postDelayed({ applyScene() }, 800)
    }

    private var transitioning = false
    private val black1: Bitmap by lazy {
        Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888).apply { eraseColor(Color.BLACK) }
    }

    /** يبدّل المشهد مع انتقال: تغطية بالأسود، تبديل المشهد، ثم كشف */
    private fun switchScene() {
        val st = SettingsStore.load(this)
        val gl = try { display?.glInterface } catch (e: Exception) { null }
        if (gl == null || st.transition == "none" || transitioning) { applyScene(); return }
        transitioning = true
        val half = (st.transMs / 2).coerceAtLeast(100).toLong()
        var f = ImageObjectFilterRender()
        gl.addFilter(f)
        var swapped = false
        val begin = SystemClock.uptimeMillis()

        // frac: نسبة التغطية من 0 إلى 1
        fun style(filter: ImageObjectFilterRender, frac: Float, reveal: Boolean) {
            if (st.transition == "wipe") {
                val w = (frac * 100f).coerceIn(0.5f, 100f)
                filter.setImage(black1)
                filter.setScale(w, 100f)
                filter.setPosition(if (reveal) 100f - w else 0f, 0f)
            } else { // fade
                val bmp = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)
                bmp.eraseColor(Color.argb((frac * 255).toInt().coerceIn(0, 255), 0, 0, 0))
                filter.setImage(bmp)
                filter.setScale(100f, 100f)
                filter.setPosition(0f, 0f)
            }
        }

        val tick = object : Runnable {
            override fun run() {
                val t = SystemClock.uptimeMillis() - begin
                try {
                    if (t >= half * 2) {
                        if (gl.filtersCount() > 0) gl.removeFilter(gl.filtersCount() - 1)
                        transitioning = false
                        return
                    }
                    if (t < half) {
                        style(f, t.toFloat() / half, false)
                    } else {
                        if (!swapped) {
                            swapped = true
                            applyScene()                 // يمسح الفلاتر ويرسم المشهد الجديد
                            f = ImageObjectFilterRender()
                            gl.addFilter(f)              // الغطاء فوق كل شي
                        }
                        style(f, 1f - (t - half).toFloat() / half, true)
                    }
                    ui.postDelayed(this, 33)
                } catch (e: Exception) {
                    transitioning = false
                    applyScene()
                }
            }
        }
        ui.post(tick)
    }

    /**
     * بت ريت تكيّفي: كل ثانية نسأل المكتبة إذا فيه ازدحام في الشبكة.
     * لو فيه نخفّض البت ريت 15% (حد أدنى 40% من اللي اخترته)، ولو هادي 5 ثواني نرفعه تدريجيًا لين يرجع للهدف.
     * مكتوبة بالـ reflection عشان لو نسخة المكتبة ما فيها الدوال ما ينكسر البناء ويتعطل التكيّف بس.
     */
    private fun startAdaptive(target: Int) {
        targetBitrate = target
        currentBitrate = target
        targetK = target / 1000
        calmTicks = 0
        adapting = true
        ui.postDelayed(adaptTick, 2000)
    }

    private fun hasCongestion(d: RtmpDisplay): Boolean? = try {
        val client = d.javaClass.methods.firstOrNull { it.name == "getStreamClient" && it.parameterTypes.isEmpty() }?.invoke(d)
        val m = client?.javaClass?.methods?.firstOrNull { it.name == "hasCongestion" && it.parameterTypes.size <= 1 && it.parameterTypes.all { p -> p == Float::class.javaPrimitiveType } }
        when {
            client == null || m == null -> null
            m.parameterTypes.isEmpty() -> m.invoke(client) as? Boolean
            else -> m.invoke(client, 20f) as? Boolean
        }
    } catch (_: Exception) { null }

    private fun setBitrateOnFly(d: RtmpDisplay, bitrate: Int) {
        try {
            val m = d.javaClass.methods.firstOrNull { it.name == "setVideoBitrateOnFly" && it.parameterTypes.size == 1 }
            m?.invoke(d, bitrate)
        } catch (_: Exception) {}
    }

    private val adaptTick = object : Runnable {
        override fun run() {
            val d = display
            if (!adapting || d == null || !d.isStreaming) { adapting = false; return }
            val congested = hasCongestion(d)
            if (congested == null) { adapting = false; return } // المكتبة ما تدعم، نوقف التكيّف
            health = when {
                reconnecting -> 3
                congested && currentBitrate <= targetBitrate * 0.5f -> 3
                congested || currentBitrate < targetBitrate -> 2
                else -> 1
            }
            if (congested) {
                calmTicks = 0
                val next = (currentBitrate * 0.85f).toInt().coerceAtLeast((targetBitrate * 0.4f).toInt())
                if (next < currentBitrate) { currentBitrate = next; targetK = next / 1000; setBitrateOnFly(d, next) }
            } else if (currentBitrate < targetBitrate && ++calmTicks >= 5) {
                calmTicks = 0
                val next = (currentBitrate * 1.1f).toInt().coerceAtMost(targetBitrate)
                currentBitrate = next; targetK = next / 1000; setBitrateOnFly(d, next)
            }
            ui.postDelayed(this, 1000)
        }
    }

    // ---- إعادة الاتصال التلقائية (reflection عشان تتحمل اختلاف نسخ المكتبة) ----
    private fun setRetries(d: RtmpDisplay, n: Int) {
        val targets = listOfNotNull(d, try { d.javaClass.methods.firstOrNull { it.name == "getStreamClient" && it.parameterTypes.isEmpty() }?.invoke(d) } catch (_: Exception) { null })
        for (t in targets) {
            try {
                val m = t.javaClass.methods.firstOrNull { it.name == "setReTries" && it.parameterTypes.size == 1 }
                if (m != null) { m.invoke(t, n); return }
            } catch (_: Exception) {}
        }
    }

    /** يطلب من المكتبة إعادة الاتصال بعد 3 ثواني. يرجع false لو المحاولات خلصت أو الدالة غير موجودة */
    private fun tryReconnect(reason: String): Boolean {
        val d = display ?: return false
        val targets = listOfNotNull(d, try { d.javaClass.methods.firstOrNull { it.name == "getStreamClient" && it.parameterTypes.isEmpty() }?.invoke(d) } catch (_: Exception) { null })
        for (t in targets) {
            try {
                val m = t.javaClass.methods
                    .filter { it.name == "reTry" && it.parameterTypes.size in 2..3 &&
                        it.parameterTypes[0] == Long::class.javaPrimitiveType && it.parameterTypes[1] == String::class.java }
                    .minByOrNull { it.parameterTypes.size } ?: continue
                val r = if (m.parameterTypes.size == 2) m.invoke(t, RETRY_DELAY_MS, reason)
                        else m.invoke(t, RETRY_DELAY_MS, reason, null)
                return r as? Boolean ?: false
            } catch (_: Exception) {}
        }
        return false
    }

    // ---- منع الجهاز من النوم أثناء البث ----
    @Suppress("DEPRECATION")
    private fun acquireWake() {
        try {
            if (wakeLock?.isHeld == true) return
            val pm = getSystemService(POWER_SERVICE) as android.os.PowerManager
            wakeLock = pm.newWakeLock(android.os.PowerManager.PARTIAL_WAKE_LOCK, "obsmobile:stream").apply {
                acquire(8 * 60 * 60 * 1000L) // حد أمان 8 ساعات
            }
        } catch (_: Exception) {}
    }

    private fun releaseWake() {
        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (_: Exception) {}
        wakeLock = null
    }

    /** لو الجوال سخن (حرارة شديدة) نخفّض الإطارات إلى 24 مؤقتًا، ونرجعها لما يبرد */
    @RequiresApi(29)
    private fun watchThermal(baseFps: Int) {
        val pm = getSystemService(POWER_SERVICE) as android.os.PowerManager
        val l = android.os.PowerManager.OnThermalStatusChangedListener { status ->
            val hot = status >= android.os.PowerManager.THERMAL_STATUS_SEVERE
            if (hot != thermalThrottled) {
                thermalThrottled = hot
                renderFps = if (hot) min(baseFps, 24) else baseFps
                try { display?.glInterface?.let { forceRender(it, renderFps) } } catch (_: Exception) {}
                toast(if (hot) "الجوال سخن، خفّضت الإطارات مؤقتًا" else "رجعت الحرارة طبيعية، رجعت الإطارات")
            }
        }
        pm.addThermalStatusListener(ContextCompat.getMainExecutor(this), l)
        thermalListener = l
    }

    private fun unwatchThermal() {
        if (Build.VERSION.SDK_INT >= 29) {
            (thermalListener as? android.os.PowerManager.OnThermalStatusChangedListener)?.let {
                (getSystemService(POWER_SERVICE) as android.os.PowerManager).removeThermalStatusListener(it)
            }
        }
        thermalListener = null
    }

    private fun toggleMute() {
        val d = display ?: return
        if (muted) d.enableAudio() else d.disableAudio()
        muted = !muted
    }

    /** يطبق الفلتر العام + مصادر المشهد النشط (نص، صورة، كاميرا) */
    private fun applyScene() {
        val d = display ?: return
        val st = SettingsStore.load(this)
        val scenes = SceneStore.load(this)
        val scene = scenes.getOrNull(SceneStore.active(this).coerceIn(0, scenes.lastIndex)) ?: return
        try {
            val gl = d.glInterface
            gl.clearFilters()
            forceRender(gl, renderFps)
            // لو المشهد ما فيه "بث شاشة" نغطي الشاشة بالأسود
            if (scene.sources.none { it.type == "screen" }) {
                val bg = ImageObjectFilterRender()
                gl.addFilter(bg)
                bg.setImage(black1)
                bg.setScale(100f, 100f)
                bg.setPosition(0f, 0f)
            }
            fun addGlobalFilter() {
                when (st.filter) {
                    "gray" -> gl.addFilter(GreyScaleFilterRender())
                    "sepia" -> gl.addFilter(SepiaFilterRender())
                    "negative" -> gl.addFilter(NegativeFilterRender())
                }
            }
            addGlobalFilter()
            scene.sources.forEach { s ->
                when (s.type) {
                    "text" -> if (s.text.isNotBlank()) {
                        // نرسم النص كصورة بنفس نسبة المعاينة (حجم الخط ÷ 720 من عرض البث)
                        val bmp = textBitmap(s.text, s.textSize * streamW / 720f)
                        val f = ImageObjectFilterRender()
                        gl.addFilter(f)
                        f.setImage(bmp)
                        f.setScale(bmp.width * 100f / streamW, bmp.height * 100f / streamH)
                        f.setPosition(s.x, s.y)
                    }
                    "image" -> loadBitmap(s.uri)?.let { bmp ->
                        val f = ImageObjectFilterRender()
                        gl.addFilter(f)
                        f.setImage(bmp)
                        val hPct = s.scale * bmp.height / bmp.width * streamW / streamH
                        f.setScale(s.scale, hPct)
                        f.setPosition(s.x, s.y)
                    }
                }
            }
        } catch (e: Exception) {
            toast("تعذر تطبيق المشهد: ${e.message}")
        }
        applyCamera(scene)
    }

    /**
     * أندرويد ما يرسل إطارات التقاط الشاشة إلا إذا تغيّرت الشاشة. لو الشاشة ثابتة
     * يوصل صوت بدون صورة فيرفضه تلقرام. هنا نجبر المكتبة ترسم إطارات باستمرار.
     */
    /**
     * لو اخترت High نجرب نطلب ملف H.264 High (ضغط أفضل بنفس البت ريت).
     * إذا الجهاز أو نسخة المكتبة ما تدعمه نرجع للوضع العادي تلقائيًا.
     */
    private fun prepareVideoSmart(d: RtmpDisplay, fps: Int, bitrate: Int, dpi: Int, high: Boolean): Boolean {
        if (high) {
            try {
                val intT = Int::class.javaPrimitiveType
                val m = d.javaClass.methods.firstOrNull { mt ->
                    mt.name == "prepareVideo" && mt.parameterTypes.size == 9 && mt.parameterTypes.all { it == intT }
                }
                if (m != null) {
                    val ok = m.invoke(d, streamW, streamH, fps, bitrate, 2, 0, dpi,
                        MediaCodecInfo.CodecProfileLevel.AVCProfileHigh, -1) as? Boolean
                    if (ok == true) return true
                    toast("الجهاز ما يدعم High، رجع للترميز العادي")
                } else {
                    toast("نسخة المكتبة ما تدعم High، رجع للترميز العادي")
                }
            } catch (_: Exception) {
                toast("تعذر High، رجع للترميز العادي")
            }
        }
        return d.prepareVideo(streamW, streamH, fps, bitrate, 0, dpi)
    }

    private fun forceRender(gl: Any, fps: Int) {
        try {
            val two = gl.javaClass.methods.firstOrNull { it.name == "setForceRender" && it.parameterTypes.size == 2 }
            if (two != null) { two.invoke(gl, true, fps); return }
            val one = gl.javaClass.methods.firstOrNull { it.name == "setForceRender" && it.parameterTypes.size == 1 }
            one?.invoke(gl, true)
        } catch (_: Exception) {}
    }

    private fun applyCamera(scene: Scene) {
        val src = scene.sources.firstOrNull { it.type == "camera" }
        if (src == null) {
            camera?.hide(); camSig = null
            return
        }
        if (!Settings.canDrawOverlays(this) ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED
        ) {
            toast("الكاميرا تحتاج صلاحية الكاميرا والظهور فوق التطبيقات")
            return
        }
        val m = resources.displayMetrics
        val w = (src.scale / 100f * m.widthPixels).toInt()
        val x = (src.x / 100f * m.widthPixels).toInt()
        val y = (src.y / 100f * m.heightPixels).toInt()
        val sig = "${src.text}|$w|$x|$y"
        val cam = camera ?: CameraOverlay(this).also { camera = it }
        if (sig != camSig || !cam.isShowing) {
            cam.show(src.text == "front", w, x, y)
            camSig = sig
        }
    }

    /** يرسم النص (سطر أو أكثر) على صورة شفافة بخط أبيض بالحجم المطلوب بالبكسل */
    private fun textBitmap(text: String, sizePx: Float): Bitmap {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = sizePx.coerceAtLeast(8f)
        }
        val lines = text.split("\n")
        var widest = lines.maxOf { paint.measureText(it) }
        // لو النص أعرض من البث نصغّره عشان ما ينقص
        if (widest > streamW * 0.95f) {
            paint.textSize = paint.textSize * streamW * 0.95f / widest
            widest = lines.maxOf { paint.measureText(it) }
        }
        val fm = paint.fontMetrics
        val lineH = fm.descent - fm.ascent
        val pad = paint.textSize * 0.1f
        val w = (widest + pad * 2).toInt().coerceAtLeast(2)
        val h = (lineH * lines.size + pad * 2).toInt().coerceAtLeast(2)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        lines.forEachIndexed { i, l -> c.drawText(l, pad, pad - fm.ascent + i * lineH, paint) }
        return bmp
    }

    private fun loadBitmap(uri: String): Bitmap? = try {
        contentResolver.openInputStream(Uri.parse(uri))?.use { BitmapFactory.decodeStream(it) }?.let {
            val maxW = streamW.coerceAtLeast(1280)
            if (it.width > maxW) Bitmap.createScaledBitmap(it, maxW, it.height * maxW / it.width, true) else it
        }
    } catch (e: Exception) { null }

    private fun stopAll() {
        countdown?.cancel(); countdown = null
        adapting = false
        ui.removeCallbacks(adaptTick)
        unwatchThermal()
        releaseWake()
        liveBitrateK = 0; targetK = 0; thermalThrottled = false
        health = 0; reconnecting = false; retryCount = 0; currentUrl = ""
        transitioning = false
        camera?.hide(); camera = null; camSig = null
        heartbeat?.stop(); heartbeat = null
        display?.let {
            if (it.isRecording) it.stopRecord()
            if (it.isStreaming) it.stopStream()
        }
        display = null
        running = false
        muted = false
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun goForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel("stream", "Streaming", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val n = Notification.Builder(this, "stream")
            .setContentTitle(getString(R.string.app_name))
            .setContentText("البث / التسجيل شغال")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            if (Build.VERSION.SDK_INT >= 30) {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
                    type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
                    type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            }
            startForeground(1, n, type)
        } else startForeground(1, n)
    }

    private fun toast(msg: String) =
        ui.post { Toast.makeText(applicationContext, msg, Toast.LENGTH_LONG).show() }

    override fun onDestroy() { stopAll(); super.onDestroy() }
}
