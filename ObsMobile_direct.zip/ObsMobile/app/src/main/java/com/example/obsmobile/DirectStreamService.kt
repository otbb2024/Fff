@file:Suppress("UnsafeOptInUsageError")

package com.example.obsmobile

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Surface
import android.widget.Toast
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import com.pedro.common.ConnectChecker
import com.pedro.library.rtmp.RtmpStream

/**
 * بث رابط فيديو مباشرة (بدون التقاط شاشة): ExoPlayer يشغّل الرابط،
 * الصورة تروح لمحرك الرسم والصوت يروح للمشفّر، ثم RTMP. مستقل تمامًا عن StreamService.
 */
class DirectStreamService : Service() {

    companion object {
        const val ACTION_START = "direct_start"
        const val ACTION_STOP = "direct_stop"
        const val EXTRA_LINK = "link"
        const val EXTRA_URL = "url"
        const val EXTRA_REFERER = "referer"
        @Volatile var running = false
        @Volatile var health = 0
        @Volatile var liveBitrateK = 0
    }

    private val ui = Handler(Looper.getMainLooper())
    private var stream: RtmpStream? = null
    private var player: ExoPlayer? = null
    private var audioSrc: ExoAudioSource? = null
    private var link = ""
    private var retries = 0
    private var stopping = false

    private val replay = Runnable {
        val p = player ?: return@Runnable
        try { p.prepare(); p.play() } catch (e: Throwable) { AppLog.e("Direct", e, "فشل إعادة التشغيل") }
    }

    private val checker = object : ConnectChecker {
        override fun onConnectionStarted(url: String) {}
        override fun onConnectionSuccess() {
            health = 1
            toast("تم الاتصال، البث شغال")
        }
        override fun onConnectionFailed(reason: String) {
            AppLog.w("Direct", "فشل الاتصال: $reason")
            toast("فشل الاتصال: $reason")
            ui.post { stopAll() }
        }
        override fun onNewBitrate(bitrate: Long) { liveBitrateK = (bitrate / 1000).toInt() }
        override fun onDisconnect() { AppLog.i("Direct", "انقطع البث") }
        override fun onAuthError() { toast("خطأ مصادقة (تأكد من مفتاح البث)") }
        override fun onAuthSuccess() {}
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        AppLog.installCrashHandler(applicationContext)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                goForeground()
                try { start(intent) } catch (e: Throwable) {
                    AppLog.e("Direct", e, "تعذر بدء البث المباشر")
                    toast("تعذر بدء البث: ${e.message}")
                    stopAll()
                }
            }
            ACTION_STOP -> stopAll()
        }
        return START_NOT_STICKY
    }

    private fun start(intent: Intent) {
        link = intent.getStringExtra(EXTRA_LINK).orEmpty().trim()
        val url = intent.getStringExtra(EXTRA_URL).orEmpty().trim()
        val referer = intent.getStringExtra(EXTRA_REFERER).orEmpty().trim()
        if (link.isEmpty() || url.isEmpty()) { toast("الرابط أو وجهة البث فاضية"); stopAll(); return }

        stopping = false
        running = true
        health = 0
        retries = 0

        val st = SettingsStore.load(this)
        val h = (st.shortSide / 2) * 2
        val w = (st.shortSide * 16 / 9) / 2 * 2

        // ---- المشغّل ----
        val sonic = SonicAudioProcessor().apply { setOutputSampleRateHz(48000) }
        val a = ExoAudioSource().also { audioSrc = it }
        val tap = PcmTap { bytes -> a.push(bytes) }
        val renderers = object : DefaultRenderersFactory(this) {
            override fun buildAudioSink(
                context: Context,
                enableFloatOutput: Boolean,
                enableAudioTrackPlaybackParams: Boolean
            ): AudioSink? = DefaultAudioSink.Builder(context)
                .setAudioProcessors(arrayOf(sonic, tap))
                .build()
        }
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent("Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
            .setAllowCrossProtocolRedirects(true)
            .apply { if (referer.isNotEmpty()) setDefaultRequestProperties(mapOf("Referer" to referer)) }
        val p = ExoPlayer.Builder(this, renderers)
            .setMediaSourceFactory(DefaultMediaSourceFactory(DefaultDataSource.Factory(this, http)))
            .build()
        p.videoScalingMode = C.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING
        p.repeatMode = Player.REPEAT_MODE_ONE
        p.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                if (stopping) return
                retries++
                val delayMs = (2000L shl (retries - 1).coerceAtMost(3)).coerceAtMost(15_000L)
                AppLog.w("Direct", "خطأ بالرابط (${error.errorCodeName})، محاولة $retries بعد ${delayMs / 1000} ثواني")
                ui.removeCallbacks(replay)
                ui.postDelayed(replay, delayMs)
            }
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY) retries = 0
            }
        })
        player = p

        // ---- البث ----
        val v = ExoVideoSource { s: Surface? -> ui.post { try { player?.setVideoSurface(s) } catch (_: Throwable) {} } }
        val s = RtmpStream(applicationContext, checker, v, a)
        stream = s
        if (!s.prepareVideo(w, h, st.bitrateK * 1000, st.fps)) { toast("الجهاز ما قدر يشغّل الفيديو بهالإعدادات"); stopAll(); return }
        if (!s.prepareAudio(48000, true, 128 * 1000)) { toast("الجهاز ما يدعم إعدادات الصوت"); stopAll(); return }

        p.setMediaItem(MediaItem.fromUri(link))
        p.prepare()
        p.playWhenReady = true
        s.startStream(url)
        AppLog.i("Direct", "بدأ البث المباشر: ${w}x$h ${st.fps}fps ${st.bitrateK}kbps")
    }

    private fun stopAll() {
        stopping = true
        ui.removeCallbacks(replay)
        try { stream?.let { if (it.isStreaming) it.stopStream() } } catch (_: Throwable) {}
        try { stream?.release() } catch (_: Throwable) {}
        stream = null
        try { player?.release() } catch (_: Throwable) {}
        player = null
        audioSrc = null
        running = false; health = 0; liveBitrateK = 0
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun goForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel("stream", "Streaming", NotificationManager.IMPORTANCE_LOW))
        }
        val stopPi = android.app.PendingIntent.getService(
            this, 21, Intent(this, DirectStreamService::class.java).setAction(ACTION_STOP),
            android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT
        )
        val open = android.app.PendingIntent.getActivity(
            this, 22, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, "stream")
            .setContentTitle(getString(R.string.app_name))
            .setContentText("بث رابط مباشر (بدون شاشة)")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(null, "■ إيقاف البث", stopPi).build())
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        else startForeground(2, n)
    }

    private fun toast(msg: String) {
        AppLog.i("toast", msg)
        ui.post { Toast.makeText(applicationContext, msg, Toast.LENGTH_LONG).show() }
    }

    override fun onDestroy() {
        if (running) {
            stopping = true
            try { stream?.stopStream(); stream?.release() } catch (_: Throwable) {}
            try { player?.release() } catch (_: Throwable) {}
            running = false
        }
        super.onDestroy()
    }
}
