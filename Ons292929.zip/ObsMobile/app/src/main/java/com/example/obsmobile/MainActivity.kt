package com.example.obsmobile

import android.Manifest
import android.content.Intent
import android.graphics.BitmapFactory
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt
import kotlinx.coroutines.delay

private val ObsBg = Color(0xFF1B1B1B)
private val ObsPanel = Color(0xFF282828)
private val ObsBar = Color(0xFF3A3A3A)
private val ObsBlue = Color(0xFF2D7DD2)
private val ObsGreen = Color(0xFF2E9B4E)
private val ObsRed = Color(0xFFC0392B)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = ObsBlue, background = ObsBg, surface = ObsPanel,
                    onBackground = Color.White, onSurface = Color.White,
                    surfaceVariant = ObsBar, onSurfaceVariant = Color(0xFFDDDDDD)
                )
            ) {
                Surface(Modifier.fillMaxSize(), color = ObsBg) { Screen() }
            }
        }
    }

    @Composable
    fun Chips(options: List<Pair<String, String>>, selected: String, onPick: (String) -> Unit) {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            options.forEach { (v, label) ->
                FilterChip(selected = v == selected, onClick = { onPick(v) }, label = { Text(label) })
            }
        }
    }

    /** لوحة بعنوان مثل الـ Docks في OBS */
    @Composable
    fun Dock(title: String, trailing: (@Composable () -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
        Column(Modifier.fillMaxWidth().background(ObsPanel)) {
            Row(
                Modifier.fillMaxWidth().background(ObsBar).padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(title, color = Color(0xFFDDDDDD), fontSize = 13.sp, modifier = Modifier.weight(1f))
                trailing?.invoke()
            }
            Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp), content = content)
        }
    }

    // ---- جودة البث: البتات لكل بكسل (bpp) ----
    private val resOptions = listOf(240, 360, 480, 540, 720, 900, 960, 1080, 1200, 1440, 2160)

    /** الدقة الأصلية للشاشة = الضلع الأقصر */
    private fun nativeShort(): Int = realScreenSize(this).let { minOf(it.first, it.second) }

    private fun pixelsOf(s: StreamSettings): Double {
        val (w, h) = streamSizeFor(this, s.ratio, s.shortSide, assumeLandscape = s.ratio == "169")
        return w.toDouble() * h
    }

    private fun bpp(s: StreamSettings): Double = s.bitrateK * 1000.0 / (pixelsOf(s) * s.fps)

    /** أعلى دقة يبقى معها الـ bpp فوق الهدف */
    private fun suggestRes(s: StreamSettings, target: Double = 0.07): Int =
        resOptions.filter { bpp(s.copy(shortSide = it)) >= target }.maxOrNull() ?: resOptions.first()

    private fun preset(id: String, s: StreamSettings): StreamSettings = when (id) {
        "calm" -> s.copy(fps = 30, codec = "high").let { it.copy(shortSide = suggestRes(it, 0.07)) }
        "fast" -> s.copy(fps = 30, codec = "high").let { it.copy(shortSide = suggestRes(it, 0.12)) }
        "weak" -> s.copy(fps = 30, codec = "high", bitrateK = minOf(s.bitrateK, 2000))
            .let { it.copy(shortSide = suggestRes(it, 0.07)) }
        else -> s
    }

    private fun decodePreview(uri: String): android.graphics.Bitmap? = try {
        contentResolver.openInputStream(Uri.parse(uri))?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = 4 })
        }
    } catch (e: Exception) { null }

    /** معاينة تخطيط المشهد: اسحب أي عنصر لتحريكه */
    @Composable
    fun ScenePreview(
        sources: List<Source>, live: Boolean, muted: Boolean, modifier: Modifier, wide: Boolean,
        onMove: (Int, Float, Float) -> Unit, onDone: () -> Unit
    ) {
        val m = resources.displayMetrics
        val (rw0, rh0) = realScreenSize(this)
        val aspect = if (wide) maxOf(rw0, rh0).toFloat() / minOf(rw0, rh0) else m.widthPixels.toFloat() / m.heightPixels
        BoxWithConstraints(modifier.aspectRatio(aspect).clip(RoundedCornerShape(4.dp)).background(Color.Black)) {
            val wPx = constraints.maxWidth.toFloat()
            val hPx = constraints.maxHeight.toFloat()
            val wDp = maxWidth
            Box(Modifier.fillMaxSize()) {
                Text(if (sources.any { it.type == "screen" && it.visible }) "شاشة الهاتف" else "بدون شاشة", color = Color.Gray, modifier = Modifier.align(Alignment.Center))
                if (live) Text(
                    " ● LIVE ", color = Color.White, fontSize = 11.sp,
                    modifier = Modifier.align(Alignment.TopStart).background(Color.Red)
                )
                if (live && muted) Text(
                    " صامت ", color = Color.White, fontSize = 11.sp,
                    modifier = Modifier.align(Alignment.TopEnd).background(Color(0xFF555555))
                )
            }
            sources.forEachIndexed { i, s ->
                if (!s.visible) return@forEachIndexed // مخفي: ما يظهر في المعاينة
                val cur by rememberUpdatedState(s)
                val mod = Modifier
                    .offset { IntOffset((cur.x / 100f * wPx).roundToInt(), (cur.y / 100f * hPx).roundToInt()) }
                    .pointerInput(i) {
                        detectDragGestures(onDragEnd = onDone) { change, drag ->
                            change.consume()
                            onMove(i, drag.x / wPx * 100f, drag.y / hPx * 100f)
                        }
                    }
                when (s.type) {
                    "text" -> Text(
                        s.text, color = Color.White,
                        fontSize = (s.textSize * wDp.value / 720f).sp,
                        modifier = mod
                    )
                    "image" -> {
                        val bmp = remember(s.shownUri) { decodePreview(s.shownUri) }
                        if (bmp != null) Image(
                            bmp.asImageBitmap(), null,
                            modifier = mod.width(wDp * (s.scale / 100f)),
                            contentScale = ContentScale.FillWidth
                        ) else Box(mod.width(wDp * (s.scale / 100f)).aspectRatio(1f).background(Color.DarkGray))
                    }
                    "camera" -> Box(
                        mod.width(wDp * (s.scale / 100f)).aspectRatio(3f / 4f)
                            .clip(RoundedCornerShape(6.dp)).background(Color(0xFF3B6EA5)),
                        contentAlignment = Alignment.Center
                    ) { Text("كاميرا", color = Color.White, fontSize = 11.sp) }
                }
            }
        }
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    fun Screen() {
        val t0 = remember { TargetStore.load(this@MainActivity) }
        var platform by remember { mutableStateOf(t0.platform) }
        var server by remember { mutableStateOf(t0.server) }
        var streamKey by remember { mutableStateOf(t0.key) }
        var showKey by remember { mutableStateOf(false) }
        fun saveTarget() = TargetStore.save(this@MainActivity, StreamTarget(platform, server, streamKey))
        // الرابط الكامل = الخادم + / + المفتاح (فاضي = تسجيل فقط)
        fun fullUrl(): String =
            if (server.isBlank()) "" else server.trim().trimEnd('/') + "/" + streamKey.trim()
        var record by remember { mutableStateOf(false) }
        var pendingStream by remember { mutableStateOf(true) }
        var live by remember { mutableStateOf(StreamService.running) }
        var muted by remember { mutableStateOf(StreamService.muted) }
        var st by remember { mutableStateOf(SettingsStore.load(this@MainActivity)) }
        var scenes by remember { mutableStateOf(SceneStore.load(this@MainActivity)) }
        var active by remember {
            mutableIntStateOf(SceneStore.active(this@MainActivity).coerceIn(0, scenes.lastIndex))
        }
        var tab by remember { mutableIntStateOf(0) }
        var liveK by remember { mutableIntStateOf(0) }
        var goalK by remember { mutableIntStateOf(0) }
        var hot by remember { mutableStateOf(false) }
        var health by remember { mutableIntStateOf(0) }
        var retrying by remember { mutableStateOf(false) }
        var cutBusy by remember { mutableStateOf(false) }
        LaunchedEffect(live) {
            while (live) {
                liveK = StreamService.liveBitrateK
                goalK = StreamService.targetK
                hot = StreamService.thermalThrottled
                health = StreamService.health
                retrying = StreamService.reconnecting
                delay(1000)
            }
            liveK = 0; goalK = 0; hot = false; health = 0; retrying = false
        }

        fun sendApply() {
            if (live) startService(
                Intent(this@MainActivity, StreamService::class.java).setAction(StreamService.ACTION_APPLY)
            )
        }
        fun push() {
            SceneStore.save(this@MainActivity, scenes)
            SceneStore.setActive(this@MainActivity, active)
            sendApply()
        }
        fun switchScene() {
            SceneStore.setActive(this@MainActivity, active)
            if (live) startService(
                Intent(this@MainActivity, StreamService::class.java).setAction(StreamService.ACTION_SWITCH)
            )
        }
        fun saveSettings(n: StreamSettings) {
            st = n
            SettingsStore.save(this@MainActivity, n)
            sendApply()
        }
        fun editSources(f: (List<Source>) -> List<Source>) {
            scenes = scenes.mapIndexed { i, s -> if (i == active) s.copy(sources = f(s.sources)) else s }
        }
        fun needOverlay(): Boolean {
            if (Settings.canDrawOverlays(this@MainActivity)) return false
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return true
        }

        val pickImage = rememberLauncherForActivityResult(
            ActivityResultContracts.OpenDocument()
        ) { uri ->
            if (uri != null) {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                editSources { it + Source(type = "image", uri = uri.toString(), x = 60f, y = 5f) }
                push()
            }
        }

        val projection = rememberLauncherForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { r ->
            if (r.resultCode == RESULT_OK && r.data != null) {
                SceneStore.save(this@MainActivity, scenes)
                SceneStore.setActive(this@MainActivity, active)
                val i = Intent(this, StreamService::class.java).apply {
                    action = StreamService.ACTION_START
                    putExtra(StreamService.EXTRA_CODE, r.resultCode)
                    putExtra(StreamService.EXTRA_DATA, r.data)
                    putExtra(StreamService.EXTRA_URL, if (pendingStream) fullUrl() else "")
                    putExtra(StreamService.EXTRA_RECORD, if (pendingStream) record else true)
                }
                startForegroundService(i)
                live = true
                muted = st.audio == "none"
            }
        }

        val perms = rememberLauncherForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) {
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection.launch(mpm.createScreenCaptureIntent())
        }

        fun begin(stream: Boolean) {
            if (stream && server.isBlank()) {
                Toast.makeText(this@MainActivity, "حط وجهة البث من تبويب (وجهة البث) أو استخدم بدء التسجيل", Toast.LENGTH_LONG).show()
                return
            }
            if (stream && streamKey.isBlank()) {
                Toast.makeText(this@MainActivity, "اكتب مفتاح البث أولًا", Toast.LENGTH_SHORT).show()
                return
            }
            if (needOverlay()) {
                Toast.makeText(this@MainActivity, "فعّل (الظهور فوق التطبيقات) للتطبيق ثم ارجع واضغط ابدأ", Toast.LENGTH_LONG).show()
                return
            }
            pendingStream = stream
            val p = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA)
            if (Build.VERSION.SDK_INT >= 33) p += Manifest.permission.POST_NOTIFICATIONS
            perms.launch(p.toTypedArray())
        }

        val screenDp = resources.displayMetrics.let { it.heightPixels / it.density }
        val screenWDp = resources.displayMetrics.let { it.widthPixels / it.density }
        // ارتفاع المعاينة محدود عشان ما تغطي الشاشة وتخفي الأزرار (خصوصًا لو الجوال أفقي)
        val previewH = if (st.ratio == "169") {
            val (pw, ph) = realScreenSize(this)
            val asp = maxOf(pw, ph).toFloat() / minOf(pw, ph)
            minOf(screenWDp * 0.95f / asp, screenDp * 0.45f)
        } else screenDp * 0.36f
        val tabs = listOf("المشاهد", "المصادر", "مازج الصوت", "الإعدادات", "وجهة البث")

        Column(Modifier.fillMaxSize()) {
            // شريط العنوان
            Row(
                Modifier.fillMaxWidth().background(ObsBar).padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Stream Studio", fontSize = 16.sp, modifier = Modifier.weight(1f))
                if (live && health > 0) {
                    val hc = when (health) { 1 -> ObsGreen; 2 -> Color(0xFFE0A030); else -> ObsRed }
                    val ht = when {
                        retrying -> "إعادة اتصال…"
                        health == 1 -> "ممتاز"
                        health == 2 -> "النت ضعيف"
                        else -> "سيّئ"
                    }
                    Box(Modifier.size(10.dp).clip(RoundedCornerShape(50)).background(hc))
                    Text(" $ht  ", color = hc, fontSize = 12.sp)
                }
                if (live) Text(" ● LIVE ", color = Color.White, fontSize = 12.sp, modifier = Modifier.background(ObsRed))
            }

            // المعاينة الكبيرة
            Column(Modifier.fillMaxWidth().background(Color(0xFF111111)).padding(vertical = 6.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                    ScenePreview(
                        scenes[active].sources, live, muted,
                        Modifier.height(previewH.dp),
                        st.ratio == "169",
                        onMove = { i, dx, dy ->
                            editSources { l ->
                                l.mapIndexed { j, s ->
                                    if (j == i) s.copy(
                                        x = (s.x + dx).coerceIn(0f, 100f),
                                        y = (s.y + dy).coerceIn(0f, 100f)
                                    ) else s
                                }
                            }
                        },
                        onDone = { push() }
                    )
                }
                Text(
                    buildString {
                        append("${st.shortSide}p • ${st.fps} fps • ${st.bitrateK} kbps")
                        if (live) {
                            append(" • فعلي: $liveK kbps")
                            if (goalK in 1 until st.bitrateK) append(" • الهدف نزل إلى $goalK")
                            if (hot) append(" • 🔥 سخونة، الإطارات مخفضة")
                        }
                    },
                    color = Color.Gray, fontSize = 11.sp,
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }

            ScrollableTabRow(
                selectedTabIndex = tab, containerColor = ObsBar, contentColor = Color.White, edgePadding = 0.dp
            ) {
                tabs.forEachIndexed { i, t ->
                    Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t, fontSize = 13.sp) })
                }
            }

            Column(
                Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                when (tab) {
                    0 -> Dock("المشاهد") {
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            scenes.forEachIndexed { i, sc ->
                                FilterChip(
                                    selected = i == active,
                                    onClick = { active = i; switchScene() },
                                    label = { Text(sc.name) }
                                )
                            }
                            AssistChip(onClick = {
                                scenes = scenes + SceneStore.defaultScene("المشهد ${scenes.size + 1}")
                                active = scenes.lastIndex
                                push()
                            }, label = { Text("+ مشهد") })
                        }
                        if (scenes.size > 1) {
                            TextButton(onClick = {
                                scenes = scenes.filterIndexed { i, _ -> i != active }
                                active = 0
                                push()
                            }) { Text("حذف هذا المشهد") }
                        }
                        Text("اسحب أي عنصر في المعاينة لتحريكه", fontSize = 12.sp, color = Color.Gray)
                    }

                    1 -> {
                        Dock("المصادر — ${scenes[active].name}") {
                            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = {
                                    if (scenes[active].sources.none { it.type == "screen" }) {
                                        editSources { listOf(Source(type = "screen")) + it }
                                        push()
                                    }
                                }) { Text("+ بث شاشة") }
                                OutlinedButton(onClick = {
                                    editSources { it + Source(type = "text", text = "نص جديد") }
                                    push()
                                }) { Text("+ نص") }
                                OutlinedButton(onClick = { pickImage.launch(arrayOf("image/*")) }) { Text("+ صورة") }
                                OutlinedButton(onClick = {
                                    if (needOverlay()) return@OutlinedButton
                                    if (scenes[active].sources.none { it.type == "camera" }) {
                                        editSources { it + Source(type = "camera", text = "front", x = 62f, y = 60f, scale = 33f) }
                                        push()
                                    }
                                }) { Text("+ كاميرا") }
                            }
                            if (scenes[active].sources.isEmpty()) {
                                Text("ما فيه مصادر. أضف من الأزرار فوق.", fontSize = 12.sp, color = Color.Gray)
                            }
                        }
                        scenes[active].sources.forEachIndexed { idx, src ->
                            fun change(n: Source) = editSources { l -> l.mapIndexed { j, s -> if (j == idx) n else s } }
                            Dock(
                                (when (src.type) {
                                    "screen" -> "بث شاشة"; "text" -> "نص"; "camera" -> "كاميرا"; else -> "صورة"
                                }) + if (src.visible) "" else " (مخفي)",
                                trailing = {
                                    // العين: ضغطة تخفي المصدر من البث وتبقيه، وضغطة ثانية تظهره
                                    Text(
                                        "👁", fontSize = 20.sp,
                                        textDecoration = if (src.visible) TextDecoration.None else TextDecoration.LineThrough,
                                        modifier = Modifier
                                            .alpha(if (src.visible) 1f else 0.35f)
                                            .clickable { change(src.copy(visible = !src.visible)); push() }
                                            .padding(horizontal = 12.dp, vertical = 2.dp)
                                    )
                                }
                            ) {
                                if (src.type == "text") {
                                    OutlinedTextField(
                                        value = src.text, onValueChange = { change(src.copy(text = it)) },
                                        label = { Text("النص") }, modifier = Modifier.fillMaxWidth()
                                    )
                                }
                                if (src.type == "image") {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Switch(
                                            checked = src.noBg, enabled = !cutBusy,
                                            onCheckedChange = { on ->
                                                if (!on || src.cutout.isNotBlank()) {
                                                    change(src.copy(noBg = on)); push()
                                                } else {
                                                    cutBusy = true
                                                    val u = src.uri
                                                    BgRemover.cutout(this@MainActivity, u) { res ->
                                                        cutBusy = false
                                                        if (res == null) {
                                                            Toast.makeText(this@MainActivity, "تعذرت إزالة الخلفية", Toast.LENGTH_SHORT).show()
                                                        } else {
                                                            scenes = scenes.map { sc ->
                                                                sc.copy(sources = sc.sources.map {
                                                                    if (it.type == "image" && it.uri == u) it.copy(noBg = true, cutout = res) else it
                                                                })
                                                            }
                                                            push()
                                                        }
                                                    }
                                                }
                                            }
                                        )
                                        Text(if (cutBusy) "  جاري إزالة الخلفية…" else "  إزالة الخلفية")
                                    }
                                }
                                if (src.type == "camera") {
                                    Row {
                                        Switch(
                                            checked = src.text == "front",
                                            onCheckedChange = { change(src.copy(text = if (it) "front" else "back")); push() }
                                        )
                                        Text("  كاميرا أمامية", Modifier.padding(top = 12.dp))
                                    }
                                }
                                if (src.type == "screen") {
                                    Text("يبث شاشة الهاتف كاملة. احذفه من مشهد لو تبي المشهد بدون شاشة (صورة أو نص فقط).", fontSize = 12.sp, color = Color.Gray)
                                } else {
                                Text("أفقي")
                                Slider(src.x, { change(src.copy(x = it)) }, valueRange = 0f..100f,
                                    onValueChangeFinished = { push() })
                                Text("عمودي")
                                Slider(src.y, { change(src.copy(y = it)) }, valueRange = 0f..100f,
                                    onValueChangeFinished = { push() })
                                if (src.type == "text") {
                                    Text("حجم الخط")
                                    Slider(src.textSize, { change(src.copy(textSize = it)) }, valueRange = 10f..120f,
                                        onValueChangeFinished = { push() })
                                } else {
                                    Text("الحجم")
                                    Slider(src.scale, { change(src.copy(scale = it)) }, valueRange = 10f..100f,
                                        onValueChangeFinished = { push() })
                                }
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    if (src.type == "text") {
                                        TextButton(onClick = { push() }) { Text("تطبيق") }
                                    }
                                    TextButton(onClick = {
                                        editSources { l -> l.filterIndexed { j, _ -> j != idx } }
                                        push()
                                    }) { Text("حذف") }
                                }
                            }
                        }
                    }

                    2 -> Dock("مازج الصوت") {
                        Text("مصدر الصوت (يطبق عند بدء بث جديد)")
                        Chips(
                            listOf("mic" to "المايك", "internal" to "صوت النظام (أندرويد 10+)", "none" to "بدون"),
                            st.audio
                        ) { saveSettings(st.copy(audio = it)) }
                        if (live) {
                            OutlinedButton(
                                onClick = {
                                    startService(Intent(this@MainActivity, StreamService::class.java)
                                        .setAction(StreamService.ACTION_MUTE))
                                    muted = !muted
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text(if (muted) "تشغيل الصوت" else "كتم الصوت") }
                        } else {
                            Text("كتم الصوت يظهر لما يبدأ البث", fontSize = 12.sp, color = Color.Gray)
                        }
                    }

                    3 -> {
                        Dock("الفيديو") {
                            Text("إعدادات جاهزة (تحسب الدقة المناسبة لبت ريتك)")
                            Chips(
                                listOf("calm" to "هادي ونظيف", "fast" to "حركة سريعة", "weak" to "نت ضعيف"),
                                ""
                            ) { saveSettings(preset(it, st)) }
                            val nat = nativeShort()
                            Text("الدقة (تطبق عند بدء بث جديد) • دقة شاشتك الأصلية: ${nat}p")
                            Chips(
                                (resOptions + nat).distinct().sorted().map { v ->
                                    v.toString() to (if (v == nat) "الأصلية ${v}p" else "${v}p")
                                },
                                st.shortSide.toString()
                            ) { saveSettings(st.copy(shortSide = it.toInt())) }
                            Text("نسبة البث (تطبق عند بدء بث جديد)")
                            Chips(
                                listOf("auto" to "حسب الشاشة", "169" to "أفقي (بدون تمدد)"),
                                st.ratio
                            ) { saveSettings(st.copy(ratio = it)) }
                            if (st.ratio == "169") {
                                Text("دوّر الجوال أفقي قبل البدء. الصورة ما تتمدد أبدًا: يثبّت 16:9 لو شاشتك قريبة منها، وإلا يبقي نسبة شاشتك.", fontSize = 12.sp, color = Color.Gray)
                            }
                            Text("ترميز الفيديو (تطبق عند بدء بث جديد)")
                            Chips(
                                listOf("auto" to "عادي", "high" to "High (أوضح)"),
                                st.codec
                            ) { saveSettings(st.copy(codec = it)) }
                            Text("الإطارات")
                            Chips(
                                listOf("15" to "15", "24" to "24", "30" to "30", "48" to "48", "60" to "60"),
                                st.fps.toString()
                            ) { saveSettings(st.copy(fps = it.toInt())) }
                            Text("البت ريت: ${st.bitrateK} kbps")
                            Chips(
                                listOf("1000" to "1000", "2500" to "2500", "4000" to "4000",
                                    "6000" to "6000", "8000" to "8000", "12000" to "12000", "20000" to "20000"),
                                st.bitrateK.toString()
                            ) { saveSettings(st.copy(bitrateK = it.toInt())) }
                            Slider(
                                st.bitrateK.toFloat().coerceIn(500f, 20000f),
                                { st = st.copy(bitrateK = (it / 250).toInt() * 250) },
                                valueRange = 500f..20000f,
                                onValueChangeFinished = { saveSettings(st) }
                            )
                            val q = bpp(st)
                            val qText: String
                            val qColor: Color
                            when {
                                q < 0.05 -> { qText = "⚠ البت ريت قليل على هالدقة (%.3f بت/بكسل). راح تطلع الصورة مكعبات.".format(q); qColor = ObsRed }
                                q < 0.08 -> { qText = "مقبول للمحتوى الهادي بس (%.3f بت/بكسل). للحركة السريعة نزّل الدقة.".format(q); qColor = Color(0xFFE0A030) }
                                else -> { qText = "✓ البت ريت مناسب للدقة (%.3f بت/بكسل).".format(q); qColor = ObsGreen }
                            }
                            Text(qText, color = qColor, fontSize = 12.sp)
                            if (q < 0.07) {
                                val sug = suggestRes(st)
                                if (sug != st.shortSide) TextButton(onClick = { saveSettings(st.copy(shortSide = sug)) }) {
                                    Text("طبّق الدقة المقترحة: ${sug}p")
                                }
                            }
                            Text("عدّاد قبل بدء البث (ثواني)")
                            Chips(
                                listOf("0" to "بدون", "3" to "3", "5" to "5", "10" to "10"),
                                st.countdown.toString()
                            ) { saveSettings(st.copy(countdown = it.toInt())) }
                        }
                        Dock("التأثيرات") {
                            Text("فلتر الفيديو (يطبق مباشرة)")
                            Chips(
                                listOf("none" to "بدون", "gray" to "أبيض وأسود", "sepia" to "سيبيا", "negative" to "سلبي"),
                                st.filter
                            ) { saveSettings(st.copy(filter = it)) }
                            Text("الانتقال بين المشاهد")
                            Chips(listOf("none" to "قطع", "fade" to "تلاشي", "wipe" to "مسح"), st.transition) {
                                saveSettings(st.copy(transition = it))
                            }
                            if (st.transition != "none") {
                                Text("مدة الانتقال: ${st.transMs} ms")
                                Slider(
                                    st.transMs.toFloat(), { st = st.copy(transMs = (it / 100).toInt() * 100) },
                                    valueRange = 200f..1500f,
                                    onValueChangeFinished = { saveSettings(st) }
                                )
                            }
                        }
                    }

                    else -> Dock("وجهة البث") {
                        Chips(Platforms.list.map { it.first to it.second }, platform) { p ->
                            saveTarget()
                            val t = TargetStore.loadFor(this@MainActivity, p)
                            platform = p; server = t.server; streamKey = t.key
                            saveTarget()
                        }
                        Text(Platforms.hint(platform), fontSize = 12.sp, color = Color.Gray)
                        OutlinedTextField(
                            value = server, onValueChange = { server = it; saveTarget() },
                            label = { Text("رابط الخادم Server URL") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = streamKey, onValueChange = { streamKey = it; saveTarget() },
                            label = { Text("مفتاح البث Stream Key") },
                            singleLine = true,
                            visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Row {
                            Checkbox(checked = showKey, onCheckedChange = { showKey = it })
                            Text("إظهار المفتاح", Modifier.padding(top = 12.dp))
                        }
                        Row {
                            Checkbox(checked = record, onCheckedChange = { record = it })
                            Text("تسجيل محلي مع البث", Modifier.padding(top = 12.dp))
                        }
                    }
                }
            }

            // شريط التحكم السفلي مثل Controls في OBS
            Row(
                Modifier.fillMaxWidth().background(ObsBar).padding(8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (!live) {
                    Button(
                        onClick = { begin(true) },
                        colors = ButtonDefaults.buttonColors(containerColor = ObsBlue),
                        modifier = Modifier.weight(1f)
                    ) { Text("بدء البث") }
                    Button(
                        onClick = { begin(false) },
                        colors = ButtonDefaults.buttonColors(containerColor = ObsGreen),
                        modifier = Modifier.weight(1f)
                    ) { Text("بدء التسجيل") }
                } else {
                    Button(
                        onClick = {
                            startService(Intent(this@MainActivity, StreamService::class.java)
                                .setAction(StreamService.ACTION_STOP))
                            live = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ObsRed),
                        modifier = Modifier.weight(1f)
                    ) { Text("إيقاف") }
                }
            }
        }
    }
}
