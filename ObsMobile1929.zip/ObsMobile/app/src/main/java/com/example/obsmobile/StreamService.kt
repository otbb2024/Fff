package com.example.obsmobile

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.content.IntentCompat
import com.pedro.common.ConnectChecker
import com.pedro.encoder.input.gl.render.filters.GreyScaleFilterRender
import com.pedro.encoder.input.gl.render.filters.NegativeFilterRender
import com.pedro.encoder.input.gl.render.filters.SepiaFilterRender
import com.pedro.encoder.input.gl.render.filters.`object`.ImageObjectFilterRender
import com.pedro.encoder.input.gl.render.filters.`object`.TextObjectFilterRender
import com.pedro.library.rtmp.RtmpDisplay
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.min

class StreamService : Service() {

    companion object {
        const val ACTION_START = "start"
        const val ACTION_STOP = "stop"
        const val ACTION_APPLY = "apply"   // تبديل المشهد / تحديث المصادر والفلتر
        const val ACTION_MUTE = "mute"     // كتم / تشغيل الصوت
        const val ACTION_SWITCH = "switch" // تبديل المشهد مع انتقال
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val EXTRA_URL = "url"
        const val EXTRA_RECORD = "record"
        @Volatile var running = false
        @Volatile var muted = false
    }

    private var display: RtmpDisplay? = null
    private var camera: CameraOverlay? = null
    private var camSig: String? = null
    private var streamW = 1280
    private var streamH = 720
    private val ui = Handler(Looper.getMainLooper())

    private val checker = object : ConnectChecker {
        override fun onConnectionStarted(url: String) {}
        override fun onConnectionSuccess() { toast("تم الاتصال، البث شغال") }
        override fun onConnectionFailed(reason: String) {
            toast("فشل الاتصال: $reason")
            stopAll()
        }
        override fun onNewBitrate(bitrate: Long) {}
        override fun onDisconnect() { toast("انقطع البث") }
        override fun onAuthError() { toast("خطأ مصادقة") }
        override fun onAuthSuccess() {}
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> start(intent)
            ACTION_APPLY -> if (transitioning) ui.postDelayed({ applyScene() }, 800) else applyScene()
            ACTION_SWITCH -> switchScene()
            ACTION_MUTE -> toggleMute()
            ACTION_STOP -> stopAll()
        }
        return START_NOT_STICKY
    }

    private fun start(intent: Intent) {
        goForeground()

        val code = intent.getIntExtra(EXTRA_CODE, 0)
        val data = IntentCompat.getParcelableExtra(intent, EXTRA_DATA, Intent::class.java)
        val url = intent.getStringExtra(EXTRA_URL).orEmpty().trim()
        val record = intent.getBooleanExtra(EXTRA_RECORD, false)
        if (data == null) { stopAll(); return }

        val st = SettingsStore.load(this)
        val d = display ?: RtmpDisplay(applicationContext, true, checker).also { display = it }
        d.setIntentResult(code, data)

        val m = resources.displayMetrics
        val scale = st.shortSide.toFloat() / min(m.widthPixels, m.heightPixels)
        streamW = (m.widthPixels * scale).toInt() / 2 * 2
        streamH = (m.heightPixels * scale).toInt() / 2 * 2

        val videoOk = d.prepareVideo(streamW, streamH, st.fps, st.bitrateK * 1000, 0, m.densityDpi)
        val audioOk = if (st.audio == "internal" && Build.VERSION.SDK_INT >= 29)
            d.prepareInternalAudio(128 * 1000, 44100, true, false, false)
        else d.prepareAudio(128 * 1000, 44100, true, false, false)

        if (!videoOk || !audioOk) { toast("الجهاز ما يدعم هذي الإعدادات"); stopAll(); return }

        if (record) {
            val dir = getExternalFilesDir(android.os.Environment.DIRECTORY_MOVIES)!!
            val name = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val file = File(dir, "rec_$name.mp4")
            d.startRecord(file.absolutePath)
            toast("التسجيل في: ${file.absolutePath}")
        }
        if (url.isNotEmpty()) d.startStream(url)
        running = true

        muted = st.audio == "none"
        if (muted) d.disableAudio()

        // نطبق المشهد بعد ما يشتغل الـ OpenGL
        ui.postDelayed({ applyScene() }, 800)
    }

    private var transitioning = false
    private val black1: Bitmap by lazy {
        Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888).apply { eraseColor(Color.BLACK) }
    }

    /** يبدّل المشهد مع انتقال: تغطية بالأسود، تبديل المشهد، ثم كشف */
    private fun switchScene() {
        val st = SettingsStore.load(this)
        val gl = try { display?.glInterface } catch (e: Exception) { null }
        if (gl == null || st.transition == "none" || transitioning) { applyScene(); return }
        transitioning = true
        val half = (st.transMs / 2).coerceAtLeast(100).toLong()
        var f = ImageObjectFilterRender()
        gl.addFilter(f)
        var swapped = false
        val begin = SystemClock.uptimeMillis()

        // frac: نسبة التغطية من 0 إلى 1
        fun style(filter: ImageObjectFilterRender, frac: Float, reveal: Boolean) {
            if (st.transition == "wipe") {
                val w = (frac * 100f).coerceIn(0.5f, 100f)
                filter.setImage(black1)
                filter.setScale(w, 100f)
                filter.setPosition(if (reveal) 100f - w else 0f, 0f)
            } else { // fade
                val bmp = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)
                bmp.eraseColor(Color.argb((frac * 255).toInt().coerceIn(0, 255), 0, 0, 0))
                filter.setImage(bmp)
                filter.setScale(100f, 100f)
                filter.setPosition(0f, 0f)
            }
        }

        val tick = object : Runnable {
            override fun run() {
                val t = SystemClock.uptimeMillis() - begin
                try {
                    if (t >= half * 2) {
                        if (gl.filtersCount() > 0) gl.removeFilter(gl.filtersCount() - 1)
                        transitioning = false
                        return
                    }
                    if (t < half) {
                        style(f, t.toFloat() / half, false)
                    } else {
                        if (!swapped) {
                            swapped = true
                            applyScene()                 // يمسح الفلاتر ويرسم المشهد الجديد
                            f = ImageObjectFilterRender()
                            gl.addFilter(f)              // الغطاء فوق كل شي
                        }
                        style(f, 1f - (t - half).toFloat() / half, true)
                    }
                    ui.postDelayed(this, 33)
                } catch (e: Exception) {
                    transitioning = false
                    applyScene()
                }
            }
        }
        ui.post(tick)
    }

    private fun toggleMute() {
        val d = display ?: return
        if (muted) d.enableAudio() else d.disableAudio()
        muted = !muted
    }

    /** يطبق الفلتر العام + مصادر المشهد النشط (نص، صورة، كاميرا) */
    private fun applyScene() {
        val d = display ?: return
        val st = SettingsStore.load(this)
        val scenes = SceneStore.load(this)
        val scene = scenes.getOrNull(SceneStore.active(this).coerceIn(0, scenes.lastIndex)) ?: return
        try {
            val gl = d.glInterface
            gl.clearFilters()
            forceRender(gl, st.fps)
            // لو المشهد ما فيه "بث شاشة" نغطي الشاشة بالأسود
            if (scene.sources.none { it.type == "screen" }) {
                val bg = ImageObjectFilterRender()
                gl.addFilter(bg)
                bg.setImage(black1)
                bg.setScale(100f, 100f)
                bg.setPosition(0f, 0f)
            }
            fun addGlobalFilter() {
                when (st.filter) {
                    "gray" -> gl.addFilter(GreyScaleFilterRender())
                    "sepia" -> gl.addFilter(SepiaFilterRender())
                    "negative" -> gl.addFilter(NegativeFilterRender())
                }
            }
            addGlobalFilter()
            scene.sources.forEach { s ->
                when (s.type) {
                    "text" -> if (s.text.isNotBlank()) {
                        val f = TextObjectFilterRender()
                        gl.addFilter(f)
                        f.setText(s.text, s.textSize, Color.WHITE)
                        f.setPosition(s.x, s.y)
                    }
                    "image" -> loadBitmap(s.uri)?.let { bmp ->
                        val f = ImageObjectFilterRender()
                        gl.addFilter(f)
                        f.setImage(bmp)
                        val hPct = s.scale * bmp.height / bmp.width * streamW / streamH
                        f.setScale(s.scale, hPct)
                        f.setPosition(s.x, s.y)
                    }
                }
            }
        } catch (e: Exception) {
            toast("تعذر تطبيق المشهد: ${e.message}")
        }
        applyCamera(scene)
    }

    /**
     * أندرويد ما يرسل إطارات التقاط الشاشة إلا إذا تغيّرت الشاشة. لو الشاشة ثابتة
     * يوصل صوت بدون صورة فيرفضه تلقرام. هنا نجبر المكتبة ترسم إطارات باستمرار.
     */
    private fun forceRender(gl: Any, fps: Int) {
        try {
            val two = gl.javaClass.methods.firstOrNull { it.name == "setForceRender" && it.parameterTypes.size == 2 }
            if (two != null) { two.invoke(gl, true, fps); return }
            val one = gl.javaClass.methods.firstOrNull { it.name == "setForceRender" && it.parameterTypes.size == 1 }
            one?.invoke(gl, true)
        } catch (_: Exception) {}
    }

    private fun applyCamera(scene: Scene) {
        val src = scene.sources.firstOrNull { it.type == "camera" }
        if (src == null) {
            camera?.hide(); camSig = null
            return
        }
        if (!Settings.canDrawOverlays(this) ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED
        ) {
            toast("الكاميرا تحتاج صلاحية الكاميرا والظهور فوق التطبيقات")
            return
        }
        val m = resources.displayMetrics
        val w = (src.scale / 100f * m.widthPixels).toInt()
        val x = (src.x / 100f * m.widthPixels).toInt()
        val y = (src.y / 100f * m.heightPixels).toInt()
        val sig = "${src.text}|$w|$x|$y"
        val cam = camera ?: CameraOverlay(this).also { camera = it }
        if (sig != camSig || !cam.isShowing) {
            cam.show(src.text == "front", w, x, y)
            camSig = sig
        }
    }

    private fun loadBitmap(uri: String): Bitmap? = try {
        contentResolver.openInputStream(Uri.parse(uri))?.use { BitmapFactory.decodeStream(it) }?.let {
            if (it.width > 1280) Bitmap.createScaledBitmap(it, 1280, it.height * 1280 / it.width, true) else it
        }
    } catch (e: Exception) { null }

    private fun stopAll() {
        transitioning = false
        camera?.hide(); camera = null; camSig = null
        display?.let {
            if (it.isRecording) it.stopRecord()
            if (it.isStreaming) it.stopStream()
        }
        display = null
        running = false
        muted = false
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun goForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel("stream", "Streaming", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val n = Notification.Builder(this, "stream")
            .setContentTitle(getString(R.string.app_name))
            .setContentText("البث / التسجيل شغال")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            if (Build.VERSION.SDK_INT >= 30) {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
                    type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
                    type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            }
            startForeground(1, n, type)
        } else startForeground(1, n)
    }

    private fun toast(msg: String) =
        ui.post { Toast.makeText(applicationContext, msg, Toast.LENGTH_LONG).show() }

    override fun onDestroy() { stopAll(); super.onDestroy() }
}
