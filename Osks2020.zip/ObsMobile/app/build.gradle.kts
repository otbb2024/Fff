plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.example.obsmobile"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.obsmobile"
        minSdk = 24
        targetSdk = 34
        // رقم الإصدار يزيد تلقائيًا مع كل بناء في GitHub عشان التحديث ينزل فوق القديم
        versionCode = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()
        versionName = "0.${System.getenv("GITHUB_RUN_NUMBER") ?: "1"}"
    }
    // توقيع ثابت: نفس المفتاح في كل بناء، فالتحديث يركب فوق التطبيق بدون حذف
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }
    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.camera:camera-core:1.3.4")
    implementation("androidx.camera:camera-camera2:1.3.4")
    implementation("androidx.camera:camera-lifecycle:1.3.4")
    implementation("androidx.camera:camera-view:1.3.4")
    // البث والتسجيل (RTMP + MediaCodec)
    implementation("com.github.pedroSG94.RootEncoder:library:2.5.5")
}
