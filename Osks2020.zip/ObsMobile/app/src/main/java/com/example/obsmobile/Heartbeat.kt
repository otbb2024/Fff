package com.example.obsmobile

import android.content.Context
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager

/**
 * نبضة صغيرة: مربع 4×4 بكسل بزاوية الشاشة يتبدل لونه بين أسود وأسود فاتح كل 100ms.
 * أندرويد ما يرسل صور التقاط الشاشة إلا لما تتغير الشاشة، فلو الشاشة ثابتة ما يطلع
 * فيديو لتلقرام. هذي النبضة تخلي الشاشة "تتغير" دائمًا فيشتغل البث علطول.
 */
class Heartbeat(private val ctx: Context) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val ui = Handler(Looper.getMainLooper())
    private var view: View? = null
    private var on = false

    private val tick = object : Runnable {
        override fun run() {
            val v = view ?: return
            v.setBackgroundColor(if (on) 0xFF000000.toInt() else 0xFF0C0C0C.toInt())
            on = !on
            ui.postDelayed(this, 100)
        }
    }

    fun start() {
        if (view != null) return
        try {
            val v = View(ctx)
            val lp = WindowManager.LayoutParams(
                4, 4,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON, // الشاشة ما تنطفي طول البث
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.BOTTOM or Gravity.START }
            wm.addView(v, lp)
            view = v
            ui.post(tick)
        } catch (_: Exception) {
            view = null
        }
    }

    fun stop() {
        ui.removeCallbacks(tick)
        try { view?.let { wm.removeView(it) } } catch (_: Exception) {}
        view = null
    }
}
