package com.example.obsmobile

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView

/**
 * عدّاد تنازلي يظهر فوق كل التطبيقات قبل بدء البث، عشان تلحق تفتح اللعبة وتجهّز.
 * يظهر قبل بدء التقاط الشاشة فما يطلع في البث نفسه.
 */
class Countdown(private val ctx: Context) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val ui = Handler(Looper.getMainLooper())
    private var view: TextView? = null
    private var cancelled = false

    fun start(seconds: Int, onDone: () -> Unit) {
        val tv = try {
            TextView(ctx).apply {
                textSize = 96f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                setPadding(90, 30, 90, 30)
                background = GradientDrawable().apply {
                    setColor(0xB0000000.toInt())
                    cornerRadius = 48f
                }
            }.also {
                val lp = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                        WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                    PixelFormat.TRANSLUCENT
                ).apply { gravity = Gravity.CENTER }
                wm.addView(it, lp)
            }
        } catch (_: Exception) { null }

        if (tv == null) { onDone(); return } // ما قدرنا نعرض العدّاد، نبدأ علطول
        view = tv

        var left = seconds
        val tick = object : Runnable {
            override fun run() {
                if (cancelled) return
                if (left <= 0) {
                    remove()
                    onDone()
                    return
                }
                tv.text = left.toString()
                left--
                ui.postDelayed(this, 1000)
            }
        }
        ui.post(tick)
    }

    fun cancel() {
        cancelled = true
        ui.removeCallbacksAndMessages(null)
        remove()
    }

    private fun remove() {
        try { view?.let { wm.removeView(it) } } catch (_: Exception) {}
        view = null
    }
}
