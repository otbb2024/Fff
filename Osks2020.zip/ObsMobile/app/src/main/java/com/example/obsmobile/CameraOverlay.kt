package com.example.obsmobile

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry

/**
 * نافذة كاميرا عائمة فوق الشاشة. لأن التقاط الشاشة (MediaProjection)
 * يلتقط كل شيء ظاهر، الكاميرا تطلع تلقائيًا في البث والتسجيل.
 * يمكن سحبها بالإصبع.
 */
class CameraOverlay(private val ctx: Context) : LifecycleOwner {

    private val registry = LifecycleRegistry(this)
    override val lifecycle: Lifecycle get() = registry

    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var view: PreviewView? = null
    private var provider: ProcessCameraProvider? = null

    val isShowing get() = view != null

    @SuppressLint("ClickableViewAccessibility")
    fun show(front: Boolean, widthPx: Int, x: Int, y: Int) {
        hide()
        val pv = PreviewView(ctx).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
        val lp = WindowManager.LayoutParams(
            widthPx, widthPx * 4 / 3,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; this.x = x; this.y = y }

        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0
        pv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { downX = e.rawX; downY = e.rawY; startX = lp.x; startY = lp.y }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = startX + (e.rawX - downX).toInt()
                    lp.y = startY + (e.rawY - downY).toInt()
                    wm.updateViewLayout(pv, lp)
                }
            }
            true
        }
        wm.addView(pv, lp)
        view = pv
        registry.currentState = Lifecycle.State.STARTED

        val future = ProcessCameraProvider.getInstance(ctx)
        future.addListener({
            val p = future.get()
            provider = p
            val preview = Preview.Builder().build().also { it.setSurfaceProvider(pv.surfaceProvider) }
            p.unbindAll()
            p.bindToLifecycle(
                this, if (front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA,
                preview
            )
        }, ContextCompat.getMainExecutor(ctx))
    }

    fun hide() {
        provider?.unbindAll()
        view?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        view = null
    }
}
