package com.example.obsmobile

import android.content.Context
import android.graphics.SurfaceTexture
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.view.Surface
import com.pedro.encoder.input.gl.render.filters.`object`.SurfaceFilterRender
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import java.io.File

/**
 * يشغّل فيديو VLC ويرسمه داخل البث مباشرة (مو فوق الشاشة)،
 * فواجهة التطبيق ما تطلع في البث.
 */
class VlcGl(private val ctx: Context) {

    private var vlc: LibVLC? = null
    private var player: MediaPlayer? = null
    private var pfd: ParcelFileDescriptor? = null
    private var surface: Surface? = null
    private var playingUri: String? = null

    fun createFilter(uri: String): SurfaceFilterRender =
        SurfaceFilterRender { st -> attach(uri, st) }

    private fun attach(uri: String, st: SurfaceTexture) {
        try {
            st.setDefaultBufferSize(1280, 720)
            val newSurface = Surface(st)
            val v = vlc ?: LibVLC(ctx).also { vlc = it }
            val p = player ?: MediaPlayer(v).also { player = it }
            val vout = p.getVLCVout()
            try { vout.detachViews() } catch (_: Exception) {}
            try { surface?.release() } catch (_: Exception) {}
            surface = newSurface
            vout.setVideoSurface(newSurface, null)
            vout.setWindowSize(1280, 720)
            vout.attachViews()

            if (playingUri != uri) {
                val media = when {
                    uri.startsWith("content://") -> {
                        try { pfd?.close() } catch (_: Exception) {}
                        val d = ctx.contentResolver.openFileDescriptor(Uri.parse(uri), "r")
                        pfd = d
                        Media(v, d!!.fileDescriptor)
                    }
                    uri.startsWith("/") -> Media(v, Uri.fromFile(File(uri)))
                    else -> Media(v, Uri.parse(uri))
                }
                media.addOption(":input-repeat=65535")
                p.media = media
                media.release()
                playingUri = uri
                p.play()
            } else if (!p.isPlaying) {
                p.play()
            }
        } catch (e: Exception) {
            // نتجاهل الخطأ، المشهد يبقى شغال بدون الفيديو
        }
    }

    fun release() {
        try { player?.stop() } catch (_: Exception) {}
        try { player?.getVLCVout()?.detachViews() } catch (_: Exception) {}
        try { player?.release() } catch (_: Exception) {}
        try { vlc?.release() } catch (_: Exception) {}
        try { pfd?.close() } catch (_: Exception) {}
        try { surface?.release() } catch (_: Exception) {}
        player = null; vlc = null; pfd = null; surface = null; playingUri = null
    }
}
