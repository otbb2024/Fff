@file:Suppress("UnsafeOptInUsageError")

package com.example.obsmobile

import android.graphics.SurfaceTexture
import android.view.Surface
import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import com.pedro.encoder.Frame
import com.pedro.encoder.input.audio.GetMicrophoneData
import com.pedro.encoder.input.sources.audio.AudioSource
import com.pedro.encoder.input.sources.video.VideoSource
import java.nio.ByteBuffer

/**
 * مصدر فيديو للبث: يعطي ExoPlayer سطح (Surface) مربوط بمحرك الرسم حق RootEncoder،
 * فالصورة تنرسم مباشرة للبث بدون التقاط شاشة.
 */
class ExoVideoSource(private val onSurface: (Surface?) -> Unit) : VideoSource() {
    private var w = 1280
    private var h = 720
    private var surface: Surface? = null
    private var active = false

    override fun create(width: Int, height: Int, fps: Int, rotation: Int): Boolean {
        w = width; h = height
        return true
    }

    override fun start(surfaceTexture: SurfaceTexture) {
        try { surfaceTexture.setDefaultBufferSize(w, h) } catch (_: Throwable) {}
        val s = Surface(surfaceTexture)
        surface = s
        active = true
        onSurface(s)
    }

    override fun stop() {
        active = false
        onSurface(null)
        try { surface?.release() } catch (_: Throwable) {}
        surface = null
    }

    override fun release() {}

    override fun isRunning(): Boolean = active
}

/**
 * مصدر صوت للبث: يستقبل صوت الفيديو (PCM ستيريو 48kHz) من المشغّل ويرسله للمشفّر مباشرة.
 */
class ExoAudioSource : AudioSource() {
    private var callback: GetMicrophoneData? = null
    private var active = false

    override fun create(sampleRate: Int, isStereo: Boolean, echoCanceler: Boolean, noiseSuppressor: Boolean): Boolean = true

    override fun start(getMicrophoneData: GetMicrophoneData) {
        callback = getMicrophoneData
        active = true
    }

    override fun stop() {
        active = false
        callback = null
    }

    override fun release() {}

    override fun isRunning(): Boolean = active

    @Volatile var pushedBytes = 0L

    /** يستقبل بايتات PCM 16-bit ستيريو ويقسمها لقطع صغيرة يقبلها المشفّر */
    fun push(bytes: ByteArray) {
        if (!active || bytes.isEmpty()) return
        val cb = callback ?: return
        val base = System.nanoTime() / 1000
        var off = 0
        while (off < bytes.size) {
            val n = minOf(2048, bytes.size - off)
            val ts = base + (off / 4) * 1_000_000L / 48000
            cb.inputPCMData(Frame(bytes, off, n, ts))
            off += n
        }
        pushedBytes += bytes.size
    }
}

/**
 * معالج صوت داخل ExoPlayer: يمرّر الصوت كما هو للسماعة، وينسخ نسخة ستيريو 16-bit للبث.
 */
class PcmTap(private val onPcm: (ByteArray) -> Unit) : BaseAudioProcessor() {
    private var channels = 2

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT) return AudioProcessor.AudioFormat.NOT_SET
        channels = inputAudioFormat.channelCount
        return inputAudioFormat
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val size = inputBuffer.remaining()
        if (size == 0) return
        val src = ByteArray(size)
        inputBuffer.duplicate().get(src)
        try { onPcm(toStereo(src, channels)) } catch (_: Throwable) {}
        val out = replaceOutputBuffer(size)
        out.put(inputBuffer)
        out.flip()
    }

    private fun toStereo(src: ByteArray, ch: Int): ByteArray {
        if (ch == 2) return src
        val frames = src.size / (2 * ch)
        val out = ByteArray(frames * 4)
        for (i in 0 until frames) {
            val s = i * 2 * ch
            val o = i * 4
            out[o] = src[s]; out[o + 1] = src[s + 1]
            if (ch == 1) { out[o + 2] = src[s]; out[o + 3] = src[s + 1] }
            else { out[o + 2] = src[s + 2]; out[o + 3] = src[s + 3] }
        }
        return out
    }
}
