package com.example.newsglow

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.text.InputType
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class SourcesActivity : Activity() {

    private lateinit var listBox: LinearLayout
    private var feeds = mutableListOf<Feed>()
    private var changed = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        feeds = FeedStore.all(this).toMutableList()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        root.addView(TextView(this).apply {
            text = "إدارة المصادر"
            textSize = 20f
        })
        root.addView(TextView(this).apply {
            text = "أضف أو عدّل أو احذف أي مصدر أخبار (رابط RSS يبدأ بـ https). المفتاح لتشغيل/إيقاف المصدر."
            textSize = 13f
            alpha = 0.75f
            setPadding(0, dp(6), 0, dp(10))
        })

        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun barBtn(label: String, action: () -> Unit) {
            bar.addView(Button(this).apply {
                text = label
                textSize = 12f
                setOnClickListener { action() }
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        barBtn("➕ إضافة") { showFeedDialog(-1) }
        barBtn("↺ الافتراضي") {
            AlertDialog.Builder(this).setMessage("ترجيع المصادر الافتراضية؟ (يحذف تعديلاتك)")
                .setPositiveButton("نعم") { _, _ ->
                    FeedStore.resetDefaults(this)
                    feeds = FeedStore.all(this).toMutableList()
                    changed = true
                    render()
                }.setNegativeButton("إلغاء", null).show()
        }
        barBtn("🗑 حذف الكل") {
            AlertDialog.Builder(this).setMessage("حذف كل المصادر؟")
                .setPositiveButton("حذف") { _, _ -> feeds.clear(); persist() }
                .setNegativeButton("إلغاء", null).show()
        }
        root.addView(bar)

        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(listBox)
        setContentView(ScrollView(this).apply { addView(root) })
        render()
    }

    private fun persist() {
        FeedStore.save(this, feeds)
        changed = true
        render()
    }

    private fun render() {
        listBox.removeAllViews()
        if (feeds.isEmpty()) {
            listBox.addView(TextView(this).apply {
                text = "لا توجد مصادر. اضغط ➕ إضافة."
                setPadding(0, dp(20), 0, 0)
            })
            return
        }
        feeds.forEachIndexed { i, f ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, dp(12), 0, dp(4))
            }
            row.addView(Switch(this).apply {
                text = f.name
                textSize = 16f
                isChecked = f.enabled
                setOnCheckedChangeListener { _, c ->
                    feeds[i] = feeds[i].copy(enabled = c)
                    FeedStore.save(this@SourcesActivity, feeds)
                    changed = true
                }
            })
            row.addView(TextView(this).apply {
                text = "${CAT_NAMES[f.cat + 1]} • ${f.url}"
                textSize = 11f
                alpha = 0.65f
            })
            val btns = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            btns.addView(Button(this).apply {
                text = "تعديل"
                setOnClickListener { showFeedDialog(i) }
            })
            btns.addView(Button(this).apply {
                text = "حذف"
                setOnClickListener {
                    AlertDialog.Builder(this@SourcesActivity).setMessage("حذف «${f.name}»؟")
                        .setPositiveButton("حذف") { _, _ -> feeds.removeAt(i); persist() }
                        .setNegativeButton("إلغاء", null).show()
                }
            })
            row.addView(btns)
            listBox.addView(row)
        }
    }

    private fun showFeedDialog(index: Int) {
        val old = if (index >= 0) feeds[index] else null
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        val name = EditText(this).apply {
            hint = "اسم المصدر"
            setText(old?.name ?: "")
        }
        val url = EditText(this).apply {
            hint = "https://example.com/rss.xml"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setText(old?.url ?: "")
        }
        val spin = Spinner(this).apply {
            adapter = ArrayAdapter(this@SourcesActivity, android.R.layout.simple_spinner_dropdown_item, CAT_NAMES)
            setSelection((old?.cat ?: CAT_AUTO) + 1)
        }
        box.addView(name)
        box.addView(url)
        box.addView(TextView(this).apply { text = "التصنيف:"; setPadding(0, dp(10), 0, 0) })
        box.addView(spin)

        AlertDialog.Builder(this)
            .setTitle(if (old == null) "إضافة مصدر" else "تعديل المصدر")
            .setView(box)
            .setPositiveButton("حفظ") { _, _ ->
                val n = name.text.toString().trim()
                val u = url.text.toString().trim()
                if (n.isEmpty() || !u.startsWith("https://")) {
                    Toast.makeText(this, "اكتب اسم ورابط يبدأ بـ https://", Toast.LENGTH_LONG).show()
                } else {
                    val f = Feed(n, u, spin.selectedItemPosition - 1, old?.enabled ?: true)
                    if (old == null) feeds.add(f) else feeds[index] = f
                    persist()
                }
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    override fun onPause() {
        super.onPause()
        if (changed) {
            changed = false
            val app = applicationContext
            Thread { try { Updater.run(app) } catch (_: Exception) {} }.start()
        }
    }
}
