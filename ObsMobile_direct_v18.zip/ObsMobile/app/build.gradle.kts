plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.example.obsmobile"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.obsmobile"
        minSdk = 24
        targetSdk = 34
        // رقم الإصدار يزيد تلقائيًا مع كل بناء في GitHub عشان التحديث ينزل فوق القديم
        versionCode = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()
        versionName = "0.${System.getenv("GITHUB_RUN_NUMBER") ?: "1"}"
        // libVLC ثقيل: نقصر المعماريات على اللي تنفع الأجهزة الحديثة (احذف armeabi-v7a لو تبي حجم أصغر)
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
    }
    // توقيع ثابت: نفس المفتاح في كل بناء، فالتحديث يركب فوق التطبيق بدون حذف
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }
    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        isCoreLibraryDesugaringEnabled = true
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    packaging { jniLibs { pickFirsts += "**/libc++_shared.so" } }
    buildFeatures { compose = true }
}

dependencies {
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.0.4")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.camera:camera-core:1.3.4")
    implementation("androidx.camera:camera-camera2:1.3.4")
    implementation("androidx.camera:camera-lifecycle:1.3.4")
    implementation("androidx.camera:camera-view:1.3.4")
    // البث والتسجيل (RTMP + MediaCodec)
    implementation("com.github.pedroSG94.RootEncoder:library:2.5.5")
    // إزالة خلفية الصور (ML Kit Subject Segmentation)
    implementation("com.google.android.gms:play-services-mlkit-subject-segmentation:16.0.0-beta1")
    // مشغّل فيديو يدعم تقريبًا كل الصيغ (مصدر "فيديو")
    implementation("org.videolan.android:libvlc-all:3.6.0")
    // مشغّل ExoPlayer للبث المباشر بدون التقاط شاشة (وضع "بث رابط")
    implementation("androidx.media3:media3-exoplayer:1.3.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.3.1")
    implementation("androidx.media3:media3-exoplayer-dash:1.3.1")
    implementation("androidx.media3:media3-exoplayer-rtsp:1.3.1")
    implementation("androidx.media3:media3-datasource-rtmp:1.3.1")
    // فك صوت MP2 / AC3 / EAC3 وغيرها بالبرنامج (FFmpeg) للأجهزة اللي ما تدعمها
    implementation("org.jellyfin.media3:media3-ffmpeg-decoder:1.3.1+2")
}
