package com.example.obsmobile

import android.app.ActivityManager
import android.content.Context
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.min

/** معلومات الجهاز اللي تهم البث */
data class DeviceInfo(
    val model: String,
    val ramGb: Float,
    val cores: Int,
    val hw1080p60: Boolean,
    val hw1080p30: Boolean,
    val hw720p60: Boolean,
    val highProfile: Boolean,
    val maxBitrateK: Int,
    val powerSave: Boolean,
    val soc: String,
    val weakSoc: Boolean // معالج ضعيف الرسوميات (فئة Snapdragon 4xx/6xx المنخفضة وما يشابهها)
)

data class TuneResult(
    val uploadMbps: Double?,
    val device: DeviceInfo,
    val settings: StreamSettings,
    val notes: List<String>
) {
    fun summary(): String {
        val up = uploadMbps?.let { String.format(Locale.US, "%.1f", it) } ?: "ما انقاس"
        val codec = if (settings.codec == "high") "High" else "عادي"
        val lock = if (settings.adaptive) "تخفيض تلقائي" else "تثبيت الجودة"
        return buildString {
            appendLine("الرفع: $up Mbps")
            appendLine("الجهاز: ${device.model}${if (device.soc.isNotBlank()) " (${device.soc})" else ""} • ${String.format(Locale.US, "%.1f", device.ramGb)}GB رام • ${device.cores} أنوية")
            appendLine("الترميز بالعتاد: 1080p60 ${if (device.hw1080p60) "✓" else "✗"} • 1080p30 ${if (device.hw1080p30) "✓" else "✗"} • 720p60 ${if (device.hw720p60) "✓" else "✗"}")
            appendLine("طبّقت: ${settings.shortSide}p • ${settings.fps} إطار • ${settings.bitrateK} kbps • $codec • $lock")
            notes.forEach { appendLine("• $it") }
        }.trim()
    }
}

/**
 * زر "الأفضل": يقيس سرعة الرفع، يفحص قدرات ترميز الجهاز،
 * ويختار الدقة والإطارات والبت ريت والترميز المناسبة.
 */
object AutoTune {
    private val ui = Handler(Looper.getMainLooper())
    private const val UP_URL = "https://speed.cloudflare.com/__up"

    fun run(ctx: Context, current: StreamSettings, onDone: (TuneResult) -> Unit) {
        val app = ctx.applicationContext
        Thread {
            val up = measureUpload()
            val dev = inspect(app)
            val res = recommend(app, current, up, dev)
            ui.post { onDone(res) }
        }.start()
    }

    /** قياس سرعة الرفع (Mbps) بإرسال بيانات عشوائية على 3 اتصالات متوازية لمدة ~7 ثواني */
    private fun measureUpload(seconds: Int = 7, threads: Int = 3): Double? {
        val total = AtomicLong(0)
        val payload = ByteArray(2_000_000).also { java.util.Random(7).nextBytes(it) }
        val t0 = System.nanoTime()
        val end = t0 + seconds * 1_000_000_000L
        val ws = List(threads) {
            Thread {
                while (System.nanoTime() < end) {
                    try {
                        val c = URL(UP_URL).openConnection() as HttpURLConnection
                        c.requestMethod = "POST"
                        c.doOutput = true
                        c.connectTimeout = 5000
                        c.readTimeout = 10000
                        c.setFixedLengthStreamingMode(payload.size)
                        c.outputStream.use { it.write(payload) }
                        val code = c.responseCode
                        if (code in 200..299) {
                            c.inputStream.use { it.readBytes() }
                            total.addAndGet(payload.size.toLong())
                        }
                        c.disconnect()
                        if (code !in 200..299) break
                    } catch (e: Exception) { break }
                }
            }.also { it.start() }
        }
        ws.forEach { it.join() }
        val secs = (System.nanoTime() - t0) / 1e9
        val bytes = total.get()
        if (bytes < 500_000 || secs <= 0.0) return null
        return bytes * 8 / secs / 1e6
    }

    fun inspect(ctx: Context): DeviceInfo {
        val all = try {
            MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.filter { ci ->
                ci.isEncoder && ci.supportedTypes.any { it.equals("video/avc", true) }
            }
        } catch (e: Exception) { emptyList() }
        val hw = all.filter { ci ->
            if (Build.VERSION.SDK_INT >= 29) ci.isHardwareAccelerated && !ci.isSoftwareOnly
            else !ci.name.startsWith("OMX.google") && !ci.name.startsWith("c2.android")
        }
        fun can(w: Int, h: Int, f: Int) = hw.any {
            try { it.getCapabilitiesForType("video/avc").videoCapabilities.areSizeAndRateSupported(w, h, f.toDouble()) }
            catch (e: Exception) { false }
        }
        val high = hw.any {
            try {
                it.getCapabilitiesForType("video/avc").profileLevels.any { p ->
                    p.profile == MediaCodecInfo.CodecProfileLevel.AVCProfileHigh
                }
            } catch (e: Exception) { false }
        }
        val maxBr = try {
            (hw.ifEmpty { all }).maxOfOrNull {
                it.getCapabilitiesForType("video/avc").videoCapabilities.bitrateRange.upper
            }?.div(1000) ?: 20000
        } catch (e: Exception) { 20000 }
        val mi = ActivityManager.MemoryInfo()
        (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        val ps = try { (ctx.getSystemService(Context.POWER_SERVICE) as PowerManager).isPowerSaveMode } catch (e: Exception) { false }
        val soc = if (Build.VERSION.SDK_INT >= 31) (Build.SOC_MODEL ?: "") else ""
        val weakSocs = setOf("SM6225", "SM6115", "SM6125", "SM4250", "SM4350", "SM4375", "SM6375", "SM6225-AD")
        val weakBoards = setOf("bengal", "trinket", "holi")
        val weak = weakSocs.any { soc.equals(it, true) } || weakBoards.any { Build.BOARD.equals(it, true) }
        return DeviceInfo(
            model = "${Build.MANUFACTURER} ${Build.MODEL}".trim(),
            ramGb = mi.totalMem / 1024f / 1024f / 1024f,
            cores = Runtime.getRuntime().availableProcessors(),
            hw1080p60 = can(1920, 1080, 60),
            hw1080p30 = can(1920, 1080, 30),
            hw720p60 = can(1280, 720, 60),
            highProfile = high,
            maxBitrateK = maxBr,
            powerSave = ps,
            soc = soc,
            weakSoc = weak
        )
    }

    private fun recommend(ctx: Context, cur: StreamSettings, up: Double?, d: DeviceInfo): TuneResult {
        val notes = mutableListOf<String>()
        val platform = TargetStore.load(ctx).platform
        val platCap = when (platform) {
            "twitch", "telegram" -> 6000
            "facebook" -> 4000
            "youtube" -> 9000
            else -> 8000
        }
        val capK = min(platCap, d.maxBitrateK)
        // نستخدم نص الرفع تقريبًا، الباقي للصوت وتذبذب الشبكة
        val safeK = up?.let { (it * 1000 * 0.5).toInt() } ?: 3500
        if (up == null) notes += "ما قدرت أقيس الرفع (تأكد من النت)، حطيت إعدادات آمنة"

        val (rw, rh) = realScreenSize(ctx)
        val nativeShort = minOf(rw, rh)
        val strong = !d.weakSoc && d.hw1080p60 && d.ramGb >= 5.5f && d.cores >= 8 &&
            Build.VERSION.SDK_INT >= 29 && !d.powerSave
        val ramOk1080 = d.ramGb >= 3.5f

        fun deviceOk(sh: Int, f: Int): Boolean {
            if (sh > nativeShort + 2) return false // ما نكبّر فوق دقة الشاشة
            if (d.powerSave && (f > 30 || sh > 720)) return false
            if (d.weakSoc && (f > 30 || sh > 720)) return false // معالج رسوميات ضعيف: اللعبة والتقاط الشاشة يتنافسون على نفس الكرت
            if (f >= 60) {
                val ok = (sh >= 1080 && strong) ||
                    (sh <= 720 && d.hw720p60 && !d.powerSave && d.cores >= 6)
                if (!ok) return false
            }
            if (sh >= 1080 && !(d.hw1080p30 && ramOk1080)) return false
            return true
        }

        val cands = listOf(1080 to 60, 1080 to 30, 720 to 60, 720 to 30, 540 to 30, 480 to 30)
        var pick: Triple<Int, Int, Int>? = null
        for ((sh, f) in cands) {
            if (!deviceOk(sh, f)) continue
            val (w, h) = streamSizeFor(ctx, cur.ratio, sh)
            val px = w.toLong() * h
            val needK = (px * f * 0.07 / 1000).toInt()
            val idealK = (px * f * 0.10 / 1000).toInt()
            val avail = min(safeK, capK)
            if (avail >= needK) {
                val br = (min(avail, idealK) / 250 * 250).coerceAtLeast(1000)
                pick = Triple(sh, f, br)
                break
            }
        }
        val (sh, f, br) = pick ?: Triple(480, 30, (min(safeK, capK) / 250 * 250).coerceAtLeast(1000))
        if (pick == null) notes += "النت أو الجهاز ما يكفي لجودة أعلى من 480p"
        if (d.weakSoc) notes += "معالج جوالك ضعيف في الرسوميات، فحدّدت الحد الأعلى 720p بـ30 إطار. خفّض رسومات اللعبة وحدّها بـ30 إطار لو تبي سلاسة أكثر"
        if (d.powerSave) notes += "توفير الطاقة شغال وخفّض الإعدادات. أطفئه لجودة أعلى"
        if (f < 60 && !strong && !d.powerSave) notes += "جوالك ما يتحمل 60 إطار بثبات مع اللعبة، فاخترت أفضل ما يتحمله"
        if (br >= capK && up != null && safeK > capK) notes += "البت ريت محدود بسقف المنصة ($capK kbps)"

        val codec = if (d.highProfile && strong) "high" else "auto"
        val adaptive = !(up != null && up >= 10.0)
        // الوضع الخفيف للمعالجات الضعيفة لو المشهد النشط شاشة فقط
        val scenes = SceneStore.load(ctx)
        val sc = scenes.getOrNull(SceneStore.active(ctx).coerceIn(0, scenes.lastIndex))
        val plain = sc != null && cur.filter == "none" &&
            sc.sources.any { it.type == "screen" && it.visible } &&
            sc.sources.none { (it.type == "text" || it.type == "image") && it.visible }
        val light = if (d.weakSoc && plain) true else cur.light
        if (light && !cur.light) notes += "فعّلت الوضع الخفيف (بدون معالجة OpenGL) لأن مشهدك شاشة فقط"
        return TuneResult(
            up, d,
            cur.copy(shortSide = sh, fps = f, bitrateK = br, codec = codec, adaptive = adaptive, light = light),
            notes
        )
    }
}
