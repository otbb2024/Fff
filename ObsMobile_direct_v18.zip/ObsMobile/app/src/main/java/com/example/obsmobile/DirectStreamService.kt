@file:Suppress("UnsafeOptInUsageError")

package com.example.obsmobile

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.net.Uri
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import androidx.media3.common.Tracks
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.extractor.ts.DefaultTsPayloadReaderFactory
import com.pedro.encoder.input.gl.render.filters.GreyScaleFilterRender
import com.pedro.encoder.input.gl.render.filters.NegativeFilterRender
import com.pedro.encoder.input.gl.render.filters.SepiaFilterRender
import com.pedro.encoder.input.gl.render.filters.`object`.ImageObjectFilterRender
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Surface
import android.widget.Toast
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.audio.AudioCapabilities
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import com.pedro.common.ConnectChecker
import com.pedro.library.rtmp.RtmpStream

/**
 * بث رابط فيديو مباشرة (بدون التقاط شاشة): ExoPlayer يشغّل الرابط،
 * الصورة تروح لمحرك الرسم والصوت يروح للمشفّر، ثم RTMP. مستقل تمامًا عن StreamService.
 */
class DirectStreamService : Service() {

    companion object {
        const val ACTION_START = "direct_start"
        const val ACTION_STOP = "direct_stop"
        const val ACTION_APPLY = "direct_apply"
        const val EXTRA_ROT = "rot"
        const val EXTRA_LINK = "link"
        const val EXTRA_URL = "url"
        const val EXTRA_REFERER = "referer"
        const val EXTRA_RECORD = "record"
        @Volatile var running = false
        @Volatile var recording = false
        @Volatile var health = 0
        @Volatile var liveBitrateK = 0
        @Volatile var previewSurface: Surface? = null
        @Volatile var previewW = 0
        @Volatile var previewH = 0
        @Volatile private var inst: DirectStreamService? = null
        /** تستدعيها الواجهة لما يجهز/يتغير سطح المعاينة */
        fun updatePreview(sf: Surface?, w: Int, h: Int) {
            previewSurface = sf; previewW = w; previewH = h
            inst?.ui?.post { inst?.attachPreview() }
        }
    }

    private var previewOn = false
    private var wakeLock: android.os.PowerManager.WakeLock? = null
    private var wifiLock: android.net.wifi.WifiManager.WifiLock? = null

    // ---- منع الجهاز من النوم أثناء البث (نفس منطق StreamService) ----
    @Suppress("DEPRECATION")
    private fun acquireWake() {
        try {
            if (wakeLock?.isHeld != true) {
                val pm = getSystemService(POWER_SERVICE) as android.os.PowerManager
                wakeLock = pm.newWakeLock(android.os.PowerManager.PARTIAL_WAKE_LOCK, "obsmobile:direct").apply {
                    setReferenceCounted(false)
                    acquire(8 * 60 * 60 * 1000L) // حد أمان 8 ساعات
                }
            }
        } catch (e: Exception) { AppLog.e("Direct", e) }
        try {
            if (wifiLock?.isHeld != true) {
                val wm = applicationContext.getSystemService(WIFI_SERVICE) as android.net.wifi.WifiManager
                val mode = if (Build.VERSION.SDK_INT >= 29) android.net.wifi.WifiManager.WIFI_MODE_FULL_LOW_LATENCY
                           else android.net.wifi.WifiManager.WIFI_MODE_FULL_HIGH_PERF
                wifiLock = wm.createWifiLock(mode, "obsmobile:direct-wifi").apply {
                    setReferenceCounted(false)
                    acquire()
                }
            }
        } catch (e: Exception) { AppLog.e("Direct", e) }
    }

    private fun releaseWake() {
        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (e: Exception) { AppLog.e("Direct", e) }
        wakeLock = null
        try { wifiLock?.let { if (it.isHeld) it.release() } } catch (e: Exception) { AppLog.e("Direct", e) }
        wifiLock = null
    }
    /** بدون أي تدوير: RootEncoder يدوّر الصورة 270° افتراضيًا (مخصص للكاميرا)، نلغيه عشان الصورة تطلع مستقيمة */
    private fun forceUpright(s: RtmpStream) {
        try {
            val gl = s.getGlInterface()
            for (m in gl.javaClass.methods) {
                if (m.name == "setRotation" && m.parameterTypes.size == 1 && m.parameterTypes[0] == Int::class.javaPrimitiveType) m.invoke(gl, 0)
                if (m.name == "setIsPortrait" && m.parameterTypes.size == 1 && m.parameterTypes[0] == Boolean::class.javaPrimitiveType) m.invoke(gl, false)
            }
        } catch (e: Throwable) { AppLog.e("Direct", e, "تعذر تثبيت الاتجاه") }
    }

    private fun attachPreview() {
        val s = stream ?: return
        val sf = previewSurface
        try {
            val gl: Any = s.getGlInterface()
            // بالـ reflection عشان البناء ما ينكسر لو اختلف اسم الدالة بين نسخ المكتبة
            fun call(name: String, vararg args: Any) {
                val m = gl.javaClass.methods.firstOrNull { it.name == name && it.parameterTypes.size == args.size } ?: return
                m.invoke(gl, *args)
            }
            if (previewOn) { call("deAttachPreview"); previewOn = false }
            if (sf != null && sf.isValid && previewW > 0) {
                call("attachPreview", sf)
                call("setPreviewResolution", previewW, previewH)
                previewOn = true
            }
        } catch (e: Throwable) { AppLog.e("Direct", e, "تعذر ربط المعاينة") }
    }

    private val ui = Handler(Looper.getMainLooper())
    private var stream: RtmpStream? = null
    private var player: ExoPlayer? = null
    private var audioSrc: ExoAudioSource? = null
    private var link = ""
    private var retries = 0
    private var stopping = false
    private var streamW = 1280
    private var streamH = 720

    private val replay = Runnable {
        val p = player ?: return@Runnable
        try { p.prepare(); p.play() } catch (e: Throwable) { AppLog.e("Direct", e, "فشل إعادة التشغيل") }
    }

    private val checker = object : ConnectChecker {
        override fun onConnectionStarted(url: String) {}
        override fun onConnectionSuccess() {
            health = 1
            toast("تم الاتصال، البث شغال")
        }
        override fun onConnectionFailed(reason: String) {
            AppLog.w("Direct", "فشل الاتصال: $reason")
            if (recording) {
                // التسجيل شغال: نوقف البث بس ونكمّل التسجيل بدون ما نخسره
                health = 0
                toast("فشل الاتصال بالبث، التسجيل مستمر")
                ui.post { try { stream?.let { if (it.isStreaming) it.stopStream() } } catch (_: Throwable) {} }
            } else {
                toast("فشل الاتصال: $reason")
                ui.post { stopAll() }
            }
        }
        override fun onNewBitrate(bitrate: Long) { liveBitrateK = (bitrate / 1000).toInt() }
        override fun onDisconnect() { AppLog.i("Direct", "انقطع البث") }
        override fun onAuthError() { toast("خطأ مصادقة (تأكد من مفتاح البث)") }
        override fun onAuthSuccess() {}
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        AppLog.installCrashHandler(applicationContext)
        inst = this
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                goForeground()
                try { start(intent) } catch (e: Throwable) {
                    AppLog.e("Direct", e, "تعذر بدء البث المباشر")
                    toast("تعذر بدء البث: ${e.message}")
                    stopAll()
                }
            }
            ACTION_STOP -> stopAll()
            ACTION_APPLY -> applyOverlays()
        }
        return START_NOT_STICKY
    }

    private fun start(intent: Intent) {
        link = intent.getStringExtra(EXTRA_LINK).orEmpty().trim()
        val url = intent.getStringExtra(EXTRA_URL).orEmpty().trim()
        val referer = intent.getStringExtra(EXTRA_REFERER).orEmpty().trim()
        val rot = 0 // أفقي طبيعي دائمًا
        val record = intent.getBooleanExtra(EXTRA_RECORD, false)
        if (link.isEmpty()) { toast("الرابط فاضي"); stopAll(); return }
        if (url.isEmpty() && !record) { toast("وجهة البث فاضية (فعّل التسجيل أو حط وجهة)"); stopAll(); return }

        stopping = false
        running = true
        health = 0
        retries = 0
        acquireWake()

        val st = SettingsStore.load(this)
        // نفس حجم مشاركة الشاشة (أفقي، بنفس نسبة الشاشة / 16:9)
        val (w, h) = streamSizeFor(this, st.ratio, st.shortSide, assumeLandscape = true)
        streamW = w; streamH = h

        // ---- المشغّل ----
        val sonic = SonicAudioProcessor().apply { setOutputSampleRateHz(48000) }
        val a = ExoAudioSource().also { audioSrc = it }
        val tap = PcmTap { bytes -> a.push(bytes) }
        val renderers = object : DefaultRenderersFactory(this) {
            override fun buildAudioSink(
                context: Context,
                enableFloatOutput: Boolean,
                enableAudioTrackPlaybackParams: Boolean
            ): AudioSink? = DefaultAudioSink.Builder(context)
                // PCM فقط: نمنع تمرير الصوت خام (AC3/EAC3 passthrough) لأنه ما يمر على معالج البث فيروح بدون صوت
                .setAudioCapabilities(AudioCapabilities.DEFAULT_AUDIO_CAPABILITIES)
                .setAudioProcessors(arrayOf(ToPcm16Processor(), sonic, tap))
                .build()
        }
        // لو فك الصوت أو الفيديو فشل بالمفكك الأول يجرب مفكك ثاني تلقائيًا بدل ما يسكت
        renderers.setEnableDecoderFallback(true)
        // لو الجهاز ما يفك الصوت (مثل MP2) نستخدم فك FFmpeg بالبرنامج
        renderers.setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent("Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
            .setAllowCrossProtocolRedirects(true)
            .apply { if (referer.isNotEmpty()) setDefaultRequestProperties(mapOf("Referer" to referer)) }
        // إعدادات تقلل تقطّع وتكسّر صورة بث TS المباشر
        val extractors = DefaultExtractorsFactory().setTsExtractorFlags(
            DefaultTsPayloadReaderFactory.FLAG_DETECT_ACCESS_UNITS
        )
        val load = DefaultLoadControl.Builder()
            .setBufferDurationsMs(15000, 40000, 2500, 5000)
            .build()
        val p = ExoPlayer.Builder(this, renderers)
            .setMediaSourceFactory(DefaultMediaSourceFactory(DefaultDataSource.Factory(this, http), extractors))
            .setLoadControl(load)
            .build()
        p.videoScalingMode = C.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING
        // يمنع النظام من إيقاف الشبكة/المعالج لما تنطفي الشاشة (سبب شائع لقطع الصوت)
        p.setWakeMode(C.WAKE_MODE_NETWORK)
        p.repeatMode = Player.REPEAT_MODE_ONE
        p.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                if (stopping) return
                retries++
                val delayMs = (2000L shl (retries - 1).coerceAtMost(3)).coerceAtMost(15_000L)
                AppLog.w("Direct", "خطأ بالرابط (${error.errorCodeName})، محاولة $retries بعد ${delayMs / 1000} ثواني")
                ui.removeCallbacks(replay)
                ui.postDelayed(replay, delayMs)
            }
            override fun onTracksChanged(tracks: Tracks) {
                var info = "الرابط ما فيه مسار صوت"
                for (g in tracks.groups) {
                    if (g.type == C.TRACK_TYPE_AUDIO && g.length > 0) {
                        val f = g.getTrackFormat(0)
                        info = "الصوت: ${f.sampleMimeType} " + if (g.isTrackSupported(0)) "(مدعوم)" else "(غير مدعوم في جهازك!)"
                    }
                }
                toast(info)
            }
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY) retries = 0
            }
        })
        player = p

        // ---- البث ----
        val v = ExoVideoSource { s: Surface? -> ui.post { try { player?.setVideoSurface(s) } catch (_: Throwable) {} } }
        val s = RtmpStream(applicationContext, checker, v, a)
        stream = s
        // أي إعدادات تحطها تشتغل: لو المشفّر ما يقبلها نقربها تلقائيًا لأعلى شي يدعمه الجهاز بدل ما نرفض
        if (!prepareVideoFlexible(s, w, h, st.bitrateK * 1000, st.fps, rot)) { toast("الجهاز ما قدر يشغّل الفيديو حتى بأقل الإعدادات"); stopAll(); return }
        var audioOk = false
        for (ab in intArrayOf(128, 96, 64)) {
            if (s.prepareAudio(48000, true, ab * 1000)) { audioOk = true; break }
        }
        if (!audioOk) { toast("الجهاز ما يدعم إعدادات الصوت"); stopAll(); return }

        p.setMediaItem(MediaItem.fromUri(link))
        p.prepare()
        p.playWhenReady = true
        forceUpright(s)
        if (record && !startRecording(s)) {
            if (url.isEmpty()) { stopAll(); return } // تسجيل فقط وفشل: ما فيه شي نكمله
        }
        if (url.isNotEmpty()) s.startStream(url) else health = 1 // تسجيل فقط: ما فيه اتصال ننتظره
        forceUpright(s)
        ui.postDelayed({ forceUpright(s) }, 500)
        ui.postDelayed({ forceUpright(s) }, 2000)
        // نطبق النصوص والصور بعد ما يشتغل الرسم، ونفحص وصول الصوت
        ui.postDelayed({ attachPreview(); applyOverlays() }, 1000)
        ui.postDelayed({
            val kb = (audioSrc?.pushedBytes ?: 0L) / 1024
            toast(if (kb > 0) "صوت واصل للبث: $kb KB • انقطاعات: ${audioSrc?.underruns ?: 0}" else "ما وصل أي صوت للمشفّر")
        }, 8000)
        AppLog.i("Direct", "بدأ البث المباشر: ${w}x$h ${st.fps}fps ${st.bitrateK}kbps، تسجيل=$recording، بث=${url.isNotEmpty()}")
    }

    private var recordPath: String? = null

    /** يبدأ تسجيل البث المباشر لملف MP4 (بالـ reflection عشان يتحمل اختلاف توقيع الدالة بين نسخ RootEncoder) */
    private fun startRecording(s: RtmpStream): Boolean {
        return try {
            val dir = getExternalFilesDir(android.os.Environment.DIRECTORY_MOVIES) ?: filesDir
            dir.mkdirs()
            if (dir.usableSpace < 200L * 1024 * 1024) {
                toast("المساحة المتبقية قليلة (أقل من 200MB)، فضّي مساحة وجرب")
                return false
            }
            val name = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val path = Recordings.tempFile(this, "direct", name).absolutePath
            val one = s.javaClass.methods.firstOrNull {
                it.name == "startRecord" && it.parameterTypes.size == 1 && it.parameterTypes[0] == String::class.java
            }
            val two = s.javaClass.methods.firstOrNull {
                it.name == "startRecord" && it.parameterTypes.size == 2 && it.parameterTypes[0] == String::class.java
            }
            when {
                one != null -> one.invoke(s, path)
                two != null -> two.invoke(s, path, null)
                else -> throw IllegalStateException("دالة startRecord غير موجودة في المكتبة")
            }
            recordPath = path
            recording = true
            toast("بدأ التسجيل، بينحفظ بالمعرض (Movies/ObsMobile) عند الإيقاف")
            true
        } catch (e: Throwable) {
            AppLog.e("Direct", e, "تعذر بدء التسجيل")
            toast("تعذر بدء التسجيل: ${e.cause?.message ?: e.message}")
            recording = false
            false
        }
    }

    private fun stopRecording() {
        if (!recording) return
        recording = false
        try { stream?.stopRecord() } catch (e: Throwable) { AppLog.e("Direct", e, "تعذر إيقاف التسجيل") }
        recordPath?.let { p -> Recordings.publish(this, File(p)) { m -> toast(m) } }
        recordPath = null
    }

    /** حدود مشفّر H264 بالجهاز: (أعلى بت ريت، أعلى عرض، أعلى ارتفاع، أعلى فريمات) أو null لو ما انقرأت */
    private fun encoderLimits(w: Int, h: Int): IntArray? = try {
        var best: IntArray? = null
        for (info in android.media.MediaCodecList(android.media.MediaCodecList.REGULAR_CODECS).codecInfos) {
            if (!info.isEncoder || !info.supportedTypes.any { it.equals("video/avc", true) }) continue
            val caps = info.getCapabilitiesForType("video/avc").videoCapabilities
            val fps = try { caps.getSupportedFrameRatesFor(w, h).upper.toInt() } catch (_: Throwable) { 30 }
            val cur = intArrayOf(caps.bitrateRange.upper, caps.supportedWidths.upper, caps.supportedHeights.upper, fps)
            if (best == null || cur[0] > best[0]) best = cur
        }
        best
    } catch (e: Throwable) { null }

    /** يجرّب الإعدادات المطلوبة أول، ولو انرفضت يقرّبها تدريجيًا (فريمات ← بت ريت ← دقة) لين يقبلها المشفّر */
    private fun prepareVideoFlexible(s: RtmpStream, w0: Int, h0: Int, bps0: Int, fps0: Int, rot: Int): Boolean {
        val lim = encoderLimits(w0, h0)
        val tries = ArrayList<IntArray>() // w, h, bps, fps
        tries += intArrayOf(w0, h0, bps0, fps0)
        var bps = bps0; var fps = fps0
        if (lim != null) { bps = minOf(bps, lim[0]); fps = minOf(fps, lim[3].coerceAtLeast(15)) }
        tries += intArrayOf(w0, h0, bps, fps)
        tries += intArrayOf(w0, h0, minOf(bps, 8_000_000), minOf(fps, 30))
        tries += intArrayOf(w0, h0, minOf(bps, 4_000_000), minOf(fps, 30))
        for ((nw, nh) in listOf(1920 to 1080, 1280 to 720, 854 to 480, 640 to 360)) {
            if (nw >= w0) continue
            val hh = (h0 * nw / w0) and 1.inv()
            tries += intArrayOf(nw, hh, minOf(bps, nw * hh * 4), minOf(fps, 30))
        }
        for ((i, t) in tries.withIndex()) {
            if (i > 0 && t.contentEquals(tries[i - 1])) continue
            val ok = try { s.prepareVideo(t[0], t[1], t[2], t[3], 2, rot) } catch (e: Throwable) { false }
            if (ok) {
                streamW = t[0]; streamH = t[1]
                if (i > 0) toast("الجهاز ما يدعم الإعدادات كاملة، اشتغل بأقرب إعداد: ${t[0]}x${t[1]} ${t[3]}fps ${t[2] / 1000}kbps")
                return true
            }
            AppLog.w("Direct", "رفض المشفّر ${t[0]}x${t[1]} ${t[3]}fps ${t[2] / 1000}kbps، أجرب أقل")
        }
        return false
    }

    /** يطبق الفلتر + النصوص والصور من المشهد النشط فوق الفيديو (مثل مشاركة الشاشة) */
    private fun applyOverlays() {
        val s = stream ?: return
        try {
            val st = SettingsStore.load(this)
            val scenes = SceneStore.load(this)
            val scene = scenes.getOrNull(SceneStore.active(this).coerceIn(0, scenes.lastIndex)) ?: return
            val gl = s.getGlInterface()
            gl.clearFilters()
            when (st.filter) {
                "gray" -> gl.addFilter(GreyScaleFilterRender())
                "sepia" -> gl.addFilter(SepiaFilterRender())
                "negative" -> gl.addFilter(NegativeFilterRender())
                "enhance" -> addEnhance(gl, 0.8f, 1.08f, 1.12f)
                "hd4k" -> addEnhance(gl, 1.6f, 1.15f, 1.2f)
                else -> FilterPresets.find(st.filter)?.let { addSteps(gl, it.steps) }
            }
            scene.sources.forEach { src ->
                if (!src.visible) return@forEach
                when (src.type) {
                    "text" -> if (src.text.isNotBlank()) {
                        val bmp = textBitmap(src.text, src.textSize * streamW / 720f)
                        val f = ImageObjectFilterRender()
                        gl.addFilter(f)
                        f.setImage(bmp)
                        f.setScale(bmp.width * 100f / streamW, bmp.height * 100f / streamH)
                        f.setPosition(src.x, src.y)
                    }
                    "image" -> loadBitmap(src.shownUri)?.let { bmp ->
                        val f = ImageObjectFilterRender()
                        gl.addFilter(f)
                        f.setImage(bmp)
                        val hPct = src.scale * bmp.height / bmp.width * streamW / streamH
                        f.setScale(src.scale, hPct)
                        f.setPosition(src.x, src.y)
                    }
                }
            }
        } catch (e: Throwable) {
            AppLog.e("Direct", e, "تعذر تطبيق النصوص والصور")
            toast("تعذر تطبيق المشهد: ${e.message}")
        }
    }

    /** نفس فلاتر وضع مشاركة الشاشة (بالـ reflection عشان ما ينكسر البناء لو تغير اسم فلتر) */
    private fun tunedFilter(cls: String, method: String, value: Float): Any? = try {
        val c = Class.forName("com.pedro.encoder.input.gl.render.filters.$cls")
        val o = c.getDeclaredConstructor().newInstance()
        c.methods.firstOrNull {
            it.name == method && it.parameterTypes.size == 1 && it.parameterTypes[0] == Float::class.javaPrimitiveType
        }?.invoke(o, value)
        o
    } catch (e: Throwable) { null }

    private fun addSteps(gl: Any, steps: List<FilterStep>) {
        try {
            val add = gl.javaClass.methods.firstOrNull { it.name == "addFilter" && it.parameterTypes.size == 1 } ?: return
            for (s in steps) {
                val f = tunedFilter(s.cls, s.method, s.value)
                if (f == null) AppLog.w("Filter", "فلتر غير متوفر في المكتبة: ${s.cls}") else add.invoke(gl, f)
            }
        } catch (e: Throwable) { AppLog.e("Filter", e) }
    }

    private fun addEnhance(gl: Any, sharp: Float, contrast: Float, sat: Float) {
        try {
            val add = gl.javaClass.methods.firstOrNull { it.name == "addFilter" && it.parameterTypes.size == 1 } ?: return
            tunedFilter("SharpnessFilterRender", "setSharpness", sharp)?.let { add.invoke(gl, it) }
            tunedFilter("ContrastFilterRender", "setContrast", contrast)?.let { add.invoke(gl, it) }
            tunedFilter("SaturationFilterRender", "setSaturation", sat)?.let { add.invoke(gl, it) }
        } catch (e: Throwable) { AppLog.e("Direct", e) }
    }

    private fun textBitmap(text: String, sizePx: Float): Bitmap {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = sizePx.coerceAtLeast(8f)
        }
        val lines = text.split("\n")
        var widest = lines.maxOf { paint.measureText(it) }
        if (widest > streamW * 0.95f) {
            paint.textSize = paint.textSize * streamW * 0.95f / widest
            widest = lines.maxOf { paint.measureText(it) }
        }
        val fm = paint.fontMetrics
        val lineH = fm.descent - fm.ascent
        val pad = paint.textSize * 0.1f
        val w = (widest + pad * 2).toInt().coerceAtLeast(2)
        val h = (lineH * lines.size + pad * 2).toInt().coerceAtLeast(2)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        lines.forEachIndexed { i, l -> c.drawText(l, pad, pad - fm.ascent + i * lineH, paint) }
        return bmp
    }

    private fun loadBitmap(uri: String): Bitmap? = try {
        contentResolver.openInputStream(Uri.parse(uri))?.use { BitmapFactory.decodeStream(it) }?.let {
            val maxW = streamW.coerceAtLeast(1280)
            if (it.width > maxW) Bitmap.createScaledBitmap(it, maxW, it.height * maxW / it.width, true) else it
        }
    } catch (e: Exception) { null }

    private fun stopAll() {
        stopping = true
        ui.removeCallbacks(replay)
        stopRecording()
        try { stream?.let { if (it.isStreaming) it.stopStream() } } catch (_: Throwable) {}
        try { stream?.release() } catch (_: Throwable) {}
        previewOn = false
        stream = null
        try { player?.release() } catch (_: Throwable) {}
        player = null
        audioSrc = null
        running = false; health = 0; liveBitrateK = 0
        releaseWake()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun goForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel("stream", "Streaming", NotificationManager.IMPORTANCE_LOW))
        }
        val stopPi = android.app.PendingIntent.getService(
            this, 21, Intent(this, DirectStreamService::class.java).setAction(ACTION_STOP),
            android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT
        )
        val open = android.app.PendingIntent.getActivity(
            this, 22, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, "stream")
            .setContentTitle(getString(R.string.app_name))
            .setContentText("بث / تسجيل رابط مباشر (بدون شاشة)")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(null, "■ إيقاف", stopPi).build())
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        else startForeground(2, n)
    }

    private fun toast(msg: String) {
        AppLog.i("toast", msg)
        ui.post { Toast.makeText(applicationContext, msg, Toast.LENGTH_LONG).show() }
    }

    override fun onDestroy() {
        inst = null
        if (running) {
            stopping = true
            stopRecording()
            try { stream?.stopStream(); stream?.release() } catch (_: Throwable) {}
            try { player?.release() } catch (_: Throwable) {}
            running = false
        }
        releaseWake()
        super.onDestroy()
    }
}
