package com.example.obsmobile

/** خطوة فلتر واحدة: اسم كلاس الفلتر في المكتبة + الدالة + القيمة */
data class FilterStep(val cls: String, val method: String, val value: Float)

/**
 * فلاتر تحسين خفيفة للأجهزة الضعيفة. كل فلتر = تمريرة (pass) على كرت الجوال،
 * فرتّبناها من الأخف (⚡) للأثقل (⚡⚡⚡) عشان تختار اللي يتحمله جوالك.
 */
data class FilterPreset(val id: String, val name: String, val steps: List<FilterStep>) {
    val label: String get() = "${"⚡".repeat(steps.size)} $name"
}

object FilterPresets {
    private fun sharp(v: Float) = FilterStep("SharpnessFilterRender", "setSharpness", v)
    private fun contrast(v: Float) = FilterStep("ContrastFilterRender", "setContrast", v)
    private fun sat(v: Float) = FilterStep("SaturationFilterRender", "setSaturation", v)
    private fun bright(v: Float) = FilterStep("BrightnessFilterRender", "setBrightness", v)

    val list: List<FilterPreset> = listOf(
        FilterPreset("p_soft_sharp", "وضوح خفيف", listOf(sharp(0.5f))),
        FilterPreset("p_clear", "وضوح عالي", listOf(sharp(0.9f))),
        FilterPreset("p_ultra_sharp", "حدة قوية", listOf(sharp(1.4f))),
        FilterPreset("p_vivid", "ألوان حيّة", listOf(sat(1.2f))),
        FilterPreset("p_contrast", "تباين أقوى", listOf(contrast(1.15f))),
        FilterPreset("p_bright", "تفتيح", listOf(bright(0.07f))),
        FilterPreset("p_night", "إضاءة ضعيفة", listOf(bright(0.1f), contrast(1.1f))),
        FilterPreset("p_rich", "ألوان غنية", listOf(sat(1.35f), contrast(1.08f))),
        FilterPreset("p_sport", "مباريات (عشب وحدة)", listOf(sat(1.25f), sharp(0.7f))),
        FilterPreset("p_balanced", "متوازن كامل", listOf(sharp(0.6f), contrast(1.06f), sat(1.1f)))
    )

    fun find(id: String): FilterPreset? = list.firstOrNull { it.id == id }
}
