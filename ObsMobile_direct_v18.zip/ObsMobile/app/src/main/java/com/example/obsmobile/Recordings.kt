package com.example.obsmobile

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import kotlin.concurrent.thread

/**
 * التسجيل يتكتب أول شي بمجلد التطبيق (أضمن أثناء التسجيل)،
 * وبعد الإيقاف ينتقل لمعرض الجوال: Movies/ObsMobile
 */
object Recordings {
    const val FOLDER = "ObsMobile"

    fun tempFile(ctx: Context, prefix: String, name: String): File {
        val dir = ctx.getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: ctx.filesDir
        dir.mkdirs()
        return File(dir, "${prefix}_$name.mp4")
    }

    /** ينسخ الملف للمعرض بخيط خلفي. onDone(msg) يرجع رسالة نجاح أو فشل. */
    fun publish(ctx: Context, src: File, onDone: (String) -> Unit) {
        val app = ctx.applicationContext
        if (!src.exists() || src.length() < 1024) {
            onDone("التسجيل فاضي، ما انحفظ شي")
            return
        }
        if (Build.VERSION.SDK_INT < 29) {
            onDone("تم حفظ التسجيل: ${src.absolutePath}")
            return
        }
        thread(name = "rec-publish") {
            var uri: android.net.Uri? = null
            try {
                val cv = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, src.name)
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(MediaStore.Video.Media.RELATIVE_PATH, "${Environment.DIRECTORY_MOVIES}/$FOLDER")
                    put(MediaStore.Video.Media.IS_PENDING, 1)
                }
                val res = app.contentResolver
                uri = res.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv)
                    ?: throw IllegalStateException("تعذر إنشاء الملف بالمعرض")
                res.openOutputStream(uri)!!.use { out -> src.inputStream().use { it.copyTo(out, 1 shl 20) } }
                res.update(uri, ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }, null, null)
                src.delete()
                AppLog.i("Rec", "انحفظ بالمعرض: Movies/$FOLDER/${src.name}")
                onDone("تم حفظ التسجيل بالمعرض: Movies/$FOLDER/${src.name}")
            } catch (e: Throwable) {
                try { uri?.let { app.contentResolver.delete(it, null, null) } } catch (_: Throwable) {}
                AppLog.e("Rec", e, "تعذر النقل للمعرض")
                onDone("تعذر النقل للمعرض، الملف بمجلد التطبيق: ${src.absolutePath}")
            }
        }
    }
}
