package com.example.obsmobile

import android.content.Context
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** سجل أخطاء وأحداث داخل التطبيق (ملف نصي صغير يتقلّص تلقائيًا) + تسجيل الانهيارات */
object AppLog {
    private const val MAX = 120_000
    private var file: File? = null
    private var lastMsg = ""
    private val fmt = SimpleDateFormat("MM-dd HH:mm:ss", Locale.US)

    fun init(ctx: Context) {
        if (file == null) file = File(ctx.applicationContext.filesDir, "app_log.txt")
    }

    @Synchronized
    private fun write(level: String, tag: String, msg: String) {
        val f = file ?: return
        val line = "$level/$tag: $msg"
        if (line == lastMsg) return // نتجاهل التكرار المتتالي
        lastMsg = line
        try {
            if (f.length() > MAX) f.writeText(f.readText().takeLast(MAX / 2).substringAfter('\n'))
            f.appendText("${fmt.format(Date())} $line\n")
        } catch (_: Exception) {}
        Log.println(if (level == "E" || level == "F") Log.ERROR else Log.INFO, "ObsMobile", line)
    }

    fun i(tag: String, msg: String) = write("I", tag, msg)
    fun w(tag: String, msg: String) = write("W", tag, msg)
    fun e(tag: String, t: Throwable, msg: String = "") =
        write("E", tag, "$msg ${t.javaClass.simpleName}: ${t.message}".trim())

    fun read(): String = try { file?.takeIf { it.exists() }?.readText().orEmpty() } catch (_: Exception) { "" }

    @Synchronized
    fun clear() { try { file?.writeText("") } catch (_: Exception) {}; lastMsg = "" }

    /** يسجّل أي انهيار قبل ما يتسكّر التطبيق */
    fun installCrashHandler(ctx: Context) {
        init(ctx)
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            write("F", "crash", Log.getStackTraceString(e).take(2500))
            prev?.uncaughtException(t, e)
        }
    }
}
