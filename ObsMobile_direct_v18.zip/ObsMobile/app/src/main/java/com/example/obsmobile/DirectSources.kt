@file:Suppress("UnsafeOptInUsageError")

package com.example.obsmobile

import android.graphics.SurfaceTexture
import android.view.Surface
import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import com.pedro.encoder.Frame
import com.pedro.encoder.input.audio.GetMicrophoneData
import com.pedro.encoder.input.sources.audio.AudioSource
import com.pedro.encoder.input.sources.video.VideoSource
import java.nio.ByteBuffer

/**
 * مصدر فيديو للبث: يعطي ExoPlayer سطح (Surface) مربوط بمحرك الرسم حق RootEncoder،
 * فالصورة تنرسم مباشرة للبث بدون التقاط شاشة.
 */
class ExoVideoSource(private val onSurface: (Surface?) -> Unit) : VideoSource() {
    private var w = 1280
    private var h = 720
    private var surface: Surface? = null
    private var active = false

    override fun create(width: Int, height: Int, fps: Int, rotation: Int): Boolean {
        w = width; h = height
        return true
    }

    override fun start(surfaceTexture: SurfaceTexture) {
        try { surfaceTexture.setDefaultBufferSize(w, h) } catch (_: Throwable) {}
        val s = Surface(surfaceTexture)
        surface = s
        active = true
        onSurface(s)
    }

    override fun stop() {
        active = false
        onSurface(null)
        try { surface?.release() } catch (_: Throwable) {}
        surface = null
    }

    override fun release() {}

    override fun isRunning(): Boolean = active
}

/**
 * مصدر صوت للبث: يستقبل صوت الفيديو (PCM ستيريو 48kHz) من المشغّل في مخزن دائري،
 * وخيط مستقل يرسله للمشفّر بإيقاع ثابت تمامًا (10.6ms لكل قطعة) مع طوابع زمنية منتظمة.
 *
 * الثبات: ساعة الصوت في الجهاز وساعة النظام ما تمشي بنفس السرعة بالضبط، والرابط ممكن يتأخر/يتسارع.
 * بدل ما نرمي ثانية صوت (قطع) أو نسكّت 200ms (تقطيع)، نعدّل سرعة القراءة بنسبة صغيرة جدًا (±2%)
 * عن طريق استيفاء خطي، فيبقى مستوى المخزن قريب من الهدف بدون أي قطع يُسمع.
 * الصمت فقط لو المشغّل وقف فعلًا (إعادة تحميل)، ويرجع الصوت بعد 100ms.
 */
class ExoAudioSource : AudioSource() {
    private companion object {
        const val RATE = 48000
        const val FRAME = 4                         // بايت لكل عينة ستيريو 16-bit
        const val CHUNK_FRAMES = 512
        const val CHUNK = CHUNK_FRAMES * FRAME      // 2048 بايت
        const val CAP = RATE * FRAME * 4            // سعة المخزن 4 ثواني
        const val PREFILL = RATE / 10               // 100ms (بالعينات) قبل البدء / بعد أي وقوف
        const val TARGET = RATE * 3 / 10            // نحافظ على ~300ms
        const val HARD_MAX = RATE * 3 / 2           // أكثر من 1.5 ثانية = حالة شاذة، نرجع للهدف
        const val MAX_ADJ = 0.02                    // أقصى تعديل سرعة ±2%
    }

    @Volatile private var callback: GetMicrophoneData? = null
    @Volatile private var active = false
    private var thread: Thread? = null
    private val lock = Object()
    private val ring = ByteArray(CAP)
    private var rPos = 0       // بايت
    private var size = 0       // بايت

    @Volatile var pushedBytes = 0L
    @Volatile var underruns = 0

    override fun create(sampleRate: Int, isStereo: Boolean, echoCanceler: Boolean, noiseSuppressor: Boolean): Boolean = true

    override fun start(getMicrophoneData: GetMicrophoneData) {
        callback = getMicrophoneData
        synchronized(lock) { rPos = 0; size = 0 }
        active = true
        thread = Thread({ pump() }, "direct-audio-pump").apply {
            priority = Thread.MAX_PRIORITY
            isDaemon = true
            start()
        }
    }

    override fun stop() {
        active = false
        thread?.interrupt()
        thread = null
        callback = null
    }

    override fun release() {}

    override fun isRunning(): Boolean = active

    /** يستقبل PCM 16-bit ستيريو 48k من المشغّل ويخزنه (لا يرسل للمشفّر مباشرة) */
    fun push(bytes: ByteArray) {
        if (!active || bytes.isEmpty()) return
        synchronized(lock) {
            var len = bytes.size and 3.inv()
            var src = 0
            if (len > CAP) { src = len - CAP; len = CAP }
            val over = size + len - CAP
            if (over > 0) { rPos = (rPos + over) % CAP; size -= over }
            val w = (rPos + size) % CAP
            val first = minOf(len, CAP - w)
            System.arraycopy(bytes, src, ring, w, first)
            if (len > first) System.arraycopy(bytes, src + first, ring, 0, len - first)
            size += len
        }
        pushedBytes += bytes.size
    }

    /** يقرأ عينة 16-bit (قناة c) من الإطار رقم k بعد رأس المخزن */
    private fun sample(k: Int, c: Int): Int {
        val p = (rPos + k * FRAME + c * 2) % CAP
        return (ring[p].toInt() and 0xFF) or (ring[(p + 1) % CAP].toInt() shl 8)
    }

    private fun pump() {
        try { android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_AUDIO) } catch (_: Throwable) {}
        val chunkUs = CHUNK_FRAMES * 1_000_000L / RATE
        val t0 = System.nanoTime() / 1000
        var emitted = 0L
        var buffering = true
        var frac = 0.0
        try {
            while (active) {
                val due = (System.nanoTime() / 1000 - t0) / chunkUs
                if (due - emitted > 60) emitted = due // تأخر الخيط كثير: نلحق الوقت بدون إغراق
                while (emitted < due && active) {
                    val out = ByteArray(CHUNK)
                    synchronized(lock) {
                        var level = size / FRAME
                        if (level > HARD_MAX) { // حالة شاذة فقط (بداية التشغيل): نرجع للهدف
                            val drop = (level - TARGET) * FRAME
                            rPos = (rPos + drop) % CAP; size -= drop; level = size / FRAME
                        }
                        if (buffering && level >= PREFILL) { buffering = false; frac = 0.0 }
                        if (!buffering) {
                            // نسرّع/نبطّئ القراءة شوي حسب بُعد المخزن عن الهدف
                            val adj = ((level - TARGET).toDouble() / RATE * 0.05).coerceIn(-MAX_ADJ, MAX_ADJ)
                            val ratio = 1.0 + adj
                            val total = frac + CHUNK_FRAMES * ratio
                            val consume = total.toInt()
                            if (level >= consume + 2) {
                                for (i in 0 until CHUNK_FRAMES) {
                                    val pos = frac + i * ratio
                                    val k = pos.toInt()
                                    val f = pos - k
                                    for (c in 0..1) {
                                        val a = sample(k, c).toShort().toInt()
                                        val b = sample(k + 1, c).toShort().toInt()
                                        val v = (a + (b - a) * f).toInt().coerceIn(-32768, 32767)
                                        val o = i * FRAME + c * 2
                                        out[o] = v.toByte(); out[o + 1] = (v shr 8).toByte()
                                    }
                                }
                                rPos = (rPos + consume * FRAME) % CAP; size -= consume * FRAME
                                frac = total - consume
                            } else { buffering = true; underruns++ } // صمت لهالقطعة (المشغّل وقف)
                        }
                    }
                    val cb = callback ?: return
                    cb.inputPCMData(Frame(out, 0, CHUNK, t0 + emitted * chunkUs))
                    emitted++
                }
                Thread.sleep(2)
            }
        } catch (_: InterruptedException) {
        } catch (_: Throwable) {}
    }
}

/**
 * معالج صوت داخل ExoPlayer: يمرّر الصوت كما هو للسماعة، وينسخ نسخة ستيريو 16-bit للبث.
 * يدعم أي عدد قنوات (مونو، 5.1، 7.1) مع دمج صحيح عشان الصوت (الكلام) ما يضيع.
 */
class PcmTap(private val onPcm: (ByteArray) -> Unit) : BaseAudioProcessor() {
    private var channels = 2

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT) return AudioProcessor.AudioFormat.NOT_SET
        channels = inputAudioFormat.channelCount
        return inputAudioFormat
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val size = inputBuffer.remaining()
        if (size == 0) return
        val src = ByteArray(size)
        inputBuffer.duplicate().get(src)
        try { onPcm(toStereo(src, channels)) } catch (_: Throwable) {}
        val out = replaceOutputBuffer(size)
        out.put(inputBuffer)
        out.flip()
    }

    private fun s16(b: ByteArray, i: Int): Int = (b[i].toInt() and 0xFF) or (b[i + 1].toInt() shl 8)

    private fun toStereo(src: ByteArray, ch: Int): ByteArray {
        if (ch == 2) return src
        val frames = src.size / (2 * ch)
        val out = ByteArray(frames * 4)
        for (i in 0 until frames) {
            val s = i * 2 * ch
            val o = i * 4
            var l: Int
            var r: Int
            if (ch == 1) { l = s16(src, s); r = l }
            else {
                // ترتيب أندرويد: FL FR FC LFE BL BR (SL SR) — ندمج المنتصف والخلفية بالجهتين
                l = s16(src, s); r = s16(src, s + 2)
                val fl = l; val fr = r
                var cL = 0.0; var cR = 0.0
                when (ch) {
                    3 -> cL = s16(src, s + 4) * 0.707
                    4 -> { cL = s16(src, s + 4) * 0.707; cR = s16(src, s + 6) * 0.707 }
                    else -> {
                        val c = s16(src, s + 4) * 0.707
                        cL = c; cR = c
                        if (ch >= 6) { cL += s16(src, s + 8) * 0.707; cR += s16(src, s + 10) * 0.707 }
                        else if (ch == 5) { cL += s16(src, s + 6) * 0.707; cR += s16(src, s + 8) * 0.707 }
                        if (ch >= 8) { cL += s16(src, s + 12) * 0.707; cR += s16(src, s + 14) * 0.707 }
                    }
                }
                if (ch == 3) { cR = cL }
                l = ((fl + cL) / 1.9).toInt(); r = ((fr + cR) / 1.9).toInt()
            }
            l = l.coerceIn(-32768, 32767); r = r.coerceIn(-32768, 32767)
            out[o] = l.toByte(); out[o + 1] = (l shr 8).toByte()
            out[o + 2] = r.toByte(); out[o + 3] = (r shr 8).toByte()
        }
        return out
    }
}

/**
 * يحوّل أي صوت غير 16-bit (float من فك FFmpeg، أو 24/32/8-bit) إلى 16-bit
 * عشان باقي المعالجات والبث يشتغلون عليه. إذا الصوت أصلاً 16-bit يكون خامل ولا يغيّر شي.
 */
class ToPcm16Processor : BaseAudioProcessor() {
    private var enc = C.ENCODING_PCM_16BIT

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        enc = inputAudioFormat.encoding
        return when (enc) {
            C.ENCODING_PCM_FLOAT, C.ENCODING_PCM_24BIT, C.ENCODING_PCM_32BIT, C.ENCODING_PCM_8BIT ->
                AudioProcessor.AudioFormat(inputAudioFormat.sampleRate, inputAudioFormat.channelCount, C.ENCODING_PCM_16BIT)
            else -> AudioProcessor.AudioFormat.NOT_SET
        }
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val step = when (enc) { C.ENCODING_PCM_FLOAT, C.ENCODING_PCM_32BIT -> 4; C.ENCODING_PCM_24BIT -> 3; else -> 1 }
        val n = inputBuffer.remaining() / step
        if (n == 0) { inputBuffer.position(inputBuffer.limit()); return }
        val out = replaceOutputBuffer(n * 2)
        val base = inputBuffer.position()
        for (i in 0 until n) {
            val p = base + i * step
            val v: Int = when (enc) {
                C.ENCODING_PCM_FLOAT -> (java.lang.Float.intBitsToFloat(rd32(inputBuffer, p)) * 32767f).coerceIn(-32768f, 32767f).toInt()
                C.ENCODING_PCM_32BIT -> rd32(inputBuffer, p) shr 16
                C.ENCODING_PCM_24BIT -> ((inputBuffer.get(p + 1).toInt() and 0xFF) or (inputBuffer.get(p + 2).toInt() shl 8)).toShort().toInt()
                else -> ((inputBuffer.get(p).toInt() and 0xFF) - 128) shl 8
            }
            out.putShort(v.toShort())
        }
        inputBuffer.position(inputBuffer.limit())
        out.flip()
    }

    private fun rd32(b: ByteBuffer, p: Int): Int =
        (b.get(p).toInt() and 0xFF) or ((b.get(p + 1).toInt() and 0xFF) shl 8) or
        ((b.get(p + 2).toInt() and 0xFF) shl 16) or (b.get(p + 3).toInt() shl 24)
}
