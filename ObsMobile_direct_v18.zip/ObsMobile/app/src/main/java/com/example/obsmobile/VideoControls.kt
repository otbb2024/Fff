package com.example.obsmobile

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

/**
 * أزرار تحكم عائمة فوق الفيديو: زر صغير شفاف (☰) يظهر دائمًا، ولمسه يفتح شريط الأزرار 5 ثواني ثم يختفي.
 * ملاحظة: التقاط الشاشة يشوف هالنافذة، فخليناها صغيرة وباهتة وتقفل تلقائيًا.
 * أزرار الإشعار تسوي نفس الشي وما تظهر بالبث أبدًا.
 */
class VideoControls(
    private val ctx: Context,
    private val onExit: () -> Unit,        // إيقاف الفيديو والرجوع للوضع الطبيعي
    private val onFullscreen: () -> Unit,  // ملء الشاشة <-> تصغير
    private val onMute: () -> Unit,        // كتم صوت الفيديو
    private val onStopStream: () -> Unit,  // إيقاف البث كامل
    private val onOpenApp: () -> Unit      // فتح التطبيق
) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val ui = Handler(Looper.getMainLooper())
    private var root: LinearLayout? = null
    private var panel: LinearLayout? = null
    private var handle: TextView? = null
    private var fullBtn: TextView? = null
    private var muteBtn: TextView? = null
    private val collapse = Runnable { setOpen(false) }

    val isShowing get() = root != null

    private fun dp(v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    private fun btn(label: String, bg: Int, click: () -> Unit) = TextView(ctx).apply {
        text = label; setTextColor(Color.WHITE); textSize = 15f; gravity = Gravity.CENTER
        setPadding(dp(12), dp(8), dp(12), dp(8))
        background = GradientDrawable().apply { cornerRadius = dp(18).toFloat(); setColor(bg) }
        setOnClickListener { click(); if (panel?.visibility == View.VISIBLE) restartTimer() }
    }

    @SuppressLint("ClickableViewAccessibility")
    fun show() {
        if (root != null) return
        val r = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }

        val h = TextView(ctx).apply {
            text = "☰"; setTextColor(Color.WHITE); textSize = 18f; gravity = Gravity.CENTER
            width = dp(44); height = dp(44); alpha = 0.35f
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#99000000")) }
        }
        val p = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL; visibility = View.GONE
            setPadding(dp(6), dp(4), dp(6), dp(4))
            background = GradientDrawable().apply { cornerRadius = dp(24).toFloat(); setColor(Color.parseColor("#CC111111")) }
        }
        val gap = LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(4); marginEnd = dp(4) }
        val exit = btn("✕ خروج", Color.parseColor("#C62828")) { onExit() }
        val full = btn("⛶ ملء", Color.parseColor("#1565C0")) { onFullscreen() }
        val mute = btn("🔊", Color.parseColor("#455A64")) { onMute() }
        val stop = btn("■ إيقاف البث", Color.parseColor("#6A1B9A")) { onStopStream() }
        val home = btn("🏠", Color.parseColor("#2E7D32")) { onOpenApp() }
        listOf(exit, full, mute, stop, home).forEach { p.addView(it, gap) }
        fullBtn = full; muteBtn = mute

        r.addView(p); r.addView(h)
        root = r; panel = p; handle = h

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = dp(8); y = dp(40) }

        // لمسة = فتح/قفل الشريط، سحب = تحريك الزر
        var dx = 0f; var dy = 0f; var sx = 0; var sy = 0; var moved = false
        h.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = lp.x; sy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    if (Math.abs(e.rawX - dx) > dp(8) || Math.abs(e.rawY - dy) > dp(8)) moved = true
                    if (moved) {
                        lp.x = sx - (e.rawX - dx).toInt()   // END gravity: الإزاحة معكوسة
                        lp.y = sy + (e.rawY - dy).toInt()
                        try { wm.updateViewLayout(r, lp) } catch (_: Exception) {}
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) setOpen(p.visibility != View.VISIBLE)
            }
            true
        }
        try { wm.addView(r, lp) } catch (e: Throwable) { AppLog.e("Controls", e, "تعذر عرض أزرار التحكم"); root = null }
    }

    private fun setOpen(open: Boolean) {
        panel?.visibility = if (open) View.VISIBLE else View.GONE
        handle?.alpha = if (open) 0.9f else 0.35f
        ui.removeCallbacks(collapse)
        if (open) restartTimer()
    }

    private fun restartTimer() { ui.removeCallbacks(collapse); ui.postDelayed(collapse, 5000) }

    fun setFull(full: Boolean) { fullBtn?.text = if (full) "⛶ تصغير" else "⛶ ملء" }
    fun setMuted(m: Boolean) { muteBtn?.text = if (m) "🔇" else "🔊" }

    fun hide() {
        ui.removeCallbacks(collapse)
        root?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        root = null; panel = null; handle = null
    }
}
