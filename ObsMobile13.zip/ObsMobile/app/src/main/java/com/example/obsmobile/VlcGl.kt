package com.example.obsmobile

import android.content.Context
import android.graphics.SurfaceTexture
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.view.Surface
import android.widget.Toast
import com.pedro.encoder.input.gl.render.filters.`object`.SurfaceFilterRender
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import java.io.File

/**
 * يشغّل فيديو VLC ويرسمه داخل البث مباشرة (مو فوق الشاشة).
 *
 * التعديلات:
 * 1) كل تعامل مع libVLC صار على الخيط الرئيسي (قبل كان على خيط OpenGL
 *    وهذا يخلي الصوت يشتغل والفيديو ما يطلع).
 * 2) الأخطاء تظهر كـ Toast بدل ما تنبلع بصمت.
 * 3) إذا اشتغل الصوت وما انفتح الفيديو بعد 7 ثواني، يعيد التشغيل
 *    بفك ترميز برمجي تلقائيًا.
 */
class VlcGl(private val ctx: Context) {

    private companion object {
        const val W = 1280
        const val H = 720
    }

    private val main = Handler(Looper.getMainLooper())
    private var vlc: LibVLC? = null
    private var player: MediaPlayer? = null
    private var pfd: ParcelFileDescriptor? = null
    private var surface: Surface? = null
    private var playingUri: String? = null
    private var voutCount = 0
    private var released = false

    fun createFilter(uri: String): SurfaceFilterRender =
        SurfaceFilterRender { st -> main.post { attach(uri, st) } }

    private fun toast(msg: String) {
        Toast.makeText(ctx.applicationContext, msg, Toast.LENGTH_LONG).show()
    }

    private fun createPlayer(v: LibVLC): MediaPlayer {
        val p = MediaPlayer(v)
        p.setEventListener(MediaPlayer.EventListener { e ->
            if (e.type == MediaPlayer.Event.EncounteredError) {
                toast("VLC: تعذر تشغيل الرابط/الملف")
            } else if (e.type == MediaPlayer.Event.Vout) {
                voutCount = e.voutCount
            }
        })
        return p
    }

    // يُستدعى دائمًا على الخيط الرئيسي
    private fun attach(uri: String, st: SurfaceTexture) {
        if (released) return
        try {
            st.setDefaultBufferSize(W, H)
            val newSurface = Surface(st)
            val v = vlc ?: LibVLC(ctx).also { vlc = it }
            val p = player ?: createPlayer(v).also { player = it }
            val vout = p.getVLCVout()
            if (vout.areViewsAttached()) vout.detachViews()
            try { surface?.release() } catch (_: Exception) {}
            surface = newSurface
            vout.setVideoSurface(newSurface, null)
            vout.setWindowSize(W, H)
            vout.attachViews()

            if (playingUri != uri) {
                play(uri, true)
            } else if (!p.isPlaying) {
                p.play()
            }
        } catch (e: Exception) {
            toast("VLC: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    private fun play(uri: String, hw: Boolean) {
        val v = vlc ?: return
        val p = player ?: return
        val media = when {
            uri.startsWith("content://") -> {
                try { pfd?.close() } catch (_: Exception) {}
                val d = ctx.contentResolver.openFileDescriptor(Uri.parse(uri), "r")
                pfd = d
                Media(v, d!!.fileDescriptor)
            }
            uri.startsWith("/") -> Media(v, Uri.fromFile(File(uri)))
            else -> Media(v, Uri.parse(uri))
        }
        media.setHWDecoderEnabled(hw, false)
        media.addOption(":input-repeat=65535")
        if (!uri.startsWith("content://") && !uri.startsWith("/")) {
            media.addOption(":network-caching=1500")
        }
        p.media = media
        media.release()
        playingUri = uri
        voutCount = 0
        p.play()

        // مراقب: صوت شغال بدون فيديو؟
        main.postDelayed({
            val pl = player
            if (!released && pl != null && playingUri == uri && pl.isPlaying && voutCount == 0) {
                if (pl.videoTracksCount <= 0) {
                    toast("الرابط ما فيه مسار فيديو (صوت فقط)")
                } else if (hw) {
                    toast("جاري تجربة فك الترميز البرمجي للفيديو")
                    play(uri, false)
                } else {
                    toast("الفيديو ما اشتغل على هذا الجهاز")
                }
            }
        }, 7000)
    }

    fun release() {
        released = true
        main.removeCallbacksAndMessages(null)
        try { player?.stop() } catch (_: Exception) {}
        try { player?.getVLCVout()?.detachViews() } catch (_: Exception) {}
        try { player?.release() } catch (_: Exception) {}
        try { vlc?.release() } catch (_: Exception) {}
        try { pfd?.close() } catch (_: Exception) {}
        try { surface?.release() } catch (_: Exception) {}
        player = null; vlc = null; pfd = null; surface = null; playingUri = null
    }
}
