package com.example.obsmobile

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** مصدر داخل المشهد: نص أو صورة */
data class Source(
    val type: String,            // "text" أو "image"
    val text: String = "",
    val uri: String = "",
    val x: Float = 5f,           // موقع أفقي % من الشاشة
    val y: Float = 5f,           // موقع عمودي %
    val scale: Float = 25f,      // عرض الصورة %
    val textSize: Float = 40f    // حجم النص
)

data class Scene(val name: String, val sources: List<Source>)

object SceneStore {
    private const val PREFS = "scenes"

    private fun prefs(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun load(c: Context): List<Scene> {
        val raw = prefs(c).getString("data", null)
        if (raw.isNullOrEmpty()) return listOf(Scene("المشهد 1", emptyList()))
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val srcs = o.getJSONArray("sources")
                Scene(o.getString("name"), (0 until srcs.length()).map { j ->
                    val s = srcs.getJSONObject(j)
                    Source(
                        type = s.getString("type"),
                        text = s.optString("text"),
                        uri = s.optString("uri"),
                        x = s.optDouble("x", 5.0).toFloat(),
                        y = s.optDouble("y", 5.0).toFloat(),
                        scale = s.optDouble("scale", 25.0).toFloat(),
                        textSize = s.optDouble("textSize", 40.0).toFloat()
                    )
                })
            }.ifEmpty { listOf(Scene("المشهد 1", emptyList())) }
        } catch (e: Exception) {
            listOf(Scene("المشهد 1", emptyList()))
        }
    }

    fun save(c: Context, scenes: List<Scene>) {
        val arr = JSONArray()
        scenes.forEach { sc ->
            val srcs = JSONArray()
            sc.sources.forEach { s ->
                srcs.put(JSONObject().apply {
                    put("type", s.type); put("text", s.text); put("uri", s.uri)
                    put("x", s.x.toDouble()); put("y", s.y.toDouble())
                    put("scale", s.scale.toDouble()); put("textSize", s.textSize.toDouble())
                })
            }
            arr.put(JSONObject().apply { put("name", sc.name); put("sources", srcs) })
        }
        prefs(c).edit().putString("data", arr.toString()).apply()
    }

    fun active(c: Context): Int = prefs(c).getInt("active", 0)
    fun setActive(c: Context, i: Int) = prefs(c).edit().putInt("active", i).apply()
}

/** إعدادات البث (مثل Settings في OBS) */
data class StreamSettings(
    val shortSide: Int = 720,        // الدقة: 480 / 720 / 1080
    val fps: Int = 30,               // 30 / 60
    val bitrateK: Int = 3000,        // kbps
    val audio: String = "mic",       // mic / internal / none
    val filter: String = "none",     // none / gray / sepia / negative
    val transition: String = "fade", // none / fade / wipe
    val transMs: Int = 600           // مدة الانتقال بالمللي ثانية
)

object SettingsStore {
    private fun p(c: Context) = c.getSharedPreferences("settings", Context.MODE_PRIVATE)
    fun load(c: Context) = p(c).let {
        StreamSettings(
            it.getInt("short", 720), it.getInt("fps", 30), it.getInt("bitrate", 3000),
            it.getString("audio", "mic") ?: "mic", it.getString("filter", "none") ?: "none",
            it.getString("transition", "fade") ?: "fade", it.getInt("transMs", 600)
        )
    }
    fun save(c: Context, s: StreamSettings) = p(c).edit()
        .putInt("short", s.shortSide).putInt("fps", s.fps).putInt("bitrate", s.bitrateK)
        .putString("audio", s.audio).putString("filter", s.filter)
        .putString("transition", s.transition).putInt("transMs", s.transMs).apply()
}

/** وجهة البث: منصة + رابط الخادم + مفتاح البث */
data class StreamTarget(
    val platform: String = "youtube",
    val server: String = "rtmp://a.rtmp.youtube.com/live2",
    val key: String = ""
)

object Platforms {
    // (المعرف، الاسم، رابط الخادم الافتراضي)
    val list = listOf(
        Triple("youtube", "YouTube", "rtmp://a.rtmp.youtube.com/live2"),
        Triple("telegram", "Telegram", "rtmps://dc4-1.rtmp.t.me/s"),
        Triple("twitch", "Twitch", "rtmp://live.twitch.tv/app"),
        Triple("facebook", "Facebook", "rtmps://live-api-s.facebook.com:443/rtmp"),
        Triple("custom", "مخصص (Kick, TikTok, غيرها)", "")
    )
    fun hint(id: String) = when (id) {
        "telegram" -> "في تليجرام: ابدأ بث مباشر للقناة أو المجموعة، واختر البث ببرنامج خارجي (Start streaming with...)، وانسخ Server URL وStream Key. الرابط عندك ممكن يختلف عن الافتراضي، فالصق اللي يعطيك إياه تليجرام."
        "youtube" -> "من YouTube Studio ← إنشاء ← بث مباشر ← انسخ Stream URL ومفتاح البث."
        "twitch" -> "من Twitch Dashboard ← Settings ← Stream ← انسخ Primary Stream key."
        "facebook" -> "من Live Producer في فيسبوك ← اختر Streaming software ← انسخ Server URL وStream key."
        else -> "الصق رابط الخادم (rtmp:// أو rtmps://) ومفتاح البث من المنصة."
    }
}

object TargetStore {
    private fun p(c: Context) = c.getSharedPreferences("target", Context.MODE_PRIVATE)

    fun load(c: Context): StreamTarget =
        loadFor(c, p(c).getString("platform", "youtube") ?: "youtube")

    /** كل منصة لها رابط خادم ومفتاح محفوظين لحالهم */
    fun loadFor(c: Context, id: String): StreamTarget {
        val def = Platforms.list.firstOrNull { it.first == id }?.third ?: ""
        return StreamTarget(
            id,
            p(c).getString("server_$id", def) ?: def,
            p(c).getString("key_$id", "") ?: ""
        )
    }

    fun save(c: Context, t: StreamTarget) = p(c).edit()
        .putString("platform", t.platform)
        .putString("server_${t.platform}", t.server)
        .putString("key_${t.platform}", t.key)
        .apply()
}
