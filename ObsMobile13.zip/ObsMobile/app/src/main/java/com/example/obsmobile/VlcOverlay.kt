package com.example.obsmobile

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout
import java.io.File

/**
 * نافذة فيديو VLC عائمة فوق الشاشة. التقاط الشاشة يلتقط كل شيء ظاهر،
 * فالفيديو يطلع تلقائيًا في البث والتسجيل. يمكن سحبه بالإصبع.
 */
class VlcOverlay(private val ctx: Context) {

    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var layout: VLCVideoLayout? = null
    private var vlc: LibVLC? = null
    private var player: MediaPlayer? = null
    private var pfd: ParcelFileDescriptor? = null

    val isShowing get() = layout != null

    @SuppressLint("ClickableViewAccessibility")
    fun show(uri: String, widthPx: Int, x: Int, y: Int) {
        hide()
        try {
            val l = VLCVideoLayout(ctx)
            l.setBackgroundColor(Color.BLACK)
            val lp = WindowManager.LayoutParams(
                widthPx, widthPx * 9 / 16,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.START; this.x = x; this.y = y }

            var downX = 0f; var downY = 0f; var startX = 0; var startY = 0
            l.setOnTouchListener { _, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { downX = e.rawX; downY = e.rawY; startX = lp.x; startY = lp.y }
                    MotionEvent.ACTION_MOVE -> {
                        lp.x = startX + (e.rawX - downX).toInt()
                        lp.y = startY + (e.rawY - downY).toInt()
                        wm.updateViewLayout(l, lp)
                    }
                }
                true
            }
            wm.addView(l, lp)
            layout = l

            val v = LibVLC(ctx)
            vlc = v
            val p = MediaPlayer(v)
            player = p
            p.attachViews(l, null, false, false)

            val media = when {
                uri.startsWith("content://") -> {
                    val d = ctx.contentResolver.openFileDescriptor(Uri.parse(uri), "r")
                    pfd = d
                    Media(v, d!!.fileDescriptor)
                }
                uri.startsWith("/") -> Media(v, Uri.fromFile(File(uri)))
                else -> Media(v, Uri.parse(uri))
            }
            media.addOption(":input-repeat=65535")
            p.media = media
            media.release()
            p.play()
        } catch (e: Exception) {
            hide()
        }
    }

    fun hide() {
        try { player?.stop() } catch (_: Exception) {}
        try { player?.detachViews() } catch (_: Exception) {}
        try { player?.release() } catch (_: Exception) {}
        try { vlc?.release() } catch (_: Exception) {}
        try { pfd?.close() } catch (_: Exception) {}
        layout?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        player = null; vlc = null; pfd = null; layout = null
    }
}
