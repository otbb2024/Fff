package com.example.arcaptions

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.media.*
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.*
import kotlinx.coroutines.*
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.abs

class CaptionService : Service() {
    companion object { @Volatile var running = false }

    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var projection: MediaProjection? = null
    private lateinit var wm: WindowManager
    private var box: LinearLayout? = null
    private var arTv: TextView? = null
    private var enTv: TextView? = null
    private var lp: WindowManager.LayoutParams? = null
    private val h = Handler(Looper.getMainLooper())
    private val clearRun = Runnable { box?.visibility = View.INVISIBLE }
    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> h.post { restyle() } }
    private val seq = AtomicLong()
    private var shown = 0L
    private var translator: com.google.mlkit.nl.translate.Translator? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, f: Int, id: Int): Int {
        if (intent?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("cap", "الترجمة", NotificationManager.IMPORTANCE_LOW))
        val stopPi = PendingIntent.getService(this, 0, Intent(this, CaptionService::class.java).setAction("STOP"),
            PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "cap").setContentTitle("ترجمان يعمل")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_media_pause), "إيقاف", stopPi).build())
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

        @Suppress("DEPRECATION")
        val data = intent?.getParcelableExtra<Intent>("data")
        if (data == null || !Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(intent.getIntExtra("code", 0), data)
        projection?.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }, h)
        val src = prefs().getString("src", "en") ?: "en"; val tgt = prefs().getString("tgt", "ar") ?: "ar"
        // نفس اللغة = تفريغ نصي فقط بدون ترجمة
        if (src != tgt) translator = Translation.getClient(
            TranslatorOptions.Builder().setSourceLanguage(src).setTargetLanguage(tgt).build())
        running = true
        buildOverlay(); prefs().registerOnSharedPreferenceChangeListener(listener)
        show("جاري تجهيز الترجمة...")
        scope.launch { engine() }
        return START_NOT_STICKY
    }

    private fun buildOverlay() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        arTv = TextView(this).apply { gravity = Gravity.CENTER; textDirection = View.TEXT_DIRECTION_FIRST_STRONG }
        enTv = TextView(this).apply { gravity = Gravity.CENTER; textDirection = View.TEXT_DIRECTION_FIRST_STRONG }
        box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(28), dp(14), dp(28), dp(14)); visibility = View.INVISIBLE
            addView(enTv); addView(arTv)
        }
        lp = WindowManager.LayoutParams((resources.displayMetrics.widthPixels * 0.85f).toInt(),
            ViewGroup.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT)
        wm.addView(box, lp)
        restyle()
    }

    private fun restyle() {
        val b = box ?: return
        val s = loadStyle()
        applyStyle(s, b, arTv!!, enTv!!)
        lp!!.gravity = Gravity.CENTER_HORIZONTAL or when (s.pos) { 0 -> Gravity.BOTTOM; 1 -> Gravity.CENTER_VERTICAL; else -> Gravity.TOP }
        lp!!.y = dp(48)
        wm.updateViewLayout(b, lp)
    }

    private fun show(ar: String, en: String = "", ms: Long = 6000) {
        h.post {
            if (ar.isBlank()) { box?.visibility = View.INVISIBLE; return@post }
            arTv?.text = ar; enTv?.text = en
            enTv?.visibility = if (en.isBlank() || !loadStyle().showEn) View.GONE else View.VISIBLE
            box?.visibility = View.VISIBLE
            h.removeCallbacks(clearRun); h.postDelayed(clearRun, ms)
        }
    }

    private fun fail(msg: String) {
        show(msg, "", 8000)
        h.postDelayed({ stopSelf() }, 8000)
    }

    private suspend fun engine() {
        var model: Model? = null; var rec: Recognizer? = null; var ar: AudioRecord? = null
        try {
            val m = ModelManager.info(this)
            if (!ModelManager.ready(this, m)) { fail("نموذج الصوت غير محمّل، افتح التطبيق وشغّل من جديد"); return }

            val tr = translator
            if (tr != null) {
                val dl = CompletableDeferred<Boolean>()
                tr.downloadModelIfNeeded(DownloadConditions.Builder().build())
                    .addOnSuccessListener { dl.complete(true) }.addOnFailureListener { dl.complete(false) }
                if (!dl.await()) { fail("تعذر تحميل نموذج الترجمة، تأكد من الإنترنت"); return }
            }

            model = withContext(Dispatchers.IO) { Model(ModelManager.dir(this@CaptionService, m).absolutePath) }
            rec = Recognizer(model, 16000f)
            val cfg = AudioPlaybackCaptureConfiguration.Builder(projection!!)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA).addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN).build()
            val fmt = AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(16000).setChannelMask(AudioFormat.CHANNEL_IN_MONO).build()
            ar = AudioRecord.Builder().setAudioFormat(fmt).setAudioPlaybackCaptureConfig(cfg)
                .setBufferSizeInBytes(16000 * 2 * 2).build()
            if (ar.state != AudioRecord.STATE_INITIALIZED) { fail("تعذر بدء التقاط الصوت على هذا الجهاز"); return }
            ar.startRecording(); show("الترجمة جاهزة ✓")

            val buf = ShortArray(2048)
            var lastPartial = ""; var lastTime = 0L
            var lastSound = System.currentTimeMillis(); var warned = false
            while (scope.isActive) {
                val n = ar.read(buf, 0, buf.size)
                if (n < 0) { fail("انقطع التقاط الصوت"); return }
                if (n == 0) continue

                var peak = 0
                for (i in 0 until n) { val a = abs(buf[i].toInt()); if (a > peak) peak = a }
                val now = System.currentTimeMillis()
                if (peak > 8) { lastSound = now; warned = false }
                else if (!warned && now - lastSound > 20000) {
                    warned = true
                    show("لا يصل صوت للتطبيق. قد يكون الفيديو متوقفاً أو أن التطبيق يمنع التقاط صوته")
                }

                if (rec.acceptWaveForm(buf, n)) {
                    val t = JSONObject(rec.result).optString("text")
                    if (t.isNotBlank()) translate(t)
                    lastPartial = ""
                } else {
                    val p = JSONObject(rec.partialResult).optString("partial")
                    if (p.isNotBlank() && p != lastPartial && now - lastTime > 800) {
                        lastPartial = p; lastTime = now; translate(p)
                    }
                }
            }
        } catch (e: Exception) {
            fail("حدث خطأ: ${e.message ?: "غير معروف"}")
        } finally {
            try { ar?.stop() } catch (_: Exception) {}
            ar?.release(); rec?.close(); model?.close()
        }
    }

    private fun translate(t: String) {
        val tr = translator
        if (tr == null) { show(t); return }
        val id = seq.incrementAndGet()
        tr.translate(t).addOnSuccessListener { if (id > shown) { shown = id; show(it, t) } }
    }

    override fun onDestroy() {
        running = false; scope.cancel(); projection?.stop()
        prefs().unregisterOnSharedPreferenceChangeListener(listener)
        h.removeCallbacksAndMessages(null)
        if (::wm.isInitialized) box?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        translator?.close()
        super.onDestroy()
    }
}
